#!/bin/bash
# Project Purge Module (mo purge).
# Removes heavy project build artifacts and dependencies.
set -euo pipefail

PROJECT_LIB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CORE_LIB_DIR="$(cd "$PROJECT_LIB_DIR/../core" && pwd)"
if ! command -v ensure_user_dir > /dev/null 2>&1; then
    # shellcheck disable=SC1090
    source "$CORE_LIB_DIR/common.sh"
fi
# shellcheck disable=SC1090
source "$PROJECT_LIB_DIR/purge_shared.sh"

readonly PURGE_TARGETS=("${MOLE_PURGE_TARGETS[@]}")
# Minimum age in days before considering for cleanup.
readonly MIN_AGE_DAYS=7
# Scan depth defaults (relative to search root).
readonly PURGE_MIN_DEPTH_DEFAULT=1
readonly PURGE_MAX_DEPTH_DEFAULT=6
# Search paths (default, can be overridden via config file).
readonly DEFAULT_PURGE_SEARCH_PATHS=("${MOLE_PURGE_DEFAULT_SEARCH_PATHS[@]}")

# Config file for custom purge paths.
readonly PURGE_CONFIG_FILE="$HOME/.config/mactools/mole/purge_paths"

# Resolved search paths.
PURGE_SEARCH_PATHS=()
PURGE_CATEGORY_FULL_PATHS_ARRAY=()
PURGE_CATEGORY_PROJECT_IDS_ARRAY=()
PURGE_CATEGORY_PROJECT_PATHS_ARRAY=()
PURGE_CATEGORY_SIZE_UNKNOWN_FLAGS_ARRAY=()

# Project indicators for container detection.
# Monorepo indicators (higher priority)
readonly MONOREPO_INDICATORS=("${MOLE_PURGE_MONOREPO_INDICATORS[@]}")
readonly PROJECT_INDICATORS=("${MOLE_PURGE_PROJECT_INDICATORS[@]}")

# Check if a directory contains projects (directly or in subdirectories).
is_project_container() {
    local dir="$1"
    local max_depth="${2:-2}"
    local deadline="${3:-}"

    # Skip hidden/system directories.
    local basename
    basename=$(basename "$dir")
    [[ "$basename" == .* ]] && return 1
    [[ "$basename" == "Library" ]] && return 1
    [[ "$basename" == "Applications" ]] && return 1
    [[ "$basename" == "Movies" ]] && return 1
    [[ "$basename" == "Music" ]] && return 1
    [[ "$basename" == "Pictures" ]] && return 1
    [[ "$basename" == "Public" ]] && return 1

    # A purge target is an artifact, never a container. A stray ~/node_modules
    # is otherwise globbed as one: every npm package ships package.json, the
    # first project indicator, so the maxdepth-2 probe matches immediately and
    # each package becomes a "project root". The scan then starts below the
    # artifact, so filter_nested_artifacts never sees node_modules itself and
    # emits package-internal dist/ and build/ instead. Deleting those leaves
    # the package half-installed: package.json stays, npm reports the tree as
    # up to date, and recovery needs a network restore, which purge must never
    # require (#1459). Same shape for vendor/ and Pods/. A container that
    # happens to share an artifact name stays reachable through
    # ~/.config/mactools/mole/purge_paths, which bypasses discovery.
    local purge_target
    for purge_target in "${PURGE_TARGETS[@]}"; do
        if [[ "$basename" == "$purge_target" ]]; then
            return 1
        fi
    done

    # Single find expression for indicators.
    local -a find_args=("$dir" "-maxdepth" "$max_depth" "(")
    local first=true
    for indicator in "${PROJECT_INDICATORS[@]}"; do
        if [[ "$first" == "true" ]]; then
            first=false
        else
            find_args+=("-o")
        fi
        find_args+=("-name" "$indicator")
    done
    find_args+=(")" "-print" "-quit")

    local probe_timeout probe_output probe_status=0
    probe_timeout=$(_mole_timeout_with_deadline "$MOLE_TIMEOUT_MEDIUM_PROBE_SEC" "$deadline") || return $?
    probe_output=$(run_with_timeout "$probe_timeout" find "${find_args[@]}" 2> /dev/null) || probe_status=$?
    if [[ $probe_status -ne 0 ]]; then
        mole_rc_timeout_or_signal "$probe_status" && return "$probe_status"
        return 2
    fi
    [[ -n "$probe_output" ]]
}

# Discover project directories in $HOME.
discover_project_dirs() {
    local -a discovered=()
    local deadline=$((SECONDS + MOLE_TIMEOUT_HINT_SCAN_SEC))
    local discovery_status=0

    for path in "${DEFAULT_PURGE_SEARCH_PATHS[@]}"; do
        if [[ -d "$path" ]]; then
            # Resolve to canonical casing to avoid duplicates on
            # case-insensitive filesystems (macOS APFS).
            discovered+=("$(mole_purge_resolve_path_case "$path")")
        fi
    done

    # Scan $HOME for other containers (depth 1).
    local dir
    for dir in "$HOME"/*/; do
        if [[ $SECONDS -ge $deadline ]]; then
            discovery_status=124
            break
        fi
        [[ ! -d "$dir" ]] && continue
        dir="${dir%/}" # Remove trailing slash
        # Resolve casing so that ~/code and ~/Code compare equal.
        dir=$(mole_purge_resolve_path_case "$dir")

        local already_found=false
        for existing in "${discovered[@]+"${discovered[@]}"}"; do
            if [[ "$dir" == "$existing" ]]; then
                already_found=true
                break
            fi
        done
        [[ "$already_found" == "true" ]] && continue

        local probe_status=0
        if is_project_container "$dir" 2 "$deadline"; then
            discovered+=("$dir")
        else
            probe_status=$?
            if [[ $probe_status -ne 1 ]]; then
                discovery_status=$probe_status
                [[ $probe_status -lt 128 ]] || break
            fi
        fi
    done

    printf '%s\n' "${discovered[@]+"${discovered[@]}"}" | sort -u
    return "$discovery_status"
}

# Prepare purge config directory/file ownership when possible.
prepare_purge_config_path() {
    ensure_user_dir "$(dirname "$PURGE_CONFIG_FILE")"
    ensure_user_file "$PURGE_CONFIG_FILE"
}

# Write purge config content atomically when possible.
write_purge_config() {
    local header="$1"
    shift
    local -a paths=("$@")

    prepare_purge_config_path

    local tmp_file
    tmp_file=$(mktemp_file "mole-purge-paths") || return 1

    if ! printf '%s\n' "$header" > "$tmp_file"; then
        rm -f "$tmp_file" 2> /dev/null || true
        return 1
    fi

    # Guard empty-array expansion under `set -u` on bash 3.2 (first-run case
    # from `mo purge --paths` passes only the header with no paths).
    if [[ ${#paths[@]} -gt 0 ]]; then
        for path in "${paths[@]}"; do
            # Convert $HOME to ~ for portability
            path="${path/#$HOME/~}"
            if ! printf '%s\n' "$path" >> "$tmp_file"; then
                rm -f "$tmp_file" 2> /dev/null || true
                return 1
            fi
        done
    fi

    if ! mv "$tmp_file" "$PURGE_CONFIG_FILE" 2> /dev/null; then
        rm -f "$tmp_file" 2> /dev/null || true
        return 1
    fi

    return 0
}

warn_purge_config_write_failure() {
    [[ -t 1 ]] || return 0
    [[ -z "${_PURGE_DISCOVERY_SILENT:-}" ]] || return 0
    echo -e "${YELLOW}${ICON_WARNING}${NC} Could not save purge paths to ${PURGE_CONFIG_FILE/#$HOME/~}, using discovered paths for this run" >&2
}

# Save discovered paths to config.
save_discovered_paths() {
    local -a paths=("$@")
    write_purge_config "# Mole Purge Paths - Auto-discovered project directories
# Edit this file to customize, or run: mo purge --paths
# Add one path per line (supports ~ for home directory)
" "${paths[@]}"
}

# Load purge paths from config or auto-discover
load_purge_config() {
    PURGE_SEARCH_PATHS=()
    PURGE_DISCOVERY_STATUS=0

    local line existing_path already_found
    while IFS= read -r line; do
        [[ -n "$line" ]] || continue
        # mole_purge_read_paths_config already folds case variants to the
        # on-disk path, so a config listing ~/code and ~/Code yields the
        # same resolved string twice. Drop the duplicate here so downstream
        # scans and the menu show each path once (#1416).
        already_found=false
        for existing_path in "${PURGE_SEARCH_PATHS[@]+"${PURGE_SEARCH_PATHS[@]}"}"; do
            if [[ "$line" == "$existing_path" ]]; then
                already_found=true
                break
            fi
        done
        [[ "$already_found" == "true" ]] && continue
        PURGE_SEARCH_PATHS+=("$line")
    done < <(mole_purge_read_paths_config "$PURGE_CONFIG_FILE")

    if [[ ${#PURGE_SEARCH_PATHS[@]} -eq 0 ]]; then
        if [[ -t 1 ]] && [[ -z "${_PURGE_DISCOVERY_SILENT:-}" ]]; then
            echo -e "${GRAY}First run: discovering project directories...${NC}" >&2
        fi

        local -a discovered=()
        local discovery_output
        discovery_output=$(discover_project_dirs) || PURGE_DISCOVERY_STATUS=$?
        [[ $PURGE_DISCOVERY_STATUS -lt 128 ]] || return "$PURGE_DISCOVERY_STATUS"
        while IFS= read -r path; do
            [[ -n "$path" ]] && discovered+=("$path")
        done <<< "$discovery_output"
        if [[ $PURGE_DISCOVERY_STATUS -ne 0 && -z "${_PURGE_DISCOVERY_SILENT:-}" ]]; then
            echo -e "${YELLOW}${ICON_WARNING}${NC} Project discovery was incomplete; using completed roots without saving them. Run mo purge --paths to review search paths." >&2
        fi

        if [[ ${#discovered[@]} -gt 0 ]]; then
            PURGE_SEARCH_PATHS=("${discovered[@]}")
            if [[ $PURGE_DISCOVERY_STATUS -ne 0 ]]; then
                : # A partial inventory must not become the next run's saved scope.
            elif save_discovered_paths "${discovered[@]}"; then
                if [[ -t 1 ]] && [[ -z "${_PURGE_DISCOVERY_SILENT:-}" ]]; then
                    echo -e "${GRAY}Found ${#discovered[@]} project directories, saved to config${NC}" >&2
                fi
            else
                warn_purge_config_write_failure
            fi
        else
            PURGE_SEARCH_PATHS=("${DEFAULT_PURGE_SEARCH_PATHS[@]}")
        fi
    fi
}

# Initialize paths on script load.
load_purge_config

format_purge_target_path() {
    local path="$1"
    echo "${path/#$HOME/~}"
}

compact_purge_menu_path() {
    local path="$1"
    local max_width="${2:-0}"

    if ! [[ "$max_width" =~ ^[0-9]+$ ]] || [[ "$max_width" -lt 4 ]]; then
        max_width=4
    fi

    local path_width
    path_width=$(get_display_width "$path")
    if [[ $path_width -le $max_width ]]; then
        echo "$path"
        return
    fi

    local tail=""
    local remainder="$path"
    local prefix_width=3

    while [[ "$remainder" == */* ]]; do
        local segment="/${remainder##*/}"
        remainder="${remainder%/*}"

        local candidate="${segment}${tail}"
        local candidate_width
        candidate_width=$(get_display_width "$candidate")
        if [[ $((candidate_width + prefix_width)) -le $max_width ]]; then
            tail="$candidate"
        else
            break
        fi
    done

    if [[ -n "$tail" ]]; then
        echo "...${tail}"
        return
    fi

    # A single long segment can contain wide characters. Build the suffix by
    # display width so the fallback cannot overflow a narrow terminal.
    local old_lc="${LC_ALL:-}"
    export LC_ALL=en_US.UTF-8
    local suffix=""
    local suffix_width=0
    local char char_width
    local i=$((${#path} - 1))
    while [[ $i -ge 0 ]]; do
        char="${path:$i:1}"
        char_width=$(get_display_width "$char")
        if [[ $((suffix_width + char_width + prefix_width)) -gt $max_width ]]; then
            break
        fi
        suffix="${char}${suffix}"
        suffix_width=$((suffix_width + char_width))
        i=$((i - 1))
    done
    if [[ -n "$old_lc" ]]; then
        export LC_ALL="$old_lc"
    else
        unset LC_ALL
    fi
    echo "...${suffix}"
}

# Args: $1 - directory path
# Determine whether a directory is a project root.
# This is used to safely allow cleaning direct-child artifacts when
# users configure a single project directory as a purge search path.
is_purge_project_root() {
    mole_purge_is_project_root "$1"
}

# Args: $1 - path to check
# Safe cleanup requires the path be inside a project directory.
is_safe_project_artifact_under_root() {
    local path="${1%/}"
    local search_path="${2%/}"

    [[ "$path" == /* && "$search_path" == /* && "$search_path" != "/" ]] || return 1
    [[ "$path" == "$search_path/"* ]] || return 1

    local relative_path="${path#"$search_path"/}"
    local relative_without_slashes="${relative_path//\//}"
    local depth=$((${#relative_path} - ${#relative_without_slashes}))
    if [[ $depth -lt 1 ]]; then
        # Allow direct-child artifacts only when the search path is itself
        # a project root (single-project mode).
        is_purge_project_root "$search_path"
        return $?
    fi
    return 0
}

is_safe_project_artifact() {
    local path="$1"
    local search_path="$2"

    # Normalize search path to tolerate user config entries with trailing slash.
    if [[ "$search_path" != "/" ]]; then
        search_path="${search_path%/}"
    fi

    if [[ "$path" != /* ]]; then
        return 1
    fi

    local lexically_contained=false
    [[ "$path" == "$search_path/"* ]] && lexically_contained=true

    # Always compare existing directories physically. A lexical prefix alone
    # is not containment when any ancestor is a symlink; it can otherwise turn
    # a configured project root into authority over an unrelated directory.
    # This also preserves aliases such as /var -> /private/var because both
    # sides are resolved before the comparison.
    if [[ -d "$path" && -d "$search_path" ]]; then
        local physical_path=""
        local physical_search_path=""
        physical_path=$(cd "$path" 2> /dev/null && pwd -P) || return 1
        physical_search_path=$(cd "$search_path" 2> /dev/null && pwd -P) || return 1

        if [[ -z "$physical_path" || -z "$physical_search_path" || "$physical_path" != "$physical_search_path/"* ]]; then
            return 1
        fi

        path="$physical_path"
        search_path="$physical_search_path"
    elif [[ "$lexically_contained" != "true" ]]; then
        return 1
    fi

    is_safe_project_artifact_under_root "$path" "$search_path"
}

# Revalidate a selected artifact against the configured scan roots immediately
# before deletion. Purge supports explicit roots outside HOME (for example
# /var/www), so HOME containment is neither sufficient nor correct here.
is_safe_configured_purge_artifact() {
    local path="$1"

    [[ -n "$path" && "$path" != "/" && "$path" != "$HOME" ]] || return 1
    [[ ${#PURGE_SEARCH_PATHS[@]} -gt 0 ]] || return 1

    local search_path
    # Ordinary configured roots retain their lexical prefix in scan results.
    # Check those roots first so one candidate does not resolve every unrelated
    # root physically. The second pass preserves support for symlink aliases.
    for search_path in "${PURGE_SEARCH_PATHS[@]}"; do
        [[ -n "$search_path" ]] || continue
        [[ "$search_path" == "/" || "$path" == "${search_path%/}/"* ]] || continue
        if is_safe_project_artifact "$path" "$search_path"; then
            return 0
        fi
    done
    for search_path in "${PURGE_SEARCH_PATHS[@]}"; do
        [[ -n "$search_path" ]] || continue
        [[ "$search_path" != "/" && "$path" != "${search_path%/}/"* ]] || continue
        if is_safe_project_artifact "$path" "$search_path"; then
            return 0
        fi
    done

    return 1
}

# Detect if directory is a Rails project root
is_rails_project_root() {
    local dir="$1"
    [[ -f "$dir/config/application.rb" ]] || return 1
    [[ -f "$dir/Gemfile" ]] || return 1
    [[ -f "$dir/bin/rails" || -f "$dir/config/environment.rb" ]]
}

# Detect if directory is a Go project root
is_go_project_root() {
    local dir="$1"
    [[ -f "$dir/go.mod" ]]
}

# Detect if directory is a PHP Composer project root
is_php_project_root() {
    local dir="$1"
    [[ -f "$dir/composer.json" ]]
}

# Decide whether a "bin" directory is a .NET directory
is_dotnet_bin_dir() {
    local path="${1%/}"
    [[ "${path##*/}" == "bin" ]] || return 1

    # Check if parent directory has a .csproj/.fsproj/.vbproj file
    local parent_dir="${path%/*}"
    [[ -n "$parent_dir" ]] || parent_dir="/"
    find "$parent_dir" -maxdepth 1 \( -name "*.csproj" -o -name "*.fsproj" -o -name "*.vbproj" \) 2> /dev/null | grep -q . || return 1

    # Check if bin directory contains Debug/ or Release/ subdirectories
    [[ -d "$path/Debug" || -d "$path/Release" ]] || return 1

    return 0
}

# Check if a vendor directory should be protected from purge
# Expects path to be a vendor directory (basename == vendor)
# Strategy: Only clean PHP Composer vendor, protect all others
is_protected_vendor_dir() {
    local path="${1%/}"
    local base="${path##*/}"
    [[ "$base" == "vendor" ]] || return 1
    local parent_dir="${path%/*}"
    [[ -n "$parent_dir" ]] || parent_dir="/"

    # PHP Composer vendor can be safely regenerated with 'composer install'
    # Do NOT protect it (return 1 = not protected = can be cleaned)
    if is_php_project_root "$parent_dir"; then
        return 1
    fi

    # Rails vendor (importmap dependencies) - should be protected
    if is_rails_project_root "$parent_dir"; then
        return 0
    fi

    # Go vendor (optional vendoring) - protect to avoid accidental deletion
    if is_go_project_root "$parent_dir"; then
        return 0
    fi

    # Unknown vendor type - protect by default (conservative approach)
    return 0
}

# Check if an artifact should be protected from purge
# Names do not prove rebuildability: target/deploy carries Anchor keys,
# and build/coverage can contain tracked source. Reused at discovery and sink.
# Returns 0 when authored content is present, 1 when the walk completed and
# found none, 2 when a probe timed out or failed; signals propagate. A 2 is not evidence either
# way: callers keep the candidate but must say so instead of dropping it.
purge_artifact_has_authored_content() {
    local path="${1%/}"
    local deadline="${2:-}"
    local probe_timeout=""
    [[ -d "$path" ]] || return 1
    # A configured root can cross a symlink before reaching the candidate.
    path=$(cd "$path" 2> /dev/null && /bin/pwd -P) || return 2
    local evidence=""
    # Do not follow links or read key contents. This walks the whole artifact
    # when nothing matches, so it takes the tree-walk budget, not the
    # command-probe one.
    probe_timeout=$(_mole_timeout_with_deadline "$MOLE_TIMEOUT_HINT_SCAN_SEC" "$deadline") || return 2
    local probe_rc=0
    evidence=$(run_with_timeout "$probe_timeout" /usr/bin/find "$path" \
        \( -name .git -o -name '*-keypair.json' \) -print -quit 2> /dev/null) || probe_rc=$?
    [[ $probe_rc -le 128 ]] || return "$probe_rc"
    [[ $probe_rc -eq 0 ]] || return 2
    [[ -z "$evidence" ]] || return 0

    local tracked_rc=0
    mole_path_has_git_tracked_files "$path" "$deadline" || tracked_rc=$?
    return "$tracked_rc"
}

# Set by is_protected_purge_artifact: true when the verdict came from an
# unfinished content probe rather than evidence.
PURGE_PROTECTION_UNVERIFIED=false

is_protected_purge_artifact() {
    local path="${1%/}"
    local deadline="${2:-}"
    local base="${path##*/}"

    PURGE_PROTECTION_UNVERIFIED=false
    local authored_rc=0
    purge_artifact_has_authored_content "$path" "$deadline" || authored_rc=$?
    [[ $authored_rc -le 128 ]] || return "$authored_rc"
    if [[ $authored_rc -eq 2 ]]; then
        PURGE_PROTECTION_UNVERIFIED=true
        return 0
    fi
    [[ $authored_rc -ne 0 ]] || return 0

    case "$base" in
        bin)
            # Only allow purging bin/ when we can detect .NET context.
            if is_dotnet_bin_dir "$path"; then
                return 1
            fi
            return 0
            ;;
        vendor)
            is_protected_vendor_dir "$path"
            return $?
            ;;
        DerivedData)
            # Protect Xcode global DerivedData in ~/Library/Developer/Xcode/
            # Only allow purging DerivedData within project directories
            [[ "$path" == *"/Library/Developer/Xcode/DerivedData"* ]] && return 0
            return 1
            ;;
    esac

    return 1
}

# Scan purge targets using fd (fast) or pruned find. Optional $3 names a file
# for the candidates the content probes verified clean; the caller that asks
# for it owns and removes it, so a plain scan leaves nothing behind.
# The purge walk and its dataless probe use the system find: `-flags` is a BSD
# primary, so a GNU findutils find earlier in PATH would always answer "unknown"
# and the walk would descend into online-only cloud folders. One binary for the
# probe, the root listing and the walk keeps the probe's answer true for both.
# Not readonly so a test can point it at a fixture stub after sourcing.
_MOLE_PURGE_FIND="/usr/bin/find"

# 0 when this find accepts `-flags +dataless`. Probed once per process on a
# directory that is never dataless; any failure means "unknown", not "dataless".
_purge_find_knows_dataless() {
    if [[ -z "${_MOLE_PURGE_FIND_DATALESS:-}" ]]; then
        local probe_rc=0
        run_with_timeout "$MOLE_TIMEOUT_QUICK_DETECT_SEC" "$_MOLE_PURGE_FIND" "$HOME" -maxdepth 0 -flags +dataless > /dev/null 2>&1 || probe_rc=$?
        mole_rc_signal "$probe_rc" && return "$probe_rc"
        if [[ $probe_rc -eq 0 ]]; then
            _MOLE_PURGE_FIND_DATALESS="yes"
        else
            _MOLE_PURGE_FIND_DATALESS="no"
        fi
    fi
    [[ "$_MOLE_PURGE_FIND_DATALESS" == "yes" ]]
}

# Directories every purge walk prunes by name.
readonly PURGE_WALK_PRUNE_DIRS=(".git" "Library" ".Trash" "Applications")

# Sets _PURGE_PRUNE_EXPR and _PURGE_TARGET_EXPR, the find name tests the purge
# walks share. $1 = yes adds the online-only (dataless) prune: such a folder
# holds nothing on this disk, and listing it makes the File Provider fetch it
# from the network, which is how a Google Drive root used up the scan budget
# (#1679).
_purge_walk_expressions() {
    local with_dataless="$1" name
    _PURGE_PRUNE_EXPR=()
    for name in "${PURGE_WALK_PRUNE_DIRS[@]}"; do
        [[ ${#_PURGE_PRUNE_EXPR[@]} -eq 0 ]] || _PURGE_PRUNE_EXPR+=(-o)
        _PURGE_PRUNE_EXPR+=(-name "$name")
    done
    [[ "$with_dataless" != "yes" ]] || _PURGE_PRUNE_EXPR+=(-o -flags +dataless)
    _PURGE_TARGET_EXPR=()
    for name in "${PURGE_TARGETS[@]}"; do
        [[ ${#_PURGE_TARGET_EXPR[@]} -eq 0 ]] || _PURGE_TARGET_EXPR+=(-o)
        _PURGE_TARGET_EXPR+=(-name "$name")
    done
}

# Split a configured scan root whose single scan timed out into scan units,
# each re-scanned with its own budget so one slow project skips only itself
# (#1666). A root that is itself a project stays one unit. Any other root
# becomes one unit per direct child the root walk would enter: pruned names,
# online-only folders, purge targets (a direct-child artifact of a non-project
# root is refused by the depth rule anyway), symlinks and non-directories are
# left out. A root whose listing fails, or that has no such child, stays one
# unit. Sets _PURGE_SCAN_UNITS; returns a signal status when the listing was
# interrupted.
_PURGE_SCAN_UNITS=()
_purge_list_scan_units() {
    local root="$1"
    _PURGE_SCAN_UNITS=()
    if mole_purge_is_project_root "$root"; then
        _PURGE_SCAN_UNITS=("$root")
        return 0
    fi
    local dataless_rc=0 with_dataless=no
    _purge_find_knows_dataless || dataless_rc=$?
    if mole_rc_signal "$dataless_rc"; then
        return "$dataless_rc"
    fi
    [[ $dataless_rc -ne 0 ]] || with_dataless=yes
    _purge_walk_expressions "$with_dataless"

    local list_output=""
    list_output=$(mktemp_file "mole-purge-units") || list_output=""
    local list_rc=1
    if [[ -n "$list_output" ]]; then
        list_rc=0
        run_with_timeout "$(_purge_scan_timeout_seconds)" "$_MOLE_PURGE_FIND" "$root" -mindepth 1 -maxdepth 1 \
            \( "${_PURGE_PRUNE_EXPR[@]}" -o "${_PURGE_TARGET_EXPR[@]}" \) -prune -o \
            -type d -print0 2> /dev/null > "$list_output" || list_rc=$?
    fi
    if mole_rc_signal "$list_rc"; then
        rm -f "$list_output" 2> /dev/null || true # SAFE: exact scratch file created above
        return "$list_rc"
    fi
    if [[ $list_rc -eq 0 ]]; then
        # Sorted, so units start and skipped children are reported in name
        # order rather than directory order.
        local child
        while IFS= read -r -d '' child; do
            [[ "$child" == "${root%/}/"* && -d "$child" && ! -L "$child" ]] || continue
            _PURGE_SCAN_UNITS+=("$child")
        done < <(LC_ALL=C sort -z "$list_output" 2> /dev/null)
    else
        debug_log "Purge scan root listing failed (status $list_rc), scanning it as one unit: $root"
    fi
    [[ -z "$list_output" ]] || rm -f "$list_output" 2> /dev/null || true # SAFE: exact scratch file created above
    [[ ${#_PURGE_SCAN_UNITS[@]} -gt 0 ]] || _PURGE_SCAN_UNITS=("$root")
    return 0
}

# Whole-second discovery budget for one scan unit, from MO_PURGE_SCAN_TIMEOUT_SEC.
_purge_scan_timeout_seconds() {
    local scan_timeout="${MO_PURGE_SCAN_TIMEOUT_SEC:-60}"
    [[ "$scan_timeout" =~ ^[1-9][0-9]*$ ]] || scan_timeout=60
    [[ "$scan_timeout" -ge 2 ]] || scan_timeout=2
    printf '%s\n' "$scan_timeout"
}

# Args: $1 configured scan root, $2 output file, $3 optional verified sidecar,
# $4 optional scan unit: a directory below $1 to walk instead of all of $1.
# Depth limits and safety checks stay relative to $1, so a unit finds exactly
# what the whole-root walk finds below it (#1666).
scan_purge_targets() {
    local search_path="$1"
    local output_file="$2"
    local target_output="${output_file}.targets"
    local tag_output="${output_file}.tags"
    local walk_output="${output_file}.walk"
    local processed_output="${output_file}.processed"
    local error_output="${output_file}.errors"
    local verified_output="${3:-}"
    local walk_path="${4:-$search_path}"
    local min_depth="$PURGE_MIN_DEPTH_DEFAULT"
    local max_depth="$PURGE_MAX_DEPTH_DEFAULT"
    if [[ ! "$min_depth" =~ ^[0-9]+$ ]]; then
        min_depth="$PURGE_MIN_DEPTH_DEFAULT"
    fi
    if [[ ! "$max_depth" =~ ^[0-9]+$ ]]; then
        max_depth="$PURGE_MAX_DEPTH_DEFAULT"
    fi
    if [[ "$max_depth" -lt "$min_depth" ]]; then
        max_depth="$min_depth"
    fi
    if [[ ! -d "$search_path" ]]; then
        return
    fi
    # A unit is a real directory below the root. One that vanished or became a
    # symlink after the root was listed holds nothing this root may scan.
    local walk_offset=0
    if [[ "$walk_path" != "$search_path" ]]; then
        local walk_relative="${walk_path#"${search_path%/}"/}"
        [[ "$walk_relative" != "$walk_path" && -n "$walk_relative" ]] || return 1
        local walk_relative_without_slashes="${walk_relative//\//}"
        walk_offset=$((${#walk_relative} - ${#walk_relative_without_slashes} + 1))
        if [[ -L "$walk_path" || ! -d "$walk_path" ]]; then
            : > "$output_file"
            return 0
        fi
    fi

    # A scan result is publishable only after every producer and filter for the
    # root completes. Keep the caller-visible file empty until that point so a
    # timeout or read failure cannot turn a partial prefix into delete candidates.
    : > "$output_file"
    rm -f "$target_output" "$tag_output" "$walk_output" "$processed_output" "$error_output" 2> /dev/null || true
    [[ -z "$verified_output" ]] || rm -f "$verified_output" "${verified_output}.probes" 2> /dev/null || true

    # Depths below are relative to the walk path; candidates keep the depths
    # they have relative to the configured root.
    local cachedir_tag_min_depth=$((min_depth + 1 - walk_offset))
    local cachedir_tag_max_depth=$((max_depth + 1 - walk_offset))
    min_depth=$((min_depth - walk_offset))
    max_depth=$((max_depth - walk_offset))
    [[ $min_depth -ge 1 ]] || min_depth=1
    [[ $cachedir_tag_min_depth -ge 1 ]] || cachedir_tag_min_depth=1
    if [[ $max_depth -lt $min_depth ]]; then
        : > "$output_file"
        return 0
    fi
    local scan_timeout
    scan_timeout=$(_purge_scan_timeout_seconds)
    local scan_deadline=$((SECONDS + scan_timeout))
    local scan_stage_timeout=""

    # Update current scanning path
    local stats_dir="${XDG_CACHE_HOME:-$HOME/.cache}/mactools/mole"
    echo "$walk_path" > "$stats_dir/purge_scanning" 2> /dev/null || true

    emit_valid_cachedir_tag_dirs() {
        local deadline="$1"
        while IFS= read -r tag_file; do
            if [[ $SECONDS -ge $deadline ]]; then
                return 124
            fi
            [[ -n "$tag_file" ]] || continue
            local cache_dir="${tag_file%/*}"
            if [[ -n "$cache_dir" ]] && mole_dir_has_cachedir_tag "$cache_dir"; then
                printf '%s\n' "$cache_dir"
            fi
        done
    }

    # Helper to process raw results
    process_scan_results() {
        local input_file="$1"
        local deadline="$2"
        if [[ -f "$input_file" ]]; then
            local process_status=0
            local nested_filter_timeout=""
            nested_filter_timeout=$(_mole_timeout_with_deadline "$scan_timeout" "$deadline") || process_status=$?
            if [[ $process_status -ne 0 ]]; then
                return "$process_status"
            fi
            filter_nested_artifacts "$nested_filter_timeout" < "$input_file" |
                (
                    while IFS= read -r item; do
                        if [[ $SECONDS -ge $deadline ]]; then
                            exit 124
                        fi
                        # Check if we should abort (scanning file removed by Ctrl+C)
                        if [[ ! -f "$stats_dir/purge_scanning" ]]; then
                            exit 130
                        fi

                        if [[ -n "$item" ]] && is_safe_project_artifact "$item" "$search_path"; then
                            echo "$item"
                            # Update scanning path to show current project directory
                            local project_dir="${item%/*}"
                            echo "$project_dir" > "$stats_dir/purge_scanning" 2> /dev/null || true
                        fi
                    done
                ) | filter_protected_artifacts "$deadline" "$verified_output" "$stats_dir/purge_scanning" > "$processed_output" || process_status=$?

            if [[ $process_status -ne 0 ]]; then
                rm -f "$processed_output" 2> /dev/null || true
                [[ -z "$verified_output" ]] || rm -f "$verified_output" "${verified_output}.probes" 2> /dev/null || true
                return "$process_status"
            fi
            if ! mv "$processed_output" "$output_file"; then
                rm -f "$processed_output" 2> /dev/null || true
                return 1
            fi
        else
            return 1
        fi
    }

    cleanup_scan_outputs() {
        rm -f "$target_output" "$tag_output" "$walk_output" "$processed_output" "$error_output" 2> /dev/null || true
    }

    local use_find=true

    # Allow forcing find via MO_USE_FIND environment variable
    if [[ "${MO_USE_FIND:-0}" == "1" ]]; then
        debug_log "MO_USE_FIND=1: Forcing find instead of fd"
        use_find=true
    elif mole_purge_is_cloud_synced_path "$search_path" || mole_purge_is_cloud_synced_path "$walk_path"; then
        # Only find can skip online-only (dataless) directories, see below.
        use_find=true
    elif command -v fd > /dev/null 2>&1; then
        # Escape regex special characters in target names for fd patterns (single sed pass)
        local _escaped_lines
        _escaped_lines=$(printf '%s\n' "${PURGE_TARGETS[@]}" | sed -e 's/[][(){}.^$*+?|\\]/\\&/g')
        local pattern
        pattern="($(printf '%s\n' "$_escaped_lines" | sed -e 's/^/^/' -e 's/$/$/' | paste -sd '|' -))"
        local fd_args=(
            "--absolute-path"
            "--show-errors"
            "--hidden"
            "--no-ignore"
            "--type" "d"
            "--min-depth" "$min_depth"
            "--max-depth" "$max_depth"
            "--threads" "8"
            "--prune"
            "--exclude" ".git"
            "--exclude" "Library"
            "--exclude" ".Trash"
            "--exclude" "Applications"
        )
        local fd_tag_args=(
            "--absolute-path"
            "--show-errors"
            "--hidden"
            "--no-ignore"
            "--type" "f"
            "--min-depth" "$cachedir_tag_min_depth"
            "--max-depth" "$cachedir_tag_max_depth"
            "--threads" "8"
            "--exclude" ".git"
            "--exclude" "Library"
            "--exclude" ".Trash"
            "--exclude" "Applications"
        )
        local purge_target
        for purge_target in "${PURGE_TARGETS[@]}"; do
            fd_tag_args+=("--exclude" "$purge_target")
        done

        # fd can return zero after unreadable directories. Require both a
        # successful exit and no filesystem diagnostics before trusting output.
        # Empty scans are common in healthy project trees; falling back to find
        # doubles the scan cost and can make "nothing to clean" feel slow.
        local fd_status=0
        scan_stage_timeout=$(_mole_timeout_with_deadline "$scan_timeout" "$scan_deadline") || fd_status=$?
        if [[ $fd_status -eq 0 ]]; then
            # Only fd diagnostics may determine scan completeness; timeout
            # wrapper tracing must not look like a filesystem error in debug mode.
            MO_DEBUG=0 run_with_timeout "$scan_stage_timeout" fd "${fd_args[@]}" "$pattern" "$walk_path" \
                2> "$error_output" > "$target_output" || fd_status=$?
        fi
        if [[ $fd_status -eq 0 ]]; then
            scan_stage_timeout=$(_mole_timeout_with_deadline "$scan_timeout" "$scan_deadline") || fd_status=$?
        fi
        if [[ $fd_status -eq 0 ]]; then
            MO_DEBUG=0 run_with_timeout "$scan_stage_timeout" fd "${fd_tag_args[@]}" "^${MOLE_CACHEDIR_TAG_NAME}$" "$walk_path" \
                2>> "$error_output" > "$tag_output" || fd_status=$?
        fi
        if [[ $fd_status -eq 0 && -s "$error_output" ]]; then
            fd_status=1
            debug_log "fd reported filesystem errors; requiring a complete find scan"
        fi
        if [[ $fd_status -eq 0 ]]; then
            emit_valid_cachedir_tag_dirs "$scan_deadline" < "$tag_output" >> "$target_output" || fd_status=$?
        fi
        if [[ $fd_status -eq 0 ]]; then
            local filter_status=0
            process_scan_results "$target_output" "$scan_deadline" || filter_status=$?
            if [[ $filter_status -ne 0 ]]; then
                # Discovery completed. Repeating it cannot repair a failed
                # shared filter and would spend the remaining root budget twice.
                cleanup_scan_outputs
                : > "$output_file"
                debug_log "Purge result filtering failed (status $filter_status): $walk_path"
                return "$filter_status"
            fi
        fi
        if [[ $fd_status -eq 0 ]]; then
            debug_log "Using fd for scanning"
            cleanup_scan_outputs
            use_find=false
        elif [[ $fd_status -ge 128 ]]; then
            cleanup_scan_outputs
            return "$fd_status"
        else
            debug_log "fd scan failed (status $fd_status), falling back to find"
            cleanup_scan_outputs
            : > "$output_file"
        fi
    fi

    if [[ "$use_find" == "true" ]]; then
        # Pruned find avoids descending into heavy and online-only directories.
        local find_status=0
        scan_stage_timeout=$(_mole_timeout_with_deadline "$scan_timeout" "$scan_deadline") || find_status=$?
        if [[ $find_status -ne 0 ]]; then
            cleanup_scan_outputs
            debug_log "Purge discovery budget exhausted before find (status $find_status): $walk_path"
            return "$find_status"
        fi
        # An older find that does not know the flag name fails the whole walk,
        # so ask it once, after the budget check, and walk without the prune
        # when it does not.
        local dataless_rc=0 with_dataless=no
        _purge_find_knows_dataless || dataless_rc=$?
        if mole_rc_signal "$dataless_rc"; then
            cleanup_scan_outputs
            return "$dataless_rc"
        elif [[ $dataless_rc -eq 0 ]]; then
            with_dataless=yes
        fi
        _purge_walk_expressions "$with_dataless"
        local -a prune_expr=("${_PURGE_PRUNE_EXPR[@]}") target_expr=("${_PURGE_TARGET_EXPR[@]}")
        if [[ $find_status -eq 0 ]]; then
            debug_log "Using find for scanning"
            # One walk prints both target directories and CACHEDIR.TAG files.
            # It reaches the tag depth, and the split below keeps targets to
            # their own depth range, so coverage matches the two walks this
            # replaced. Prune rules now apply at depth 1 for tags too, so a tag
            # inside a top-level .git, Library or online-only folder is no
            # longer listed (#1666).
            run_with_timeout "$scan_stage_timeout" "$_MOLE_PURGE_FIND" "$walk_path" -mindepth "$min_depth" -maxdepth "$cachedir_tag_max_depth" \
                \( -type d \( "${prune_expr[@]}" \) \) -prune -o \
                \( "${target_expr[@]}" \) -print -prune -o \
                -type f -name "$MOLE_CACHEDIR_TAG_NAME" -print \
                2> /dev/null > "$walk_output" || find_status=$?
        fi
        if [[ $find_status -eq 0 ]]; then
            # shellcheck disable=SC2016 # Awk expands its own variables.
            WALK_BASE="${walk_path%/}" TAG_NAME="$MOLE_CACHEDIR_TAG_NAME" TARGET_OUT="$target_output" TAG_OUT="$tag_output" \
                awk -v target_max="$max_depth" -v tag_min="$cachedir_tag_min_depth" '
                    BEGIN {
                        base = ENVIRON["WALK_BASE"]; tag = ENVIRON["TAG_NAME"]
                        target_out = ENVIRON["TARGET_OUT"]; tag_out = ENVIRON["TAG_OUT"]
                        printf "" > target_out; printf "" > tag_out
                    }
                    {
                        if (substr($0, 1, length(base) + 1) != base "/") next
                        n = split(substr($0, length(base) + 2), parts, "/")
                        depth = 0
                        for (i = 1; i <= n; i++) if (parts[i] != "") { depth++; name = parts[i] }
                        if (name == tag) { if (depth >= tag_min) print > tag_out }
                        else if (depth <= target_max) print > target_out
                    }
                ' "$walk_output" || find_status=$?
        fi
        if [[ $find_status -eq 0 ]]; then
            emit_valid_cachedir_tag_dirs "$scan_deadline" < "$tag_output" >> "$target_output" || find_status=$?
        fi
        if [[ $find_status -eq 0 ]]; then
            local filter_status=0
            process_scan_results "$target_output" "$scan_deadline" || filter_status=$?
            if [[ $filter_status -ne 0 ]]; then
                cleanup_scan_outputs
                : > "$output_file"
                debug_log "Purge result filtering failed (status $filter_status): $walk_path"
                return "$filter_status"
            fi
        fi

        cleanup_scan_outputs
        if [[ $find_status -ne 0 ]]; then
            : > "$output_file"
            debug_log "find scan failed (status $find_status): $walk_path"
            return "$find_status"
        fi
    fi
}
# Filter out nested artifacts (e.g. node_modules inside node_modules, .build inside build).
# Optimized: Sort paths to put parents before children, then filter in single pass.
filter_nested_artifacts() {
    local timeout_seconds="${1:-}"
    # shellcheck disable=SC2016 # Awk expands its own variables.
    local nested_filter_program='
        BEGIN { last_kept = "" }
        {
            current = $0
            # If current path starts with last_kept, it is nested
            # Only check if last_kept is not empty
            if (last_kept == "" || index(current, last_kept) != 1) {
                print current
                last_kept = current
            }
        }
    '
    # shellcheck disable=SC2016 # The child shell expands its own positional parameters.
    local -a filter_command=(
        /bin/bash -o pipefail -c
        'sed "$1" | LC_COLLATE=C sort | awk "$2" | sed "$3"'
        _
        's|[^/]$|&/|'
        "$nested_filter_program"
        's|/$||'
    )

    # 1. Append trailing slash to each path (to ensure /foo/bar starts with /foo/)
    # 2. Sort to group parents and children (LC_COLLATE=C ensures standard sorting)
    # 3. Use awk to filter out paths that start with the previous kept path
    # 4. Remove trailing slash
    if [[ -n "$timeout_seconds" ]]; then
        run_with_timeout "$timeout_seconds" "${filter_command[@]}"
    else
        "${filter_command[@]}"
    fi
}

# Optional $2 collects the candidates this probe verified clean, so the review
# step can skip walking them a second time within the same run. Optional $3 is
# the scan sentinel; the filter stops with 130 once it has been removed.
# Probes run in a bounded pool, but results stay bound to each item's input
# position and are published in input order only after every probe finished.
filter_protected_artifacts() {
    local deadline="${1:-}"
    local verified_file="${2:-}"
    local cancel_file="${3:-}"
    local results=""
    if [[ -n "$verified_file" ]]; then
        results="${verified_file}.probes"
        : > "$results" 2> /dev/null || true
    else
        results=$(mktemp_file "mole-purge-probes") || return 1
    fi

    local max_probe_jobs
    max_probe_jobs=$(get_optimal_parallel_jobs io)
    if ! [[ "$max_probe_jobs" =~ ^[0-9]+$ ]] || [[ "$max_probe_jobs" -lt 1 ]]; then
        max_probe_jobs=1
    elif [[ "$max_probe_jobs" -gt 4 ]]; then
        max_probe_jobs=4
    fi

    local -a items=() probe_pids=()
    local item item_index probe_pid done_pid probe_slot wait_status stop_status=0
    while IFS= read -r item; do
        if [[ "$deadline" =~ ^[0-9]+$ && $SECONDS -ge $deadline ]]; then
            stop_status=124
            break
        fi
        if [[ -n "$cancel_file" && ! -f "$cancel_file" ]]; then
            stop_status=130
            break
        fi
        items+=("$item")
        item_index=$((${#items[@]} - 1))
        (
            probe_rc=0
            is_protected_purge_artifact "$item" "$deadline" || probe_rc=$?
            printf '%s %s %s\n' "$item_index" "$probe_rc" "$PURGE_PROTECTION_UNVERIFIED" >> "$results"
            [[ $probe_rc -le 128 ]] || exit "$probe_rc"
        ) < /dev/null &
        probe_pids+=("$!")
        if [[ ${#probe_pids[@]} -ge $max_probe_jobs ]]; then
            wait_status=0
            mole_wait_for_any_worker done_pid "${probe_pids[@]}" || wait_status=$?
            if [[ $wait_status -ge 128 ]]; then
                stop_status=$wait_status
                break
            fi
            for probe_slot in "${!probe_pids[@]}"; do
                if [[ "${probe_pids[$probe_slot]}" == "$done_pid" ]]; then
                    unset 'probe_pids[probe_slot]'
                    break
                fi
            done
        fi
    done
    if [[ $stop_status -ne 0 ]]; then
        for probe_pid in "${probe_pids[@]+"${probe_pids[@]}"}"; do
            kill "$probe_pid" 2> /dev/null || true
        done
    fi
    for probe_pid in "${probe_pids[@]+"${probe_pids[@]}"}"; do
        wait_status=0
        wait "$probe_pid" 2> /dev/null || wait_status=$?
        if [[ $stop_status -eq 0 && $wait_status -gt 128 ]]; then
            stop_status=$wait_status
        fi
    done
    # A scan cancelled while its last probes ran has already had its sidecars
    # removed; publishing now would recreate them.
    if [[ $stop_status -eq 0 && ${#items[@]} -gt 0 && -n "$cancel_file" && ! -f "$cancel_file" ]]; then
        stop_status=130
    fi
    # The last probe can consume the remaining budget too. Never publish
    # that root's prefix as complete, even when there is no next item.
    if [[ $stop_status -eq 0 && "$deadline" =~ ^[0-9]+$ && $SECONDS -ge $deadline ]]; then
        stop_status=124
    fi
    if [[ $stop_status -ne 0 ]]; then
        rm -f "$results" 2> /dev/null || true # SAFE: exact probe result scratch file owned by this filter
        return "$stop_status"
    fi

    local -a probe_rcs=() probe_unverified=()
    local record_index record_rc record_unverified record_extra
    if [[ -r "$results" ]]; then
        while read -r record_index record_rc record_unverified record_extra; do
            [[ "$record_index" =~ ^[0-9]+$ && "$record_rc" =~ ^[0-9]+$ && -z "$record_extra" ]] || continue
            [[ "$record_unverified" == "true" || "$record_unverified" == "false" ]] || continue
            probe_rcs[record_index]="$record_rc"
            probe_unverified[record_index]="$record_unverified"
        done < "$results"
    fi
    rm -f "$results" 2> /dev/null || true # SAFE: exact probe result scratch file owned by this filter

    for ((item_index = 0; item_index < ${#items[@]}; item_index++)); do
        item="${items[$item_index]}"
        record_rc="${probe_rcs[$item_index]:-}"
        # An unfinished probe or a missing record is not evidence either way.
        # Keep the candidate visible; the in-process recheck before the menu
        # reports it.
        if [[ -z "$record_rc" || "$record_rc" != "0" || "${probe_unverified[$item_index]:-true}" == "true" ]]; then
            echo "$item"
        fi
        if [[ -n "$verified_file" && -n "$record_rc" && "$record_rc" != "0" ]]; then
            # A lost record only costs the review a second walk.
            printf '%s\n' "$item" >> "$verified_file" 2> /dev/null || true
        fi
    done
}
# Args: $1 - path, $2 - optional current epoch
# Classify artifact activity as recent, old, or uncertain. Only a complete
# bounded scan may return old; timeouts and read failures fail closed.
# _PURGE_ACTIVITY_MTIME keeps the artifact mtime it read, for the age label.
classify_purge_activity() {
    local path="$1"
    local current_time="${2:-}"
    local age_days=$MIN_AGE_DAYS
    _PURGE_ACTIVITY_STATE="uncertain"
    _PURGE_ACTIVITY_MTIME=""

    if [[ ! -e "$path" ]]; then
        _PURGE_ACTIVITY_STATE="old"
        return 0
    fi

    local mod_time
    mod_time=$(get_file_mtime "$path" 2> /dev/null || true)
    if [[ ! "$mod_time" =~ ^[0-9]+$ ]]; then
        debug_log "Unable to read purge activity timestamp: $path"
        return 0
    fi
    _PURGE_ACTIVITY_MTIME="$mod_time"
    if [[ -z "$current_time" || ! "$current_time" =~ ^[0-9]+$ ]]; then
        current_time=$(get_epoch_seconds)
    fi

    local age_seconds=$((current_time - mod_time))
    local age_in_days=$((age_seconds / 86400))
    if [[ $age_in_days -lt $age_days ]]; then
        _PURGE_ACTIVITY_STATE="recent"
        return 0
    fi

    if [[ ! -d "$path" ]]; then
        _PURGE_ACTIVITY_STATE="old"
        return 0
    fi

    local probe_timeout="${MO_PURGE_ACTIVITY_TIMEOUT_SEC:-$MOLE_TIMEOUT_MEDIUM_PROBE_SEC}"
    if [[ ! "$probe_timeout" =~ ^[1-9][0-9]*$ ]]; then
        probe_timeout="$MOLE_TIMEOUT_MEDIUM_PROBE_SEC"
    fi

    # clean_project_artifacts sets one deadline for the whole classification
    # pass. A standalone caller still gets the per-item ceiling above.
    if [[ "${_PURGE_ACTIVITY_DEADLINE_EPOCH:-}" =~ ^[0-9]+$ ]]; then
        local now_epoch remaining
        now_epoch=$(get_epoch_seconds)
        remaining=$((_PURGE_ACTIVITY_DEADLINE_EPOCH - now_epoch))
        if [[ $remaining -le 0 ]]; then
            debug_log "Purge activity scan budget exhausted before: $path"
            return 0
        fi
        if [[ $probe_timeout -gt $remaining ]]; then
            probe_timeout=$remaining
        fi
    fi

    local recent_file=""
    local probe_status=0
    recent_file=$(run_with_timeout "$probe_timeout" \
        find "$path" -type f -mtime "-$age_days" -print -quit 2> /dev/null) || probe_status=$?

    if [[ $probe_status -ne 0 ]]; then
        debug_log "Purge activity scan failed closed (exit $probe_status): $path"
        if mole_rc_timeout_or_signal "$probe_status"; then
            return "$probe_status"
        fi
        return 0
    fi
    if [[ -n "$recent_file" ]]; then
        _PURGE_ACTIVITY_STATE="recent"
    else
        _PURGE_ACTIVITY_STATE="old"
    fi
}

# Args: $1 - path, $2 - optional current epoch
# Return 0 for protected, 1 for old, or preserve timeout/signal status.
is_recently_modified() {
    classify_purge_activity "$@" || return $?
    [[ "$_PURGE_ACTIVITY_STATE" != "old" ]]
}

# An artifact that was old when the menu opened can become active before the
# user confirms deletion. Recheck only those default-safe rows; a user who
# explicitly selected an already-recent row has already overridden that hint.
purge_target_activity_still_safe() {
    local path="$1"
    local reviewed_state="${2:-recent}"
    # A known-recent row may be explicitly selected. Unknown probe state is
    # never an override: it must be resolved successfully before deletion.
    [[ "$reviewed_state" == "true" || "$reviewed_state" == "recent" ]] && return 0

    # Do not inherit the menu pass's expired shared deadline.
    local _PURGE_ACTIVITY_DEADLINE_EPOCH=""
    local activity_status=0
    is_recently_modified "$path" "$(get_epoch_seconds)" || activity_status=$?
    [[ $activity_status -eq 1 ]] && return 0
    if mole_rc_timeout_or_signal "$activity_status"; then
        return "$activity_status"
    fi
    return 1
}

# Final safe_remove hook for purge. The caller supplies the exact scan-root and
# candidate identities through dynamically scoped locals. Recheck them after
# the stateful activity probe so no filesystem walk separates identity proof
# from safe_remove's deletion sink.
_mole_purge_final_remove_guard() {
    local path="$1"
    is_safe_configured_purge_artifact "$path" || return 1
    local protection_rc=0
    is_protected_purge_artifact "$path" || protection_rc=$?
    [[ $protection_rc -le 128 ]] || return "$protection_rc"
    [[ $protection_rc -ne 0 ]] || return 1
    purge_target_activity_still_safe "$path" "${_MOLE_PURGE_FINAL_ACTIVITY_STATE:-uncertain}" || return $?

    _mole_path_matches_identity \
        "${_MOLE_PURGE_FINAL_SCAN_ROOT:-}" \
        "${_MOLE_PURGE_FINAL_SCAN_ROOT_PARENT:-}" \
        "${_MOLE_PURGE_FINAL_SCAN_ROOT_PARENT_ID:-}" \
        "${_MOLE_PURGE_FINAL_SCAN_ROOT_TARGET_ID:-}" || return 1
    _mole_path_matches_identity \
        "${_MOLE_PURGE_FINAL_SCAN_ROOT_PHYSICAL:-}" \
        "${_MOLE_PURGE_FINAL_SCAN_ROOT_PHYSICAL_PARENT:-}" \
        "${_MOLE_PURGE_FINAL_SCAN_ROOT_PHYSICAL_PARENT_ID:-}" \
        "${_MOLE_PURGE_FINAL_SCAN_ROOT_PHYSICAL_TARGET_ID:-}" || return 1
    _mole_path_matches_identity \
        "$path" \
        "${_MOLE_PURGE_FINAL_EXPECTED_PARENT:-}" \
        "${_MOLE_PURGE_FINAL_EXPECTED_PARENT_ID:-}" \
        "${_MOLE_PURGE_FINAL_EXPECTED_TARGET_ID:-}" || return 1

    local current_physical_path="${_MOLE_PATH_SNAPSHOT_PARENT%/}/${path##*/}"
    [[ "$_MOLE_PATH_SNAPSHOT_PARENT" == "/" ]] && current_physical_path="/${path##*/}"
    is_safe_project_artifact_under_root \
        "$current_physical_path" "${_MOLE_PURGE_FINAL_SCAN_ROOT_PHYSICAL:-}"
}

# Args: $1 - path, $2 - optional shared deadline in SECONDS
# Get directory size in KB.
get_dir_size_kb() {
    local path="$1"
    local deadline="${2:-}"
    if [[ ! -d "$path" ]]; then
        echo "0"
        return
    fi

    local timeout_seconds="${MO_PURGE_SIZE_TIMEOUT_SEC:-15}"
    if [[ ! "$timeout_seconds" =~ ^[0-9]+([.][0-9]+)?$ ]]; then
        timeout_seconds=15
    fi
    if [[ -n "$deadline" ]]; then
        timeout_seconds=$(_mole_timeout_with_deadline "$timeout_seconds" "$deadline") || {
            debug_log "Size calculation budget exhausted before: $path"
            echo "TIMEOUT"
            return
        }
    fi

    local du_output=""
    local du_exit=0
    local du_tmp
    du_tmp=$(mktemp)
    if run_with_timeout "$timeout_seconds" du -skP "$path" > "$du_tmp" 2> /dev/null; then
        du_output=$(cat "$du_tmp")
    else
        du_exit=$?
    fi
    rm -f "$du_tmp"

    if mole_rc_timeout "$du_exit"; then
        debug_log "Size calculation timed out (${timeout_seconds}s): $path"
        echo "TIMEOUT"
        return
    fi

    if [[ $du_exit -ne 0 ]]; then
        debug_log "Size calculation failed (exit $du_exit): $path"
        echo "ERROR"
        return
    fi

    local size_kb
    size_kb=$(printf '%s\n' "$du_output" | awk 'NR==1 {print $1; exit}')
    if [[ "$size_kb" =~ ^[0-9]+$ ]]; then
        echo "$size_kb"
    else
        debug_log "Size calculation returned invalid output: $path"
        echo "ERROR"
    fi
}

_mole_purge_size_budget_seconds() {
    mole_purge_timeout_budget_seconds "${1:-$MOLE_TIMEOUT_DISK_VERIFY_SEC}" 30
}

# Resolve the owning project for a purge artifact. Monorepo indicators take
# precedence so every artifact in one workspace shares the same identity.
find_purge_project_root_for_artifact() {
    local path="$1"
    local current_dir="${path%/*}"
    [[ -z "$current_dir" ]] && current_dir="/"
    local monorepo_root=""
    local project_root=""

    while [[ "$current_dir" != "/" && "$current_dir" != "$HOME" && -n "$current_dir" ]]; do
        if [[ -z "$monorepo_root" ]]; then
            for indicator in "${MONOREPO_INDICATORS[@]}"; do
                if [[ -e "$current_dir/$indicator" ]]; then
                    monorepo_root="$current_dir"
                    break
                fi
            done
        fi

        if [[ -z "$project_root" ]]; then
            for indicator in "${PROJECT_INDICATORS[@]}"; do
                if [[ -e "$current_dir/$indicator" ]]; then
                    project_root="$current_dir"
                    break
                fi
            done
        fi

        if [[ -n "$monorepo_root" ]]; then
            break
        fi

        local relative_to_home="${current_dir#"$HOME"}"
        local without_slashes="${relative_to_home//\//}"
        local depth=$((${#relative_to_home} - ${#without_slashes}))
        if [[ -n "$project_root" && $depth -lt 2 ]]; then
            break
        fi

        local parent="${current_dir%/*}"
        current_dir="${parent:-/}"
    done

    if [[ -n "$monorepo_root" ]]; then
        printf '%s\n' "$monorepo_root"
        return 0
    fi

    if [[ -n "$project_root" ]]; then
        printf '%s\n' "$project_root"
        return 0
    fi

    return 1
}

# Format one visible row from canonical menu data at the current terminal width.
# Width excludes the selector prefix and activity suffix; inputs contain no ANSI.
format_purge_display() {
    local project_path="$1" artifact="$2" size="$3" width="$4"
    if [[ $width -lt 30 ]]; then
        truncate_by_display_width "$artifact $size" "$width"
        return
    fi
    local artifact_width=$(((width - 13) / 2))
    [[ $artifact_width -gt 24 ]] && artifact_width=24
    local path_width=$((width - artifact_width - 13))
    local path_prefix=""
    if [[ "$project_path" == "[cloud] "* ]]; then
        path_prefix="[cloud] "
        project_path="${project_path#"[cloud] "}"
    fi
    local path
    local body_width=$((path_width - ${#path_prefix}))
    if [[ -n "$path_prefix" && $body_width -lt 4 ]]; then
        path=$(truncate_by_display_width "${path_prefix% }" "$path_width")
    else
        path="${path_prefix}$(compact_purge_menu_path "$project_path" "$body_width")"
    fi
    local padding=$((path_width - $(get_display_width "$path")))
    printf '%s%*s %9s | %s' "$path" "$padding" "" "$size" "$(truncate_by_display_width "$artifact" "$artifact_width")"
}

# Purge category selector.
select_purge_categories() {
    local LC_ALL=en_US.UTF-8
    local -a categories=("$@")
    local total_items=${#categories[@]}
    local clear_line=$'\r\033[2K'
    if [[ $total_items -eq 0 ]]; then
        return 1
    fi

    # Calculate items per page based on terminal height.
    _get_items_per_page() {
        local term_height=24
        if [[ -t 0 ]] || [[ -t 2 ]]; then
            term_height=$(stty size < /dev/tty 2> /dev/null | awk '{print $1}')
        fi
        if [[ -z "$term_height" || $term_height -le 0 ]]; then
            if command -v tput > /dev/null 2>&1; then
                term_height=$(tput lines 2> /dev/null || echo "24")
            else
                term_height=24
            fi
        fi
        # Title, footer context, full path, controls, and spacing. The project
        # context can use two lines on narrow terminals.
        local reserved=10
        local available=$((term_height - reserved))
        if [[ $available -lt 3 ]]; then
            echo 0
        elif [[ $available -gt 50 ]]; then
            echo 50
        else
            echo "$available"
        fi
    }

    local items_per_page=$(_get_items_per_page)
    local cursor_pos=0
    local top_index=0
    local search_query="" search_message=""
    local -a rendered_rows=()
    local rendered_width=0 menu_ready=true

    # Selection and group totals belong to the menu, keyed by canonical row index.
    local -a selected=() sizes=() recent_flags=() age_labels=()
    local -a group_starts=() group_ends=() row_groups=() group_sizes=() group_selected=() group_unknown=()
    local selected_size=0 selected_count=0 selected_unknown=0 group=-1
    local previous_project_id="" project_id=""
    IFS=',' read -r -a sizes <<< "${PURGE_CATEGORY_SIZES:-}"
    IFS=',' read -r -a recent_flags <<< "${PURGE_RECENT_CATEGORIES:-}"
    IFS=',' read -r -a age_labels <<< "${PURGE_AGE_LABELS:-}"
    for ((i = 0; i < total_items; i++)); do
        project_id="${PURGE_CATEGORY_PROJECT_IDS_ARRAY[i]:-}"
        if [[ $i -eq 0 || -z "$project_id" || "$project_id" != "$previous_project_id" ]]; then
            group=$((group + 1))
            group_starts[group]=$i
            group_sizes[group]=0
            group_selected[group]=0
            group_unknown[group]=false
        fi
        previous_project_id="$project_id"
        row_groups[i]=$group
        group_ends[group]=$i
        group_sizes[group]=$((group_sizes[group] + ${sizes[i]:-0}))
        if [[ "${PURGE_CATEGORY_SIZE_UNKNOWN_FLAGS_ARRAY[i]:-false}" == true ]]; then
            group_unknown[group]=true
        fi
        selected[i]=false
        if [[ "${recent_flags[i]:-false}" != true ]]; then
            selected[i]=true
            selected_count=$((selected_count + 1))
            selected_size=$((selected_size + ${sizes[i]:-0}))
            group_selected[group]=$((group_selected[group] + 1))
            if [[ "${PURGE_CATEGORY_SIZE_UNKNOWN_FLAGS_ARRAY[i]:-false}" == true ]]; then
                selected_unknown=$((selected_unknown + 1))
            fi
        fi
    done
    set_selected() {
        local index="$1" value="$2" delta=1
        [[ "${selected[index]}" != "$value" ]] || return 0
        [[ "$value" == true ]] || delta=-1
        selected[index]="$value"
        selected_count=$((selected_count + delta))
        selected_size=$((selected_size + delta * ${sizes[index]:-0}))
        local group_index="${row_groups[index]}"
        group_selected[group_index]=$((group_selected[group_index] + delta))
        if [[ "${PURGE_CATEGORY_SIZE_UNKNOWN_FLAGS_ARRAY[index]:-false}" == true ]]; then
            selected_unknown=$((selected_unknown + delta))
        fi
    }
    local original_stty=""
    local previous_exit_trap=""
    local previous_int_trap=""
    local previous_term_trap=""
    local terminal_restored=false
    if [[ -t 0 ]] && command -v stty > /dev/null 2>&1; then
        original_stty=$(stty -g 2> /dev/null || echo "")
    fi
    previous_exit_trap=$(trap -p EXIT || true)
    previous_int_trap=$(trap -p INT || true)
    previous_term_trap=$(trap -p TERM || true)
    # Terminal control functions
    restore_terminal() {
        # Avoid trap churn when restore is called repeatedly via RETURN/EXIT paths.
        if [[ "${terminal_restored:-false}" == "true" ]]; then
            return
        fi
        terminal_restored=true

        # Clear traps first to prevent re-entrant firing during eval below.
        trap - EXIT INT TERM

        # Restore terminal state before re-installing caller traps, so the
        # terminal is always usable even if a restored trap handler exits.
        show_cursor
        if [[ -n "${original_stty:-}" ]]; then
            stty "${original_stty}" 2> /dev/null || stty sane 2> /dev/null || true
        fi

        # Snapshot and clear saved traps before eval to prevent infinite
        # recursion if the restored handler triggers another signal.
        local _prev_exit="$previous_exit_trap"
        local _prev_int="$previous_int_trap"
        local _prev_term="$previous_term_trap"
        previous_exit_trap=""
        previous_int_trap=""
        previous_term_trap=""
        # eval: restore caller traps captured by $(trap -p)
        [[ -n "$_prev_exit" ]] && eval "$_prev_exit"
        [[ -n "$_prev_int" ]] && eval "$_prev_int"
        [[ -n "$_prev_term" ]] && eval "$_prev_term"
        return 0
    }
    # Prefixed because nested functions are global: a bare handle_interrupt()
    # would replace bin/purge.sh's handler, which its restored INT/TERM trap
    # calls by name for the rest of the purge run.
    # shellcheck disable=SC2329
    _purge_menu_handle_interrupt() {
        restore_terminal
        exit 130
    }
    _get_terminal_width() {
        local term_width=""
        if [[ -t 0 ]] || [[ -t 2 ]]; then
            term_width=$(stty size < /dev/tty 2> /dev/null | awk '{print $2}')
        fi
        if [[ ! "$term_width" =~ ^[1-9][0-9]*$ ]]; then
            term_width=$(tput cols 2> /dev/null || echo 80)
        fi
        [[ "$term_width" =~ ^[1-9][0-9]*$ ]] || term_width=80
        echo "$term_width"
    }
    draw_menu() {
        local focused_index=$((top_index + cursor_pos))
        items_per_page=$(_get_items_per_page)
        local _term_w
        _term_w=$(_get_terminal_width)
        menu_ready=true
        if [[ $_term_w -lt 30 || $items_per_page -eq 0 ]]; then
            menu_ready=false
            printf '\033[H%s%s\n%s%s\n\033[J' "$clear_line" "$(truncate_by_display_width "Resize to 30 columns, 13 rows" "$_term_w")" "$clear_line" "$(truncate_by_display_width "Q Quit" "$_term_w")"
            return 0
        fi
        if [[ $rendered_width -ne $_term_w ]]; then
            # Cache presentation only. Measured metadata is immutable while
            # this menu is open; every resize invalidates its rendered rows.
            rendered_rows=()
            rendered_width=$_term_w
        fi

        # Keep the same absolute artifact focused when the viewport changes.
        local max_top_index=$((total_items - items_per_page))
        [[ $max_top_index -lt 0 ]] && max_top_index=0
        [[ $top_index -gt $max_top_index ]] && top_index=$max_top_index
        [[ $top_index -lt 0 ]] && top_index=0
        if [[ $focused_index -lt $top_index ]]; then
            top_index=$focused_index
        elif [[ $focused_index -ge $((top_index + items_per_page)) ]]; then
            top_index=$((focused_index - items_per_page + 1))
        fi
        cursor_pos=$((focused_index - top_index))
        local visible_count=$((total_items - top_index))
        [[ $visible_count -gt $items_per_page ]] && visible_count=$items_per_page

        printf "\033[H"
        # Format selected size (stored in KB) using shared display rules.
        local selected_size_human
        selected_size_human=$(bytes_to_human_kb "$selected_size")
        [[ $selected_unknown -eq 0 ]] || selected_size_human+=" + $selected_unknown unmeasured"

        # Show position indicator if scrolling is needed
        local scroll_indicator=""
        if [[ $total_items -gt $items_per_page ]]; then
            local current_pos=$((top_index + cursor_pos + 1))
            scroll_indicator=" [${current_pos}/${total_items}]"
        fi

        printf "%s${PURPLE_BOLD}%s${NC}\n" "$clear_line" "$(truncate_by_display_width "Select Artifacts to Purge${scroll_indicator}" "$_term_w")"
        local subtitle="${selected_size_human}, ${selected_count} selected"
        if [[ -n "$search_message" ]]; then
            subtitle="$subtitle · $search_message"
        fi
        printf "%s${GRAY}%s${NC}\n" "$clear_line" "$(truncate_by_display_width "$subtitle" "$_term_w")"

        # Calculate visible range
        local end_index=$((top_index + visible_count))

        # Draw only visible items
        for ((i = top_index; i < end_index; i++)); do
            local checkbox="$ICON_EMPTY"
            [[ ${selected[i]} == true ]] && checkbox="$ICON_SOLID"
            local group_marker="─"
            local row_project_id="${PURGE_CATEGORY_PROJECT_IDS_ARRAY[i]:-}"
            if [[ -n "$row_project_id" ]]; then
                local previous_same_project=false
                local next_same_project=false
                if [[ $i -gt 0 && "${PURGE_CATEGORY_PROJECT_IDS_ARRAY[i - 1]:-}" == "$row_project_id" ]]; then
                    previous_same_project=true
                fi
                if [[ $i -lt $((total_items - 1)) && "${PURGE_CATEGORY_PROJECT_IDS_ARRAY[i + 1]:-}" == "$row_project_id" ]]; then
                    next_same_project=true
                fi
                if [[ "$previous_same_project" == "true" && "$next_same_project" == "true" ]]; then
                    group_marker="├"
                elif [[ "$next_same_project" == "true" ]]; then
                    group_marker="┌"
                elif [[ "$previous_same_project" == "true" ]]; then
                    group_marker="└"
                fi
            fi
            local recent_marker=""
            local _age="${age_labels[i]:-}"
            [[ -n "$_age" ]] && recent_marker=" ${GRAY}| ${_age}${NC}"
            if [[ -z "${rendered_rows[i]+set}" ]]; then
                local row_width=$((_term_w - 6))
                if [[ -n "$_age" ]]; then
                    row_width=$((row_width - ${#_age} - 3))
                fi
                [[ $row_width -lt 1 ]] && row_width=1
                local row_size="unknown"
                if [[ "${PURGE_CATEGORY_SIZE_UNKNOWN_FLAGS_ARRAY[i]:-false}" != "true" ]]; then
                    row_size=$(bytes_to_human_kb "${sizes[i]:-0}")
                fi
                rendered_rows[i]=$(format_purge_display "${PURGE_CATEGORY_PROJECT_PATHS_ARRAY[i]:-}" "${categories[i]}" "$row_size" "$row_width")
            fi
            local row="${rendered_rows[i]}"
            local rel_pos=$((i - top_index))
            if [[ $rel_pos -eq $cursor_pos ]]; then
                printf "%s${CYAN}${ICON_ARROW} %s %s %s%s${NC}\n" "$clear_line" "$checkbox" "$group_marker" "$row" "$recent_marker"
            else
                printf "%s  %s %s %s%s\n" "$clear_line" "$checkbox" "$group_marker" "$row" "$recent_marker"
            fi
        done

        # Keep one blank line between the list and footer tips.
        printf "%s\n" "$clear_line"

        local current_index=$((top_index + cursor_pos))
        local current_project_path="${PURGE_CATEGORY_PROJECT_PATHS_ARRAY[current_index]:-}"
        if [[ -n "$current_project_path" ]]; then
            local current_group="${row_groups[current_index]}"
            local group_size="${group_sizes[current_group]}"
            local group_item_count=$((group_ends[current_group] - group_starts[current_group] + 1))
            local group_selected_count="${group_selected[current_group]}"
            local group_has_unknown_size="${group_unknown[current_group]}"

            local group_size_label
            group_size_label=$(bytes_to_human_kb "$group_size")
            if [[ "$group_has_unknown_size" == "true" ]]; then
                if [[ $group_size -gt 0 ]]; then
                    group_size_label="${group_size_label} + unknown"
                else
                    group_size_label="unknown size"
                fi
            fi

            local project_label="Project: "
            local project_summary=" · ${group_size_label} · ${group_selected_count}/${group_item_count} selected"
            local project_path_width=$((_term_w - ${#project_label} - ${#project_summary}))
            if [[ $project_path_width -ge 12 ]]; then
                printf "%s${GRAY}%s${NC}%s%s\n" "$clear_line" "$project_label" "$(compact_purge_menu_path "$current_project_path" "$project_path_width")" "$project_summary"
            else
                project_path_width=$((_term_w - ${#project_label}))
                [[ $project_path_width -lt 4 ]] && project_path_width=4
                printf "%s${GRAY}%s${NC}%s\n" "$clear_line" "$project_label" "$(compact_purge_menu_path "$current_project_path" "$project_path_width")"
                printf "%s${GRAY}%s${NC}\n" "$clear_line" "$(truncate_by_display_width "Group: $group_size_label · $group_selected_count/$group_item_count selected" "$_term_w")"
            fi
        fi

        local current_full_path=""
        local paths_len="${#PURGE_CATEGORY_FULL_PATHS_ARRAY[@]}"
        if [[ "$paths_len" -gt 0 && "$current_index" -lt "$paths_len" ]]; then
            current_full_path="${PURGE_CATEGORY_FULL_PATHS_ARRAY[current_index]}"
        fi
        if [[ -n "$current_full_path" ]]; then
            printf "%s${GRAY}Path:${NC} %s\n" "$clear_line" "$(compact_purge_menu_path "$current_full_path" "$((_term_w - 6))")"
            printf "%s\n" "$clear_line"
        fi

        # Adaptive footer hints, mirrors menu_paginated.sh pattern
        local _sep=" ${GRAY}|${NC} "
        local _nav="${GRAY}${ICON_NAV_UP}${ICON_NAV_DOWN} [] Projects / Find${NC}"
        local _space="${GRAY}Space Select${NC}"
        local _enter="${GRAY}Enter Confirm${NC}"
        local _all="${GRAY}A All${NC}"
        local _invert="${GRAY}I Invert${NC}"
        local _skip_project="${GRAY}X Skip Project${NC}"
        local _quit="${GRAY}Q Quit${NC}"

        # Strip ANSI to measure real length
        _ph_len() { printf "%s" "$1" | LC_ALL=C awk '{gsub(/\033\[[0-9;]*[A-Za-z]/,""); printf "%d", length}'; }

        # Level 0 (full): ↑↓ | Space Select | Enter Confirm | A All | I Invert | X Skip Project | Q Quit
        local _full="${_nav}${_sep}${_space}${_sep}${_enter}${_sep}${_all}${_sep}${_invert}${_sep}${_skip_project}${_sep}${_quit}"
        if (($(_ph_len "$_full") <= _term_w)); then
            printf "%s${_full}${NC}\n" "$clear_line"
        else
            # Level 1: ↑↓ | Enter Confirm | A All | X Skip Project | Q Quit
            local _l1="${_nav}${_sep}${_enter}${_sep}${_all}${_sep}${_skip_project}${_sep}${_quit}"
            if (($(_ph_len "$_l1") <= _term_w)); then
                printf "%s${_l1}${NC}\n" "$clear_line"
            else
                # Level 2: keep the project action discoverable on narrow terminals.
                local _l2="${_nav}${_sep}${GRAY}Enter${NC}${_sep}${_skip_project}${_sep}${_quit}"
                if (($(_ph_len "$_l2") <= _term_w)); then
                    printf "%s${_l2}${NC}\n" "$clear_line"
                else
                    # Level 3 (minimal): ↑↓ | Enter | X Skip | Q
                    printf "%s${GRAY}${ICON_NAV_UP}${ICON_NAV_DOWN}${NC}${_sep}${GRAY}Enter${NC}${_sep}${GRAY}X Skip${NC}${_sep}${GRAY}Q${NC}\n" "$clear_line"
                fi
            fi
        fi

        # Clear stale content below the footer when list height shrinks.
        printf '\033[J'
    }
    focus_item() {
        local target="$1"
        [[ $target -lt 0 ]] && target=0
        [[ $target -ge $total_items ]] && target=$((total_items - 1))
        cursor_pos=$((target - top_index))
    }
    move_project() {
        local current_index=$((top_index + cursor_pos))
        local target_group="${row_groups[current_index]}"
        if [[ "$1" == next ]]; then
            target_group=$((target_group + 1))
        else
            target_group=$((target_group - 1))
        fi
        if [[ $target_group -ge 0 && $target_group -lt ${#group_starts[@]} ]]; then
            focus_item "${group_starts[target_group]}"
        fi
    }
    find_next_match() {
        [[ -n "$search_query" ]] || return 0
        local start="$1" offset index match=-1 case_was_enabled=false
        shopt -q nocasematch && case_was_enabled=true
        shopt -s nocasematch
        for ((offset = 0; offset < total_items; offset++)); do
            index=$(((start + offset) % total_items))
            if [[ "${PURGE_CATEGORY_PROJECT_PATHS_ARRAY[index]:-} ${categories[index]}" == *"$search_query"* ]]; then
                match=$index
                break
            fi
        done
        [[ "$case_was_enabled" == true ]] || shopt -u nocasematch
        if [[ $match -ge 0 ]]; then
            focus_item "$match"
            search_message="n: next match"
        else
            search_message="No match: $search_query"
        fi
    }
    trap restore_terminal EXIT
    trap _purge_menu_handle_interrupt INT TERM
    # Preserve interrupt character for Ctrl-C
    stty -echo -icanon intr ^C 2> /dev/null || true
    hide_cursor
    if [[ -t 1 ]]; then
        clear_screen
    fi
    # Main loop
    while true; do
        draw_menu
        local key
        key=$(read_key)
        if [[ "$menu_ready" != true && "$key" != QUIT ]]; then
            continue
        fi
        case "$key" in
            CHAR:/)
                # Readline owns text editing and multibyte input. A byte-at-a-time
                # key loop on Bash 3.2 cannot safely edit Unicode project names.
                if ! IFS= read -e -r -p "Find project/artifact: " search_query; then
                    restore_terminal
                    return 1
                fi
                find_next_match 0
                ;;
            CHAR:n | CHAR:N) find_next_match "$((top_index + cursor_pos + 1))" ;;
            UP) focus_item "$((top_index + cursor_pos - 1))" ;;
            DOWN) focus_item "$((top_index + cursor_pos + 1))" ;;
            LEFT) focus_item "$((top_index + cursor_pos - items_per_page))" ;;
            RIGHT) focus_item "$((top_index + cursor_pos + items_per_page))" ;;
            TOP) focus_item 0 ;;
            BOTTOM) focus_item "$((total_items - 1))" ;;
            'CHAR:[') move_project previous ;;
            'CHAR:]') move_project next ;;
            SPACE) # Space - toggle current item
                local idx=$((top_index + cursor_pos))
                if [[ ${selected[idx]} == true ]]; then
                    set_selected "$idx" false
                else
                    set_selected "$idx" true
                fi
                ;;
            CHAR:a | CHAR:A) # Select all
                for ((i = 0; i < total_items; i++)); do
                    set_selected "$i" true
                done
                ;;
            CHAR:i | CHAR:I) # Invert selection
                for ((i = 0; i < total_items; i++)); do
                    if [[ ${selected[i]} == true ]]; then
                        set_selected "$i" false
                    else
                        set_selected "$i" true
                    fi
                done
                ;;
            CHAR:x | CHAR:X) # Deselect the current artifact's exact project
                local current_index=$((top_index + cursor_pos))
                local current_group="${row_groups[current_index]}"
                for ((i = group_starts[current_group]; i <= group_ends[current_group]; i++)); do
                    set_selected "$i" false
                done
                move_project next
                ;;
            QUIT) # Quit, Ctrl-C, or closed input
                restore_terminal
                return 1
                ;;
            ENTER) # Enter - confirm
                # A resize can happen while read_key is waiting. Check again
                # before accepting input from a now-unreadable viewport.
                local confirm_width
                confirm_width=$(tput cols 2> /dev/null || echo 80)
                [[ "$confirm_width" =~ ^[1-9][0-9]*$ ]] || confirm_width=80
                if [[ $confirm_width -lt 30 || $(_get_items_per_page) -eq 0 ]]; then
                    continue
                fi
                # Build result
                PURGE_SELECTION_RESULT=""
                for ((i = 0; i < total_items; i++)); do
                    if [[ ${selected[i]} == true ]]; then
                        [[ -n "$PURGE_SELECTION_RESULT" ]] && PURGE_SELECTION_RESULT+=","
                        PURGE_SELECTION_RESULT+="$i"
                    fi
                done
                restore_terminal
                return 0
                ;;
        esac
    done
}

# Final confirmation before deleting selected purge artifacts.
confirm_purge_cleanup() {
    local item_count="${1:-0}"
    local total_size_kb="${2:-0}"
    local unknown_count="${3:-0}"
    local cloud_count="${4:-0}"
    local -a selected_paths=("${@:5}")

    [[ "$item_count" =~ ^[0-9]+$ ]] || item_count=0
    [[ "$total_size_kb" =~ ^[0-9]+$ ]] || total_size_kb=0
    [[ "$unknown_count" =~ ^[0-9]+$ ]] || unknown_count=0
    [[ "$cloud_count" =~ ^[0-9]+$ ]] || cloud_count=0

    local item_text="artifact"
    [[ $item_count -ne 1 ]] && item_text="artifacts"

    local size_display
    size_display=$(bytes_to_human "$((total_size_kb * 1024))")

    local unknown_hint=""
    if [[ $unknown_count -gt 0 ]]; then
        local unknown_text="unknown size"
        [[ $unknown_count -gt 1 ]] && unknown_text="unknown sizes"
        unknown_hint=", ${unknown_count} ${unknown_text}"
    fi

    if [[ ${#selected_paths[@]} -gt 0 ]]; then
        echo ""
        echo -e "${GRAY}Selected paths:${NC}"
        local selected_path=""
        for selected_path in "${selected_paths[@]}"; do
            echo "  $selected_path"
        done
    fi

    if [[ $cloud_count -gt 0 ]]; then
        echo ""
        echo -e "${YELLOW}${ICON_WARNING}${NC} Cloud-synced artifacts may also be removed from other devices."
        echo -e "${GRAY}Use 'mo purge --paths' to exclude cloud storage roots.${NC}"
    fi

    echo -ne "${PURPLE}${ICON_ARROW}${NC} Remove ${item_count} ${item_text}, ${size_display}${unknown_hint}  ${GREEN}Enter${NC} confirm, ${GRAY}ESC${NC} cancel: "
    drain_pending_input
    local key=""
    if ! IFS= read -r -s -n1 key; then
        echo ""
        return 1
    fi
    drain_pending_input

    case "$key" in
        "" | $'\n' | $'\r' | y | Y)
            echo ""
            return 0
            ;;
        *)
            echo ""
            return 1
            ;;
    esac
}

# Main cleanup function - scans and prompts user to select artifacts to clean.
# Normal outcomes return zero; the command renders the outcome and maps incomplete
# work to failure. Signals and deletion-phase timeouts stop the run immediately.
# PURGE_RUN_OUTCOME: completed, incomplete, no_candidates, cancelled, scan_failed.
clean_project_artifacts() {
    if [[ ! -t 0 && "${MOLE_DRY_RUN:-0}" != "1" && "${MOLE_PURGE_YES:-0}" != "1" ]]; then
        PURGE_RUN_OUTCOME="cancelled"
        echo "Purge requires confirmation. Run mo purge in a terminal, or use --dry-run to preview and --yes to confirm unattended cleanup." >&2
        return 1
    fi
    PURGE_RUN_OUTCOME="completed"
    [[ ${PURGE_DISCOVERY_STATUS:-0} -eq 0 ]] || PURGE_RUN_OUTCOME="incomplete"
    PURGE_UNKNOWN_SIZE_COUNT=0
    local -a all_found_items=()
    local -a safe_to_clean=()
    local -a uninspected_paths=()
    local -a safe_recent_flags=()
    local -a safe_activity_states=()
    local -a safe_activity_mtimes=()
    local -a safe_expected_parents=()
    local -a safe_expected_parent_ids=()
    local -a safe_expected_target_ids=()
    local -a safe_scan_root_indexes=()
    local previous_int_trap=""
    local previous_term_trap=""
    local trap_installed_by_this_call=false
    # Set up cleanup on interrupt
    # Note: Declared without 'local' so cleanup_scan trap can access them
    scan_pids=()
    scan_temps=()
    scan_roots=()
    _cleanup_scan_done=false
    # shellcheck disable=SC2329
    cleanup_scan() {
        [[ "$_cleanup_scan_done" == "true" ]] && return
        _cleanup_scan_done=true
        # Kill all background scans
        for pid in "${scan_pids[@]+"${scan_pids[@]}"}"; do
            kill "$pid" 2> /dev/null || true
        done
        for pid in "${scan_pids[@]+"${scan_pids[@]}"}"; do
            wait "$pid" 2> /dev/null || true
        done
        scan_pids=()
        # Clean up temp files
        for temp in "${scan_temps[@]+"${scan_temps[@]}"}"; do
            rm -f "$temp" "${temp}.targets" "${temp}.tags" "${temp}.walk" "${temp}.processed" "${temp}.errors" \
                "${temp}.verified" "${temp}.verified.probes" 2> /dev/null || true
        done
        # Clean up purge scanning file
        local stats_dir="${XDG_CACHE_HOME:-$HOME/.cache}/mactools/mole"
        rm -f "$stats_dir/purge_scanning" 2> /dev/null || true
        echo ""
        exit 130
    }
    # Save caller traps and install local cleanup trap for this function call.
    previous_int_trap=$(trap -p INT || true)
    previous_term_trap=$(trap -p TERM || true)
    trap cleanup_scan INT TERM
    trap_installed_by_this_call=true
    _restore_purge_scan_traps() {
        [[ "$trap_installed_by_this_call" == "true" ]] || return 0
        trap - INT TERM
        trap_installed_by_this_call=false
        local saved_int_trap="$previous_int_trap"
        local saved_term_trap="$previous_term_trap"
        previous_int_trap=""
        previous_term_trap=""
        # eval: restore caller traps captured by $(trap -p)
        [[ -n "$saved_int_trap" ]] && eval "$saved_int_trap"
        [[ -n "$saved_term_trap" ]] && eval "$saved_term_trap"
        return 0
    }
    local -a scan_statuses=()
    local -a scan_root_parents=()
    local -a scan_root_parent_ids=()
    local -a scan_root_target_ids=()
    local -a scan_root_physical_paths=()
    local -a scan_root_physical_parents=()
    local -a scan_root_physical_parent_ids=()
    local -a scan_root_physical_target_ids=()
    local -a failed_scan_roots=()
    local -a failed_scan_statuses=()
    local failed_scan_count=0
    local scan_interrupt_status=0
    local max_scan_jobs
    max_scan_jobs=$(get_optimal_parallel_jobs io)
    if ! [[ "$max_scan_jobs" =~ ^[0-9]+$ ]] || [[ "$max_scan_jobs" -lt 1 ]]; then
        max_scan_jobs=1
    elif [[ "$max_scan_jobs" -gt 4 ]]; then
        max_scan_jobs=4
    fi

    local -a active_scan_indexes=()
    _reap_purge_scans() {
        local wait_for_completion="${1:-true}"
        local slot pid status finished unit_index
        while [[ ${#scan_pids[@]} -gt 0 ]]; do
            local -a running_pids=() running_indexes=()
            finished=false
            for ((slot = 0; slot < ${#scan_pids[@]}; slot++)); do
                pid="${scan_pids[slot]}"
                if kill -0 "$pid" 2> /dev/null; then
                    running_pids+=("$pid")
                    running_indexes+=("${active_scan_indexes[slot]}")
                    continue
                fi
                status=0
                wait "$pid" 2> /dev/null || status=$?
                unit_index="${active_scan_indexes[slot]}"
                unit_statuses[unit_index]=$status
                finished=true
                if [[ $status -ge 128 ]]; then
                    local peer
                    for peer in "${scan_pids[@]}"; do
                        kill "$peer" 2> /dev/null || true
                    done
                    for peer in "${scan_pids[@]}"; do
                        wait "$peer" 2> /dev/null || true
                    done
                    scan_pids=()
                    active_scan_indexes=()
                    return "$status"
                fi
            done
            scan_pids=("${running_pids[@]+"${running_pids[@]}"}")
            active_scan_indexes=("${running_indexes[@]+"${running_indexes[@]}"}")
            [[ "$finished" == true || "$wait_for_completion" == false ]] && return 0
            sleep 0.05
        done
        return 0
    }

    # Every root is scanned first as one unit, exactly as before. Only a root
    # that is not itself a project and whose single scan timed out is scanned
    # again, one direct child at a time (_purge_list_scan_units), each child
    # with its own MO_PURGE_SCAN_TIMEOUT_SEC budget, so one slow project skips
    # only itself (#1666). The re-scan is capped at that budget times the scan
    # slots; a child that cannot start before the cap is reported as skipped
    # by its own path. A root that completes keeps its speed and its output.
    local -a unit_paths=() unit_root_indexes=() unit_statuses=() unit_temps=() unit_superseded=()
    local scan_unit_timeout
    scan_unit_timeout=$(_purge_scan_timeout_seconds)
    local expanded_root_cap=$((scan_unit_timeout * max_scan_jobs))

    # Start one unit in a free pool slot. Unit indexes remain stable regardless
    # of completion order, so incomplete output cannot acquire another unit's status.
    _launch_purge_scan_unit() {
        local root_index="$1" path="$2" unit_path="$3" unit_timeout="$4"
        _reap_purge_scans false || return $?
        unit_paths+=("$unit_path")
        unit_root_indexes+=("$root_index")
        local unit_index=$((${#unit_paths[@]} - 1))
        unit_temps[unit_index]=""
        unit_superseded[unit_index]=false
        if [[ "$unit_timeout" -le 0 ]]; then
            unit_statuses[unit_index]=124
            debug_log "Purge scan root budget used up before this unit started: $unit_path"
            return 0
        fi
        local scan_output
        scan_output=$(mktemp)
        scan_temps+=("$scan_output")
        unit_temps[unit_index]="$scan_output"
        # Launch scan in background for true parallelism
        MO_PURGE_SCAN_TIMEOUT_SEC="$unit_timeout" \
            scan_purge_targets "$path" "$scan_output" "${scan_output}.verified" "$unit_path" < /dev/null &
        scan_pids+=("$!")
        active_scan_indexes+=("$unit_index")
        if [[ ${#scan_pids[@]} -ge $max_scan_jobs ]]; then
            _reap_purge_scans || return $?
        fi
        return 0
    }

    for path in "${PURGE_SEARCH_PATHS[@]}"; do
        _reap_purge_scans false || scan_interrupt_status=$?
        [[ $scan_interrupt_status -ge 128 ]] && break
        if [[ -d "$path" ]]; then
            if ! _mole_snapshot_path_identity "$path"; then
                failed_scan_count=$((failed_scan_count + 1))
                failed_scan_roots+=("$path")
                failed_scan_statuses+=("1")
                debug_log "Purge scan root identity unavailable: $path"
                continue
            fi
            local scan_root_parent="$_MOLE_PATH_SNAPSHOT_PARENT"
            local scan_root_parent_id="$_MOLE_PATH_SNAPSHOT_PARENT_ID"
            local scan_root_target_id="$_MOLE_PATH_SNAPSHOT_TARGET_ID"
            local scan_root_physical_path=""
            scan_root_physical_path=$(cd -P "$path" 2> /dev/null && pwd -P) || {
                failed_scan_count=$((failed_scan_count + 1))
                failed_scan_roots+=("$path")
                failed_scan_statuses+=("1")
                debug_log "Purge scan root physical path unavailable: $path"
                continue
            }
            if ! _mole_snapshot_path_identity "$scan_root_physical_path"; then
                failed_scan_count=$((failed_scan_count + 1))
                failed_scan_roots+=("$path")
                failed_scan_statuses+=("1")
                debug_log "Purge scan root physical identity unavailable: $path"
                continue
            fi
            scan_roots+=("$path")
            scan_root_parents+=("$scan_root_parent")
            scan_root_parent_ids+=("$scan_root_parent_id")
            scan_root_target_ids+=("$scan_root_target_id")
            scan_root_physical_paths+=("$scan_root_physical_path")
            scan_root_physical_parents+=("$_MOLE_PATH_SNAPSHOT_PARENT")
            scan_root_physical_parent_ids+=("$_MOLE_PATH_SNAPSHOT_PARENT_ID")
            scan_root_physical_target_ids+=("$_MOLE_PATH_SNAPSHOT_TARGET_ID")
            _launch_purge_scan_unit "$((${#scan_roots[@]} - 1))" "$path" "$path" "$scan_unit_timeout" ||
                scan_interrupt_status=$?
            [[ $scan_interrupt_status -ge 128 ]] && break
        fi
    done
    while [[ $scan_interrupt_status -lt 128 && ${#scan_pids[@]} -gt 0 ]]; do
        _reap_purge_scans || scan_interrupt_status=$?
    done

    # Fallback for roots whose single scan timed out. Its partial output is
    # discarded; only completed child units count.
    local first_pass_units=${#unit_paths[@]}
    local fallback_index
    for ((fallback_index = 0; fallback_index < first_pass_units; fallback_index++)); do
        [[ $scan_interrupt_status -lt 128 ]] || break
        mole_rc_timeout "${unit_statuses[$fallback_index]:-1}" || continue
        local fallback_root_index="${unit_root_indexes[$fallback_index]}"
        local fallback_root="${scan_roots[$fallback_root_index]}"
        local list_status=0
        _purge_list_scan_units "$fallback_root" || list_status=$?
        if [[ $list_status -ge 128 ]]; then
            scan_interrupt_status=$list_status
            break
        fi
        # A project root, or a root with no child to split into, keeps its
        # timeout and is reported as before.
        [[ ${#_PURGE_SCAN_UNITS[@]} -eq 1 && "${_PURGE_SCAN_UNITS[0]}" == "$fallback_root" ]] && continue
        local -a fallback_units=("${_PURGE_SCAN_UNITS[@]}")
        unit_superseded[fallback_index]=true
        debug_log "Purge scan root timed out, scanning its ${#fallback_units[@]} children separately: $fallback_root"
        local root_cap_deadline=$((SECONDS + expanded_root_cap))
        local unit_path
        for unit_path in "${fallback_units[@]}"; do
            local unit_timeout=$((root_cap_deadline - SECONDS))
            [[ $unit_timeout -le $scan_unit_timeout ]] || unit_timeout=$scan_unit_timeout
            _launch_purge_scan_unit "$fallback_root_index" "$fallback_root" "$unit_path" "$unit_timeout" ||
                scan_interrupt_status=$?
            [[ $scan_interrupt_status -ge 128 ]] && break
        done
    done
    while [[ $scan_interrupt_status -lt 128 && ${#scan_pids[@]} -gt 0 ]]; do
        _reap_purge_scans || scan_interrupt_status=$?
    done

    if [[ $scan_interrupt_status -ge 128 ]]; then
        # A root listing can be interrupted while earlier units still run;
        # stop them before their files are removed.
        local interrupted_pid
        for interrupted_pid in "${scan_pids[@]+"${scan_pids[@]}"}"; do
            kill "$interrupted_pid" 2> /dev/null || true
        done
        for interrupted_pid in "${scan_pids[@]+"${scan_pids[@]}"}"; do
            wait "$interrupted_pid" 2> /dev/null || true
        done
        scan_pids=()
        local interrupted_stats_dir="${XDG_CACHE_HOME:-$HOME/.cache}/mactools/mole"
        rm -f "$interrupted_stats_dir/purge_scanning" 2> /dev/null || true
        local interrupted_temp
        for interrupted_temp in "${scan_temps[@]+"${scan_temps[@]}"}"; do
            rm -f "$interrupted_temp" "${interrupted_temp}.targets" "${interrupted_temp}.tags" \
                "${interrupted_temp}.walk" "${interrupted_temp}.processed" "${interrupted_temp}.errors" \
                "${interrupted_temp}.verified" "${interrupted_temp}.verified.probes" 2> /dev/null || true
        done
        _restore_purge_scan_traps
        if [[ -t 1 ]]; then
            stop_inline_spinner
        fi
        return "$scan_interrupt_status"
    fi

    # Stop the scanning monitor (removes purge_scanning file to signal completion)
    local stats_dir="${XDG_CACHE_HOME:-$HOME/.cache}/mactools/mole"
    rm -f "$stats_dir/purge_scanning" 2> /dev/null || true

    # Give monitor process time to exit and clear its output
    if [[ -t 1 ]]; then
        sleep 0.2
    fi

    # Collect all results and deduplicate once. This avoids an O(N²) shell loop
    # when overlapping search roots produce the same artifact many times.
    local dedupe_output
    dedupe_output=$(mktemp_file "mole-purge-dedupe") || return 1
    # Candidates a completed discovery probe already found clean. The review
    # below walks only the rest: a repeat walk of every artifact tree was the
    # largest serial step of a purge, and deletion still rechecks each target.
    local discovery_verified=$'\n'
    local completed_scan_count=0
    local scan_index
    local -a root_changed=() root_completed=()
    for ((scan_index = 0; scan_index < ${#scan_roots[@]}; scan_index++)); do
        root_changed[scan_index]=false
        root_completed[scan_index]=false
        if ! _mole_path_matches_identity \
            "${scan_roots[$scan_index]}" \
            "${scan_root_parents[$scan_index]}" \
            "${scan_root_parent_ids[$scan_index]}" \
            "${scan_root_target_ids[$scan_index]}"; then
            root_changed[scan_index]=true
            debug_log "Purge scan root changed before results were collected: ${scan_roots[$scan_index]}"
        elif ! _mole_path_matches_identity \
            "${scan_root_physical_paths[$scan_index]}" \
            "${scan_root_physical_parents[$scan_index]}" \
            "${scan_root_physical_parent_ids[$scan_index]}" \
            "${scan_root_physical_target_ids[$scan_index]}"; then
            root_changed[scan_index]=true
            debug_log "Purge scan root target changed before results were collected: ${scan_roots[$scan_index]}"
        fi
    done
    # Only completed units count. A unit that failed or timed out is reported
    # by its own path and contributes nothing, not even a prefix.
    local unit_index
    for ((unit_index = 0; unit_index < ${#unit_paths[@]}; unit_index++)); do
        scan_index="${unit_root_indexes[$unit_index]}"
        scan_output="${unit_temps[$unit_index]:-}"
        local scan_status="${unit_statuses[$unit_index]:-1}"
        if [[ "${unit_superseded[$unit_index]:-false}" == "true" ]]; then
            scan_status=-1
        elif [[ "${root_changed[$scan_index]}" == "true" ]]; then
            scan_status=-1
        elif [[ $scan_status -eq 0 && (-z "$scan_output" || ! -f "$scan_output") ]]; then
            scan_status=1
        fi
        if [[ $scan_status -eq 0 ]]; then
            if cat "$scan_output" >> "$dedupe_output"; then
                completed_scan_count=$((completed_scan_count + 1))
                root_completed[scan_index]=true
                if [[ -s "${scan_output}.verified" ]]; then
                    local verified_item
                    while IFS= read -r verified_item; do
                        [[ -n "$verified_item" ]] && discovery_verified+="${verified_item}"$'\n'
                    done < "${scan_output}.verified"
                fi
            else
                scan_status=1
                debug_log "Purge scan output unreadable: ${unit_paths[$unit_index]}"
            fi
        fi
        if [[ $scan_status -gt 0 ]]; then
            failed_scan_count=$((failed_scan_count + 1))
            failed_scan_roots+=("${unit_paths[$unit_index]}")
            failed_scan_statuses+=("$scan_status")
            debug_log "Purge scan incomplete (status $scan_status): ${unit_paths[$unit_index]}"
        fi
        if [[ -n "$scan_output" ]]; then
            rm -f "$scan_output" "${scan_output}.targets" "${scan_output}.tags" "${scan_output}.walk" "${scan_output}.processed" \
                "${scan_output}.errors" "${scan_output}.verified" "${scan_output}.verified.probes" 2> /dev/null || true
        fi
    done
    # A root binds candidates only when it is unchanged and at least one of
    # its units completed. A changed root is reported once, by its own path.
    for ((scan_index = 0; scan_index < ${#scan_roots[@]}; scan_index++)); do
        scan_statuses[scan_index]=1
        if [[ "${root_changed[$scan_index]}" == "true" ]]; then
            failed_scan_count=$((failed_scan_count + 1))
            failed_scan_roots+=("${scan_roots[$scan_index]}")
            failed_scan_statuses+=("1")
        elif [[ "${root_completed[$scan_index]}" == "true" ]]; then
            scan_statuses[scan_index]=0
        fi
    done
    if [[ -s "$dedupe_output" ]]; then
        while IFS= read -r item; do
            [[ -n "$item" ]] && all_found_items+=("$item")
        done < <(LC_COLLATE=C sort -u "$dedupe_output")
    fi
    rm -f "$dedupe_output"
    # Restore caller traps after this function completes.
    _restore_purge_scan_traps
    if [[ $failed_scan_count -gt 0 ]]; then
        PURGE_RUN_OUTCOME="incomplete"
        local root_text="root"
        [[ $failed_scan_count -ne 1 ]] && root_text="roots"
        echo ""
        echo -e "${YELLOW}${ICON_WARNING}${NC} Skipped ${failed_scan_count} project scan ${root_text} because scanning did not complete:"
        # A root with thousands of children must not flood the screen; the
        # heading keeps the full count.
        local failed_shown_limit=10
        for ((scan_index = 0; scan_index < ${#failed_scan_roots[@]} && scan_index < failed_shown_limit; scan_index++)); do
            local display_root="${failed_scan_roots[$scan_index]/#$HOME/~}"
            echo -e "  ${GRAY}${display_root}${NC} (status ${failed_scan_statuses[$scan_index]:-1})"
        done
        if [[ ${#failed_scan_roots[@]} -gt $failed_shown_limit ]]; then
            echo -e "  ${GRAY}and $((${#failed_scan_roots[@]} - failed_shown_limit)) more${NC}"
        fi
        echo -e "${GRAY}Re-run with 'mo purge --debug' to inspect the scan failure.${NC}"
        if [[ $completed_scan_count -eq 0 ]]; then
            printf '\n'
            PURGE_RUN_OUTCOME="scan_failed"
            return 0
        fi
    fi
    if [[ ${#all_found_items[@]} -eq 0 ]]; then
        echo ""
        if [[ "$PURGE_RUN_OUTCOME" == "incomplete" ]]; then
            echo -e "${GRAY}No artifacts found in the completed project scans${NC}"
        else
            echo -e "${GREEN}${ICON_SUCCESS}${NC} Great! No old project artifacts to clean"
        fi
        printf '\n'
        [[ "$PURGE_RUN_OUTCOME" != "incomplete" ]] && PURGE_RUN_OUTCOME="no_candidates"
        return 0
    fi
    # Bind candidates before starting the activity evidence budget.
    if [[ -t 1 ]]; then
        start_inline_spinner "Preparing artifacts..."
    fi
    local candidate_index
    for ((candidate_index = 0; candidate_index < ${#all_found_items[@]}; candidate_index++)); do
        item="${all_found_items[$candidate_index]}"
        if is_path_whitelisted "$item"; then
            continue
        fi
        local candidate_bound=false
        local candidate_parent=""
        local candidate_parent_id=""
        local candidate_target_id=""
        local root_index
        local scan_root
        local -a candidate_root_indexes=()
        for ((root_index = 0; root_index < ${#scan_roots[@]}; root_index++)); do
            [[ ${scan_statuses[$root_index]:-1} -eq 0 ]] || continue
            scan_root="${scan_roots[$root_index]}"
            if [[ "$scan_root" == "/" || "$item" == "${scan_root%/}/"* ]]; then
                candidate_root_indexes+=("$root_index")
            fi
        done
        # A scan root may be a symlink while fd/find reports the physical path.
        # Fall back to the full physical containment check only for that rare
        # alias case; normal candidates stay on their lexical roots.
        if [[ ${#candidate_root_indexes[@]} -eq 0 ]]; then
            for ((root_index = 0; root_index < ${#scan_roots[@]}; root_index++)); do
                [[ ${scan_statuses[$root_index]:-1} -eq 0 ]] || continue
                candidate_root_indexes+=("$root_index")
            done
        fi
        if [[ ! -d "$item" || -L "$item" ]] || ! _mole_snapshot_path_identity "$item"; then
            continue
        fi
        candidate_parent="$_MOLE_PATH_SNAPSHOT_PARENT"
        candidate_parent_id="$_MOLE_PATH_SNAPSHOT_PARENT_ID"
        candidate_target_id="$_MOLE_PATH_SNAPSHOT_TARGET_ID"
        local candidate_physical_path="${candidate_parent%/}/${item##*/}"
        [[ "$candidate_parent" == "/" ]] && candidate_physical_path="/${item##*/}"
        local candidate_scan_root_index=-1
        # Root identities are rechecked once per root after this loop.
        for root_index in "${candidate_root_indexes[@]}"; do
            if ! is_safe_project_artifact_under_root \
                "$candidate_physical_path" "${scan_root_physical_paths[$root_index]}"; then
                continue
            fi
            candidate_scan_root_index="$root_index"
            candidate_bound=true
            break
        done
        if [[ "$candidate_bound" != "true" ]]; then
            debug_log "Skipping purge target whose scan identity changed: $item"
            continue
        fi
        local protection_rc=1
        if [[ "$discovery_verified" != *$'\n'"$item"$'\n'* ]]; then
            protection_rc=0
            is_protected_purge_artifact "$item" || protection_rc=$?
        fi
        if [[ $protection_rc -gt 128 ]]; then
            PURGE_RUN_OUTCOME="cancelled"
            if [[ -t 1 ]]; then stop_inline_spinner; fi
            return "$protection_rc"
        fi
        if [[ $protection_rc -eq 0 ]]; then
            if [[ "$PURGE_PROTECTION_UNVERIFIED" == "true" ]]; then
                PURGE_RUN_OUTCOME="incomplete"
                uninspected_paths+=("$item")
            else
                debug_log "Skipping purge target that became protected after scanning: $item"
            fi
            continue
        fi

        safe_to_clean+=("$item")
        safe_expected_parents+=("$candidate_parent")
        safe_expected_parent_ids+=("$candidate_parent_id")
        safe_expected_target_ids+=("$candidate_target_id")
        safe_scan_root_indexes+=("$candidate_scan_root_index")
    done
    if [[ -t 1 ]]; then
        stop_inline_spinner
    fi
    # Recheck each bound scan root once, after binding, and drop every
    # candidate of a root that changed. Deletion still rechecks the root and
    # the candidate identity at the final sink.
    if [[ ${#safe_to_clean[@]} -gt 0 ]]; then
        local -a bound_root_states=()
        local -a kept_items=() kept_parents=() kept_parent_ids=() kept_target_ids=() kept_root_indexes=()
        local bound_index
        for ((bound_index = 0; bound_index < ${#safe_to_clean[@]}; bound_index++)); do
            root_index="${safe_scan_root_indexes[$bound_index]}"
            if [[ -z "${bound_root_states[$root_index]:-}" ]]; then
                bound_root_states[root_index]=changed
                if _mole_path_matches_identity \
                    "${scan_roots[$root_index]}" \
                    "${scan_root_parents[$root_index]}" \
                    "${scan_root_parent_ids[$root_index]}" \
                    "${scan_root_target_ids[$root_index]}" &&
                    _mole_path_matches_identity \
                        "${scan_root_physical_paths[$root_index]}" \
                        "${scan_root_physical_parents[$root_index]}" \
                        "${scan_root_physical_parent_ids[$root_index]}" \
                        "${scan_root_physical_target_ids[$root_index]}"; then
                    bound_root_states[root_index]=same
                fi
            fi
            if [[ "${bound_root_states[$root_index]}" != "same" ]]; then
                debug_log "Skipping purge target whose scan identity changed: ${safe_to_clean[$bound_index]}"
                continue
            fi
            kept_items+=("${safe_to_clean[$bound_index]}")
            kept_parents+=("${safe_expected_parents[$bound_index]}")
            kept_parent_ids+=("${safe_expected_parent_ids[$bound_index]}")
            kept_target_ids+=("${safe_expected_target_ids[$bound_index]}")
            kept_root_indexes+=("$root_index")
        done
        safe_to_clean=("${kept_items[@]+"${kept_items[@]}"}")
        safe_expected_parents=("${kept_parents[@]+"${kept_parents[@]}"}")
        safe_expected_parent_ids=("${kept_parent_ids[@]+"${kept_parent_ids[@]}"}")
        safe_expected_target_ids=("${kept_target_ids[@]+"${kept_target_ids[@]}"}")
        safe_scan_root_indexes=("${kept_root_indexes[@]+"${kept_root_indexes[@]}"}")
    fi
    for item in "${uninspected_paths[@]+"${uninspected_paths[@]}"}"; do
        echo -e "${YELLOW}${ICON_WARNING}${NC} Could not inspect ${item/#$HOME/~}; kept" >&2
    done
    if [[ ${#safe_to_clean[@]} -eq 0 ]]; then
        echo -e "${GRAY}No eligible project artifacts to purge${NC}"
        [[ "$PURGE_RUN_OUTCOME" != "incomplete" ]] && PURGE_RUN_OUTCOME="no_candidates"
        return 0
    fi
    if [[ -t 1 ]]; then
        start_inline_spinner "Checking recent activity..."
    fi
    local _now_epoch
    _now_epoch=$(get_epoch_seconds)
    local _activity_total_timeout="${MO_PURGE_ACTIVITY_TOTAL_TIMEOUT_SEC:-$MOLE_TIMEOUT_HINT_SCAN_SEC}"
    if [[ ! "$_activity_total_timeout" =~ ^[1-9][0-9]*$ ]]; then
        _activity_total_timeout="$MOLE_TIMEOUT_HINT_SCAN_SEC"
    fi
    local _PURGE_ACTIVITY_DEADLINE_EPOCH=$((_now_epoch + _activity_total_timeout))
    # A few slow artifacts must not consume every later artifact's opportunity.
    # Reuse the discovery concurrency ceiling, while keeping the SAME shared
    # deadline and per-item classifier. Results stay indexed until all workers
    # finish; only a complete, successful old classification can preselect a row.
    local -a _activity_pids=() _activity_indexes=() _activity_tmpfiles=() _activity_worker_statuses=()
    local _activity_setup_failed=false
    local _activity_interrupt_status=0
    local _activity_previous_int_trap _activity_previous_term_trap
    _activity_previous_int_trap=$(trap -p INT || true)
    _activity_previous_term_trap=$(trap -p TERM || true)
    trap '[[ $_activity_interrupt_status -ge 128 ]] || _activity_interrupt_status=130' INT
    trap '[[ $_activity_interrupt_status -ge 128 ]] || _activity_interrupt_status=143' TERM
    _wait_purge_activity_batch() {
        local drain="${1:-true}" activity_pid worker_status slot finished
        while [[ ${#_activity_pids[@]} -gt 0 ]]; do
            local -a running_pids=() running_indexes=()
            finished=false
            for ((slot = 0; slot < ${#_activity_pids[@]}; slot++)); do
                activity_pid="${_activity_pids[$slot]}"
                if [[ $_activity_interrupt_status -lt 128 ]] && kill -0 "$activity_pid" 2> /dev/null; then
                    running_pids+=("$activity_pid")
                    running_indexes+=("${_activity_indexes[$slot]}")
                    continue
                fi
                worker_status=0
                wait "$activity_pid" 2> /dev/null || worker_status=$?
                if [[ $worker_status -ge 128 ]]; then
                    [[ $_activity_interrupt_status -ge 128 ]] || _activity_interrupt_status=$worker_status
                    # Interrupted wait can leave its bounded probe alive.
                    # Drain it instead of orphaning timeout/find children.
                    while kill -0 "$activity_pid" 2> /dev/null; do
                        wait "$activity_pid" 2> /dev/null || true
                    done
                fi
                _activity_worker_statuses[${_activity_indexes[$slot]}]=$worker_status
                finished=true
            done
            _activity_pids=("${running_pids[@]+"${running_pids[@]}"}")
            _activity_indexes=("${running_indexes[@]+"${running_indexes[@]}"}")
            if [[ "$drain" == false && "$finished" == true && $_activity_interrupt_status -lt 128 ]]; then
                return 0
            fi
            # The trap owns cancellation; interrupted sleep must not trigger
            # errexit before worker drain and caller-trap restoration.
            [[ ${#_activity_pids[@]} -eq 0 ]] || sleep 0.02 || true
        done
    }
    for item in "${safe_to_clean[@]}"; do
        [[ $_activity_interrupt_status -ge 128 ]] && break
        local activity_temp
        if ! activity_temp=$(mktemp); then
            _activity_setup_failed=true
            break
        fi
        register_temp_file "$activity_temp"
        _activity_tmpfiles+=("$activity_temp")
        (
            _PURGE_ACTIVITY_STATE="uncertain"
            _PURGE_ACTIVITY_MTIME=""
            activity_status=0
            is_recently_modified "$item" "$_now_epoch" || activity_status=$?
            [[ $activity_status -lt 128 ]] || exit "$activity_status"
            printf '%s %s %s\n' "$activity_status" "${_PURGE_ACTIVITY_STATE:-uncertain}" "${_PURGE_ACTIVITY_MTIME:--}" > "$activity_temp" || exit 1
            exit 0
        ) < /dev/null &
        _activity_pids+=("$!")
        _activity_indexes+=("$((${#_activity_tmpfiles[@]} - 1))")
        if [[ ${#_activity_pids[@]} -ge $max_scan_jobs ]]; then
            _wait_purge_activity_batch false
        fi
    done
    _wait_purge_activity_batch
    trap - INT TERM
    # eval: restore the caller traps captured before starting activity workers.
    [[ -z "$_activity_previous_int_trap" ]] || eval "$_activity_previous_int_trap"
    [[ -z "$_activity_previous_term_trap" ]] || eval "$_activity_previous_term_trap"
    if [[ $_activity_interrupt_status -ge 128 || "$_activity_setup_failed" == true ]]; then
        for activity_temp in "${_activity_tmpfiles[@]+"${_activity_tmpfiles[@]}"}"; do
            rm -f "$activity_temp" # SAFE: exact registered mktemp activity result file
        done
        if [[ $_activity_interrupt_status -lt 128 ]]; then
            PURGE_RUN_OUTCOME="incomplete"
            [[ ! -t 1 ]] || stop_inline_spinner
            return 1
        fi
        PURGE_RUN_OUTCOME="cancelled"
        [[ ! -t 1 ]] || stop_inline_spinner
        return "$_activity_interrupt_status"
    fi
    local activity_index=0
    for activity_temp in "${_activity_tmpfiles[@]}"; do
        local is_recent=true activity_status="" activity_state="uncertain" activity_mtime="" activity_extra=""
        # Only a complete record from a successful worker can preselect a row.
        # A truncated first field must never turn unknown evidence into old.
        if [[ "${_activity_worker_statuses[$activity_index]:-1}" == "0" ]] &&
            read -r activity_status activity_state activity_mtime activity_extra < "$activity_temp" &&
            [[ -n "$activity_mtime" && -z "$activity_extra" ]]; then
            if [[ "$activity_status" == "1" && "$activity_state" == "old" ]]; then
                is_recent=false
            elif [[ "$activity_status" != "0" || "$activity_state" != "recent" ]]; then
                activity_state="uncertain"
            fi
        else
            activity_state="uncertain"
            activity_mtime=""
        fi
        activity_index=$((activity_index + 1))
        safe_recent_flags+=("$is_recent")
        safe_activity_states+=("$activity_state")
        safe_activity_mtimes+=("$activity_mtime")
    done
    rm -f "${_activity_tmpfiles[@]+"${_activity_tmpfiles[@]}"}" 2> /dev/null || true # SAFE: exact registered mktemp activity result files
    if [[ -t 1 ]]; then
        stop_inline_spinner
    fi
    # Build menu options - one per artifact
    if [[ -t 1 ]]; then
        start_inline_spinner "Calculating sizes..."
    fi

    # Pre-compute sizes in parallel with sliding-window throttle.
    # Unbounded parallelism (all N at once) causes I/O contention on cold
    # filesystem cache, making du timeout and display "unknown" sizes.
    local -a _size_tmpfiles=()
    local -a _size_pids=()
    local _size_total_timeout
    _size_total_timeout=$(_mole_purge_size_budget_seconds "$MOLE_TIMEOUT_DISK_VERIFY_SEC")
    local _size_deadline=$((SECONDS + _size_total_timeout))
    local _max_size_jobs
    _max_size_jobs=$(get_optimal_parallel_jobs io)
    if ! [[ "$_max_size_jobs" =~ ^[0-9]+$ ]] || [[ "$_max_size_jobs" -lt 1 ]]; then
        _max_size_jobs=1
    elif [[ "$_max_size_jobs" -gt 8 ]]; then
        _max_size_jobs=8
    fi

    # Keep the sliding window full on Bash 3.2 as well as newer shells.
    _reap_one_size_pid() {
        local completed_pid="" size_slot worker_rc=0
        mole_wait_for_any_worker completed_pid "${_size_pids[@]}" || worker_rc=$?
        if [[ $worker_rc -ge 128 ]]; then
            [[ $_size_interrupt_status -ge 128 ]] || _size_interrupt_status=$worker_rc
            _cleanup_purge_size_workers
            return 0
        fi
        for size_slot in "${!_size_pids[@]}"; do
            if [[ "${_size_pids[$size_slot]}" == "$completed_pid" ]]; then
                unset '_size_pids[size_slot]'
                break
            fi
        done
    }

    local _size_previous_int_trap=""
    local _size_previous_term_trap=""
    local _size_interrupt_status=0
    local _size_traps_installed=false
    # shellcheck disable=SC2329 # Invoked by the signal trap below.
    _cleanup_purge_size_workers() {
        local size_pid
        for size_pid in "${_size_pids[@]+"${_size_pids[@]}"}"; do
            kill "$size_pid" 2> /dev/null || true
        done
        for size_pid in "${_size_pids[@]+"${_size_pids[@]}"}"; do
            wait "$size_pid" 2> /dev/null || true
        done
        _size_pids=()
    }
    # shellcheck disable=SC2329 # Invoked by the signal trap below.
    _handle_purge_size_interrupt() {
        local interrupt_status="$1"
        if [[ $_size_interrupt_status -lt 128 ]]; then
            _size_interrupt_status="$interrupt_status"
        fi
        _cleanup_purge_size_workers
    }
    _restore_purge_size_traps() {
        [[ "$_size_traps_installed" == "true" ]] || return 0
        trap - INT TERM
        _size_traps_installed=false
        local saved_int_trap="$_size_previous_int_trap"
        local saved_term_trap="$_size_previous_term_trap"
        _size_previous_int_trap=""
        _size_previous_term_trap=""
        # eval: restore caller traps captured by $(trap -p)
        [[ -n "$saved_int_trap" ]] && eval "$saved_int_trap"
        [[ -n "$saved_term_trap" ]] && eval "$saved_term_trap"
        return 0
    }

    _size_previous_int_trap=$(trap -p INT || true)
    _size_previous_term_trap=$(trap -p TERM || true)
    trap '_handle_purge_size_interrupt 130' INT
    trap '_handle_purge_size_interrupt 143' TERM
    _size_traps_installed=true

    for _sz_item in "${safe_to_clean[@]}"; do
        [[ $_size_interrupt_status -ge 128 ]] && break
        local _stmp
        _stmp=$(mktemp)
        register_temp_file "$_stmp"
        _size_tmpfiles+=("$_stmp")
        if [[ $SECONDS -ge $_size_deadline ]]; then
            printf 'TIMEOUT\n' > "$_stmp"
            continue
        fi
        (get_dir_size_kb "$_sz_item" "$_size_deadline" > "$_stmp" 2> /dev/null) < /dev/null &
        _size_pids+=($!)

        if [[ ${#_size_pids[@]} -ge $_max_size_jobs ]]; then
            _reap_one_size_pid
            [[ $_size_interrupt_status -ge 128 ]] && break
        fi
    done
    if [[ $_size_interrupt_status -lt 128 ]]; then
        for _spid in "${_size_pids[@]+"${_size_pids[@]}"}"; do
            wait "$_spid" 2> /dev/null || true
        done
        _size_pids=()
    fi
    _restore_purge_size_traps

    if [[ $_size_interrupt_status -ge 128 ]]; then
        local interrupted_size_temp
        for interrupted_size_temp in "${_size_tmpfiles[@]+"${_size_tmpfiles[@]}"}"; do
            rm -f "$interrupted_size_temp" 2> /dev/null || true # SAFE: exact scratch file created by mktemp above
        done
        if [[ -t 1 ]]; then
            stop_inline_spinner
        fi
        return "$_size_interrupt_status"
    fi

    local -a menu_options=()
    local -a item_paths=()
    local -a item_sizes=()
    local -a item_size_unknown_flags=()
    local -a item_recent_flags=()
    local -a item_activity_states=()
    local -a item_age_labels=()
    local -a item_cloud_flags=()
    local -a item_expected_parents=()
    local -a item_expected_parent_ids=()
    local -a item_expected_target_ids=()
    local -a item_scan_root_indexes=()
    # Resolve project ownership once per artifact. An indicator-backed root is
    # preferred. Without one, the artifact's direct parent is the narrowest
    # exact ownership boundary we can prove without grouping unrelated paths.
    # The physical identity is authoritative; display text is never a selector.
    local -a project_roots=()
    local -a _cached_project_identities=()
    local _pre_idx
    local project_parent=""
    local project_root=""
    local project_identity=""
    for _pre_idx in "${!safe_to_clean[@]}"; do
        local artifact_path="${safe_to_clean[$_pre_idx]}"
        # Adjacent siblings share report-only ownership. Deletion still rebinds
        # every artifact to its original scan evidence at the final boundary.
        if [[ "${artifact_path%/*}" != "$project_parent" ]]; then
            project_parent="${artifact_path%/*}"
            if ! project_root=$(find_purge_project_root_for_artifact "$artifact_path"); then
                project_root="$project_parent"
            fi
            project_identity=$(mole_path_identity "$project_root")
        fi
        project_roots[_pre_idx]="$project_root"
        _cached_project_identities[_pre_idx]="$project_identity"
    done

    # Build menu options - one line per artifact
    # Keep labels unformatted; the selector renders only visible rows.
    # Sizes are read from pre-computed results (parallel du calls launched above).
    local -a item_display_paths=()
    local -a item_project_identities=()
    local -a item_project_paths=()
    local -a size_failed_paths=()
    local _sz_idx=0
    for item in "${safe_to_clean[@]}"; do
        local item_index=$_sz_idx
        local project_root="${project_roots[$item_index]}"
        local project_path="${project_root/#$HOME/~}"
        local artifact_type="${item#"$project_root/"}"
        # Builtin reads keep the old cat mapping: an unreadable result is 0,
        # an empty one or a second line is invalid. The files are removed
        # together after this loop.
        local size_raw="0" size_extra=""
        if [[ -r "${_size_tmpfiles[$item_index]}" ]]; then
            size_raw=""
            if ! {
                IFS= read -r size_raw || true
                IFS= read -r size_extra || true
            } < "${_size_tmpfiles[$item_index]}" 2> /dev/null; then
                size_raw="0"
            fi
            [[ -z "$size_extra" ]] || size_raw="$size_raw"$'\n'"$size_extra"
        fi
        _sz_idx=$((_sz_idx + 1))
        local size_kb=0
        local size_human=""
        local size_unknown=false

        if [[ "$size_raw" == "TIMEOUT" ]]; then
            size_unknown=true
            size_human="unknown"
        elif [[ "$size_raw" =~ ^[0-9]+$ ]]; then
            size_kb="$size_raw"
            if [[ $size_kb -eq 0 && "${MOLE_PURGE_INCLUDE_EMPTY:-0}" != "1" ]]; then
                continue
            fi
            size_human=$(bytes_to_human "$((size_kb * 1024))")
        else
            PURGE_RUN_OUTCOME="incomplete"
            size_failed_paths+=("$item")
            debug_log "Invalid size result '$size_raw' for $item"
            continue
        fi

        local is_recent="${safe_recent_flags[$item_index]:-true}"
        local activity_state="${safe_activity_states[$item_index]:-uncertain}"
        local is_cloud=false
        if mole_purge_is_cloud_synced_path "$item"; then
            is_cloud=true
        fi
        local display_project_path="$project_path"
        local display_item_path
        display_item_path=$(format_purge_target_path "$item")
        if [[ "$is_cloud" == "true" ]]; then
            display_project_path="[cloud] $display_project_path"
            display_item_path="[cloud] $display_item_path"
        fi
        menu_options+=("$artifact_type")
        item_paths+=("$item")
        item_display_paths+=("$display_item_path")
        item_project_identities+=("${_cached_project_identities[$item_index]}")
        item_project_paths+=("$display_project_path")
        item_sizes+=("$size_kb")
        item_size_unknown_flags+=("$size_unknown")
        item_recent_flags+=("$is_recent")
        item_activity_states+=("$activity_state")
        item_cloud_flags+=("$is_cloud")
        item_expected_parents+=("${safe_expected_parents[$item_index]}")
        item_expected_parent_ids+=("${safe_expected_parent_ids[$item_index]}")
        item_expected_target_ids+=("${safe_expected_target_ids[$item_index]}")
        item_scan_root_indexes+=("${safe_scan_root_indexes[$item_index]}")
        # Build human-readable age label (bash 3.2 compatible, no assoc arrays).
        # Reuse the mtime the activity worker already read for this row.
        local _mod_time="${safe_activity_mtimes[$item_index]:-}" _age_secs _age_d
        [[ "$_mod_time" =~ ^[0-9]+$ ]] || _mod_time=$(get_file_mtime "$item" 2> /dev/null || echo "0")
        _age_secs=$((_now_epoch - _mod_time))
        _age_d=$((_age_secs / 86400))
        if [[ "$activity_state" == "uncertain" ]]; then
            item_age_labels+=("unknown")
        elif [[ "$activity_state" == "recent" && $_age_d -ge $MIN_AGE_DAYS ]]; then
            item_age_labels+=("<${MIN_AGE_DAYS}d")
        elif [[ $_age_d -lt 1 ]]; then
            item_age_labels+=("<1d")
        elif [[ $_age_d -lt 30 ]]; then
            item_age_labels+=("${_age_d}d")
        elif [[ $_age_d -lt 365 ]]; then
            item_age_labels+=("$((_age_d / 30))mo")
        else
            item_age_labels+=("$((_age_d / 365))y")
        fi
    done
    rm -f "${_size_tmpfiles[@]+"${_size_tmpfiles[@]}"}" 2> /dev/null || true # SAFE: exact registered mktemp size result files

    # Keep every exact project together. Project groups are ordered by their
    # aggregate known size, then artifacts within each group by item size. Only
    # numeric local indices cross the sort boundary; canonical path identities
    # remain in their aligned shell arrays.
    if [[ ${#item_sizes[@]} -gt 0 ]]; then
        local -a group_project_identities=()
        local -a group_total_sizes=()
        local -a item_group_indices=()
        local group_index

        # Sort an injective, line-safe encoding of each identity once, then
        # assign adjacent rows to the same group. This keeps grouping O(n log n)
        # when a large workspace contains hundreds of distinct projects.
        local grouping_temp
        grouping_temp=$(mktemp)
        for ((i = 0; i < ${#item_sizes[@]}; i++)); do
            local encoded_identity="${item_project_identities[i]}"
            encoded_identity="${encoded_identity//%/%25}"
            encoded_identity="${encoded_identity//|/%7C}"
            encoded_identity="${encoded_identity//$'\n'/%0A}"
            printf '%s|%d|%d\n' "$encoded_identity" "$i" "${item_sizes[i]}"
        done > "$grouping_temp"

        local previous_encoded_identity=""
        local have_previous_identity=false
        while IFS='|' read -r encoded_identity i item_size; do
            if [[ "$have_previous_identity" != "true" || "$encoded_identity" != "$previous_encoded_identity" ]]; then
                group_index=${#group_project_identities[@]}
                group_project_identities+=("${item_project_identities[i]}")
                group_total_sizes+=(0)
                previous_encoded_identity="$encoded_identity"
                have_previous_identity=true
            fi
            item_group_indices[i]=$group_index
            group_total_sizes[group_index]=$((group_total_sizes[group_index] + item_size))
        done < <(LC_ALL=C sort -t'|' -k1,1 -k2,2n "$grouping_temp")
        rm -f "$grouping_temp" # SAFE: this is the exact scratch file created by mktemp above.

        local group_sort_temp
        group_sort_temp=$(mktemp)
        for ((group_index = 0; group_index < ${#group_project_identities[@]}; group_index++)); do
            printf '%d|%d\n' "$group_index" "${group_total_sizes[group_index]}"
        done > "$group_sort_temp"

        local -a group_ranks=()
        local group_rank=0
        while IFS='|' read -r group_index group_total_size; do
            group_ranks[group_index]=$group_rank
            group_rank=$((group_rank + 1))
        done < <(sort -t'|' -k2,2nr -k1,1n "$group_sort_temp")
        rm -f "$group_sort_temp"

        local item_sort_temp
        item_sort_temp=$(mktemp)
        for ((i = 0; i < ${#item_sizes[@]}; i++)); do
            group_index=${item_group_indices[i]}
            printf '%d|%d|%d\n' "${group_ranks[group_index]}" "${item_sizes[i]}" "$i"
        done > "$item_sort_temp"

        local -a sorted_indices=()
        while IFS='|' read -r group_rank size idx; do
            sorted_indices+=("$idx")
        done < <(sort -t'|' -k1,1n -k2,2nr -k3,3n "$item_sort_temp")
        rm -f "$item_sort_temp"

        # Rebuild arrays in sorted order
        local -a sorted_menu_options=()
        local -a sorted_item_paths=()
        local -a sorted_item_sizes=()
        local -a sorted_item_size_unknown_flags=()
        local -a sorted_item_recent_flags=()
        local -a sorted_item_activity_states=()
        local -a sorted_item_display_paths=()
        local -a sorted_item_project_identities=()
        local -a sorted_item_project_paths=()
        local -a sorted_item_age_labels=()
        local -a sorted_item_cloud_flags=()
        local -a sorted_item_expected_parents=()
        local -a sorted_item_expected_parent_ids=()
        local -a sorted_item_expected_target_ids=()
        local -a sorted_item_scan_root_indexes=()

        for idx in "${sorted_indices[@]}"; do
            sorted_menu_options+=("${menu_options[idx]}")
            sorted_item_paths+=("${item_paths[idx]}")
            sorted_item_sizes+=("${item_sizes[idx]}")
            sorted_item_size_unknown_flags+=("${item_size_unknown_flags[idx]}")
            sorted_item_recent_flags+=("${item_recent_flags[idx]}")
            sorted_item_activity_states+=("${item_activity_states[idx]}")
            sorted_item_display_paths+=("${item_display_paths[idx]}")
            sorted_item_project_identities+=("${item_project_identities[idx]}")
            sorted_item_project_paths+=("${item_project_paths[idx]}")
            sorted_item_age_labels+=("${item_age_labels[idx]}")
            sorted_item_cloud_flags+=("${item_cloud_flags[idx]}")
            sorted_item_expected_parents+=("${item_expected_parents[idx]}")
            sorted_item_expected_parent_ids+=("${item_expected_parent_ids[idx]}")
            sorted_item_expected_target_ids+=("${item_expected_target_ids[idx]}")
            sorted_item_scan_root_indexes+=("${item_scan_root_indexes[idx]}")
        done

        # Replace original arrays with sorted versions
        menu_options=("${sorted_menu_options[@]}")
        item_paths=("${sorted_item_paths[@]}")
        item_sizes=("${sorted_item_sizes[@]}")
        item_size_unknown_flags=("${sorted_item_size_unknown_flags[@]}")
        item_recent_flags=("${sorted_item_recent_flags[@]}")
        item_activity_states=("${sorted_item_activity_states[@]}")
        item_display_paths=("${sorted_item_display_paths[@]}")
        item_project_identities=("${sorted_item_project_identities[@]}")
        item_project_paths=("${sorted_item_project_paths[@]}")
        item_age_labels=("${sorted_item_age_labels[@]}")
        item_cloud_flags=("${sorted_item_cloud_flags[@]}")
        item_expected_parents=("${sorted_item_expected_parents[@]}")
        item_expected_parent_ids=("${sorted_item_expected_parent_ids[@]}")
        item_expected_target_ids=("${sorted_item_expected_target_ids[@]}")
        item_scan_root_indexes=("${sorted_item_scan_root_indexes[@]}")
    fi
    if [[ -t 1 ]]; then
        stop_inline_spinner
    fi
    for item in "${size_failed_paths[@]+"${size_failed_paths[@]}"}"; do
        echo -e "${YELLOW}${ICON_WARNING}${NC} Could not measure ${item/#$HOME/~}; skipped" >&2
    done
    # Exit early if no artifacts were found to avoid unbound variable errors
    # when expanding empty arrays with set -u active.
    if [[ ${#menu_options[@]} -eq 0 ]]; then
        echo ""
        if [[ "$PURGE_RUN_OUTCOME" == "incomplete" ]]; then
            echo -e "${YELLOW}No artifacts could be prepared for review${NC}"
        else
            echo -e "${GRAY}No artifacts found to purge${NC}"
            PURGE_RUN_OUTCOME="no_candidates"
        fi
        printf '\n'
        return 0
    fi
    # Set global vars for selector
    export PURGE_CATEGORY_SIZES=$(
        IFS=,
        echo "${item_sizes[*]-}"
    )
    export PURGE_RECENT_CATEGORIES=$(
        IFS=,
        echo "${item_recent_flags[*]-}"
    )
    export PURGE_AGE_LABELS=$(
        IFS=,
        echo "${item_age_labels[*]-}"
    )
    # Interactive selection (only if terminal is available)
    PURGE_SELECTION_RESULT=""
    PURGE_CATEGORY_FULL_PATHS_ARRAY=("${item_display_paths[@]}")
    PURGE_CATEGORY_PROJECT_IDS_ARRAY=("${item_project_identities[@]}")
    PURGE_CATEGORY_PROJECT_PATHS_ARRAY=("${item_project_paths[@]}")
    PURGE_CATEGORY_SIZE_UNKNOWN_FLAGS_ARRAY=("${item_size_unknown_flags[@]}")
    if [[ -t 0 ]]; then
        if ! select_purge_categories "${menu_options[@]}"; then
            PURGE_CATEGORY_FULL_PATHS_ARRAY=()
            PURGE_CATEGORY_PROJECT_IDS_ARRAY=()
            PURGE_CATEGORY_PROJECT_PATHS_ARRAY=()
            PURGE_CATEGORY_SIZE_UNKNOWN_FLAGS_ARRAY=()
            unset PURGE_CATEGORY_SIZES PURGE_RECENT_CATEGORIES PURGE_AGE_LABELS PURGE_SELECTION_RESULT
            PURGE_RUN_OUTCOME="cancelled"
            return 0
        fi
    else
        # Non-interactive: select all non-recent items
        local skipped_cloud_count=0
        for ((i = 0; i < ${#menu_options[@]}; i++)); do
            if [[ "${item_cloud_flags[i]:-false}" == "true" && "${MOLE_DRY_RUN:-0}" != "1" ]]; then
                skipped_cloud_count=$((skipped_cloud_count + 1))
                continue
            fi
            if [[ ${item_recent_flags[i]} != "true" ]]; then
                [[ -n "$PURGE_SELECTION_RESULT" ]] && PURGE_SELECTION_RESULT+=","
                PURGE_SELECTION_RESULT+="$i"
            fi
        done
        if [[ $skipped_cloud_count -gt 0 ]]; then
            local skipped_cloud_text="artifact"
            [[ $skipped_cloud_count -ne 1 ]] && skipped_cloud_text="artifacts"
            echo ""
            echo -e "${YELLOW}${ICON_WARNING}${NC} Skipped ${skipped_cloud_count} cloud-synced ${skipped_cloud_text} in non-interactive mode (confirmation required)"
        fi
    fi
    if [[ -z "$PURGE_SELECTION_RESULT" ]]; then
        echo ""
        echo -e "${GRAY}No items selected${NC}"
        printf '\n'
        PURGE_CATEGORY_FULL_PATHS_ARRAY=()
        PURGE_CATEGORY_PROJECT_IDS_ARRAY=()
        PURGE_CATEGORY_PROJECT_PATHS_ARRAY=()
        PURGE_CATEGORY_SIZE_UNKNOWN_FLAGS_ARRAY=()
        unset PURGE_CATEGORY_SIZES PURGE_RECENT_CATEGORIES PURGE_AGE_LABELS PURGE_SELECTION_RESULT
        [[ "$PURGE_RUN_OUTCOME" != "incomplete" ]] && PURGE_RUN_OUTCOME="cancelled"
        return 0
    fi
    IFS=',' read -r -a selected_indices <<< "$PURGE_SELECTION_RESULT"
    local selected_total_kb=0
    local selected_unknown_count=0
    local selected_cloud_count=0
    local -a selected_display_paths=()
    for idx in "${selected_indices[@]}"; do
        local selected_size_kb="${item_sizes[idx]:-0}"
        [[ "$selected_size_kb" =~ ^[0-9]+$ ]] || selected_size_kb=0
        selected_total_kb=$((selected_total_kb + selected_size_kb))
        if [[ "${item_size_unknown_flags[idx]:-false}" == "true" ]]; then
            selected_unknown_count=$((selected_unknown_count + 1))
        fi
        if [[ "${item_cloud_flags[idx]:-false}" == "true" ]]; then
            selected_cloud_count=$((selected_cloud_count + 1))
        fi
        selected_display_paths+=("${item_display_paths[idx]}")
    done

    if [[ -t 0 ]]; then
        if ! confirm_purge_cleanup "${#selected_indices[@]}" "$selected_total_kb" "$selected_unknown_count" "$selected_cloud_count" "${selected_display_paths[@]}"; then
            echo -e "${GRAY}Purge cancelled${NC}"
            printf '\n'
            PURGE_CATEGORY_FULL_PATHS_ARRAY=()
            PURGE_CATEGORY_PROJECT_IDS_ARRAY=()
            PURGE_CATEGORY_PROJECT_PATHS_ARRAY=()
            PURGE_CATEGORY_SIZE_UNKNOWN_FLAGS_ARRAY=()
            unset PURGE_CATEGORY_SIZES PURGE_RECENT_CATEGORIES PURGE_AGE_LABELS PURGE_SELECTION_RESULT
            PURGE_RUN_OUTCOME="cancelled"
            return 0
        fi
    fi
    PURGE_CATEGORY_FULL_PATHS_ARRAY=()
    PURGE_CATEGORY_PROJECT_IDS_ARRAY=()
    PURGE_CATEGORY_PROJECT_PATHS_ARRAY=()
    PURGE_CATEGORY_SIZE_UNKNOWN_FLAGS_ARRAY=()

    # Clean selected items
    echo ""
    local stats_dir="${XDG_CACHE_HOME:-$HOME/.cache}/mactools/mole"
    local cleaned_count=0
    local dry_run_mode="${MOLE_DRY_RUN:-0}"
    for idx in "${selected_indices[@]}"; do
        local item_path="${item_paths[idx]}"
        local display_item_path="${item_display_paths[idx]}"
        local size_kb="${item_sizes[idx]}"
        local size_unknown="${item_size_unknown_flags[idx]:-false}"
        local size_human
        if [[ "$size_unknown" == "true" ]]; then
            size_human="unknown"
        else
            size_human=$(bytes_to_human "$((size_kb * 1024))")
        fi
        # Safety checks
        local expected_parent="${item_expected_parents[idx]}"
        local expected_parent_id="${item_expected_parent_ids[idx]}"
        local expected_target_id="${item_expected_target_ids[idx]}"
        local expected_scan_root_index="${item_scan_root_indexes[idx]}"
        local expected_scan_root="${scan_roots[$expected_scan_root_index]}"
        local expected_scan_root_physical="${scan_root_physical_paths[$expected_scan_root_index]}"
        if ! _mole_path_matches_identity \
            "$expected_scan_root" \
            "${scan_root_parents[$expected_scan_root_index]}" \
            "${scan_root_parent_ids[$expected_scan_root_index]}" \
            "${scan_root_target_ids[$expected_scan_root_index]}"; then
            echo -e "${YELLOW}${ICON_WARNING}${NC} Skipped $display_item_path (scan root changed after review)"
            continue
        fi
        if ! _mole_path_matches_identity \
            "$expected_scan_root_physical" \
            "${scan_root_physical_parents[$expected_scan_root_index]}" \
            "${scan_root_physical_parent_ids[$expected_scan_root_index]}" \
            "${scan_root_physical_target_ids[$expected_scan_root_index]}"; then
            echo -e "${YELLOW}${ICON_WARNING}${NC} Skipped $display_item_path (scan root target changed after review)"
            continue
        fi
        if ! _mole_path_matches_identity \
            "$item_path" "$expected_parent" "$expected_parent_id" "$expected_target_id"; then
            echo -e "${YELLOW}${ICON_WARNING}${NC} Skipped $display_item_path (path changed after review)"
            continue
        fi
        local current_item_physical_path="${_MOLE_PATH_SNAPSHOT_PARENT%/}/${item_path##*/}"
        [[ "$_MOLE_PATH_SNAPSHOT_PARENT" == "/" ]] && current_item_physical_path="/${item_path##*/}"
        if ! is_safe_project_artifact_under_root "$current_item_physical_path" "$expected_scan_root_physical"; then
            debug_log "Skipping purge target outside configured safe roots: ${item_path:-<empty>}"
            continue
        fi
        local protection_rc=0
        is_protected_purge_artifact "$item_path" || protection_rc=$?
        if [[ $protection_rc -gt 128 ]]; then
            PURGE_RUN_OUTCOME="cancelled"
            echo "$cleaned_count" > "$stats_dir/purge_count"
            return "$protection_rc"
        fi
        if [[ $protection_rc -eq 0 ]]; then
            if [[ "$PURGE_PROTECTION_UNVERIFIED" == "true" ]]; then
                echo -e "${YELLOW}${ICON_WARNING}${NC} Skipped $display_item_path (could not inspect contents; re-run mo purge to review it again)"
            else
                debug_log "Skipping purge target that became protected after review: $item_path"
            fi
            continue
        fi
        local activity_status=0
        purge_target_activity_still_safe "$item_path" "${item_activity_states[idx]:-uncertain}" || activity_status=$?
        if mole_rc_timeout_or_signal "$activity_status"; then
            PURGE_RUN_OUTCOME="cancelled"
            echo "$cleaned_count" > "$stats_dir/purge_count"
            return "$activity_status"
        fi
        if [[ $activity_status -ne 0 ]]; then
            echo -e "${YELLOW}${ICON_WARNING}${NC} Skipped $display_item_path (activity changed after review)"
            continue
        fi
        if [[ -t 1 ]]; then
            start_inline_spinner "Cleaning $display_item_path..."
        fi
        local removal_recorded=false
        if [[ -e "$item_path" ]]; then
            local _MOLE_PURGE_FINAL_ACTIVITY_STATE="${item_activity_states[idx]:-uncertain}"
            local _MOLE_PURGE_FINAL_SCAN_ROOT="$expected_scan_root"
            local _MOLE_PURGE_FINAL_SCAN_ROOT_PARENT="${scan_root_parents[$expected_scan_root_index]}"
            local _MOLE_PURGE_FINAL_SCAN_ROOT_PARENT_ID="${scan_root_parent_ids[$expected_scan_root_index]}"
            local _MOLE_PURGE_FINAL_SCAN_ROOT_TARGET_ID="${scan_root_target_ids[$expected_scan_root_index]}"
            local _MOLE_PURGE_FINAL_SCAN_ROOT_PHYSICAL="$expected_scan_root_physical"
            local _MOLE_PURGE_FINAL_SCAN_ROOT_PHYSICAL_PARENT="${scan_root_physical_parents[$expected_scan_root_index]}"
            local _MOLE_PURGE_FINAL_SCAN_ROOT_PHYSICAL_PARENT_ID="${scan_root_physical_parent_ids[$expected_scan_root_index]}"
            local _MOLE_PURGE_FINAL_SCAN_ROOT_PHYSICAL_TARGET_ID="${scan_root_physical_target_ids[$expected_scan_root_index]}"
            local _MOLE_PURGE_FINAL_EXPECTED_PARENT="$expected_parent"
            local _MOLE_PURGE_FINAL_EXPECTED_PARENT_ID="$expected_parent_id"
            local _MOLE_PURGE_FINAL_EXPECTED_TARGET_ID="$expected_target_id"
            local _MOLE_SAFE_REMOVE_FINAL_GUARD="_mole_purge_final_remove_guard"
            if safe_remove "$item_path" true "$size_kb" "" \
                "$expected_parent" "$expected_parent_id" "$expected_target_id"; then
                if [[ "$dry_run_mode" == "1" || ! -e "$item_path" ]]; then
                    local current_total
                    current_total=$(cat "$stats_dir/purge_stats" 2> /dev/null || echo "0")
                    echo "$((current_total + size_kb))" > "$stats_dir/purge_stats"
                    cleaned_count=$((cleaned_count + 1))
                    if [[ "$size_unknown" == "true" ]]; then
                        PURGE_UNKNOWN_SIZE_COUNT=$((PURGE_UNKNOWN_SIZE_COUNT + 1))
                    fi
                    removal_recorded=true
                fi
            else
                local removal_status=$?
                if mole_rc_timeout_or_signal "$removal_status"; then
                    PURGE_RUN_OUTCOME="cancelled"
                    echo "$cleaned_count" > "$stats_dir/purge_count"
                    if [[ -t 1 ]]; then
                        stop_inline_spinner
                    fi
                    return "$removal_status"
                fi
                echo -e "${YELLOW}${ICON_WARNING}${NC} Skipped $display_item_path (final removal check failed; re-run mo purge to review it again)"
            fi
        fi
        if [[ -t 1 ]]; then
            stop_inline_spinner
        fi
        if [[ "$removal_recorded" == "true" ]]; then
            if [[ "$dry_run_mode" == "1" ]]; then
                echo -e "${GREEN}${ICON_SUCCESS}${NC} [DRY RUN] $display_item_path${NC}, ${GREEN}$size_human${NC}"
            elif [[ -t 1 ]]; then
                echo -e "${GREEN}${ICON_SUCCESS}${NC} $display_item_path${NC}, ${GREEN}$size_human${NC}"
            fi
        fi
    done
    # Update count
    echo "$cleaned_count" > "$stats_dir/purge_count"
    if [[ $cleaned_count -lt ${#selected_indices[@]} ]]; then
        PURGE_RUN_OUTCOME="incomplete"
    fi
    unset PURGE_CATEGORY_SIZES PURGE_RECENT_CATEGORIES PURGE_AGE_LABELS PURGE_SELECTION_RESULT
}
