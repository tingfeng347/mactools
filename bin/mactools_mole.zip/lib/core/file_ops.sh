#!/bin/bash
# Mole - File Operations
# Safe file and directory manipulation with validation

set -euo pipefail

# Prevent multiple sourcing
if [[ -n "${MOLE_FILE_OPS_LOADED:-}" ]]; then
    return 0
fi
readonly MOLE_FILE_OPS_LOADED=1

# Error codes for removal operations
readonly MOLE_ERR_SIP_PROTECTED=10
readonly MOLE_ERR_AUTH_FAILED=11
readonly MOLE_ERR_READONLY_FS=12
readonly MOLE_ERR_PROTECTED_PATH=13
readonly MOLE_ERR_PRIVACY_DENIED=14
readonly MOLE_ERR_MUTABLE_PARENT=15
readonly MOLE_ERR_OWNER_UNVERIFIED=16
readonly MOLE_ERR_APP_REAPPEARED=17

# Ensure dependencies are loaded
_MOLE_CORE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -z "${MOLE_BASE_LOADED:-}" ]]; then
    # shellcheck source=lib/core/base.sh
    source "$_MOLE_CORE_DIR/base.sh"
fi
if [[ -z "${MOLE_LOG_LOADED:-}" ]]; then
    # shellcheck source=lib/core/log.sh
    source "$_MOLE_CORE_DIR/log.sh"
fi
if [[ -z "${MOLE_TIMEOUT_LOADED:-}" ]]; then
    # shellcheck source=lib/core/timeout.sh
    source "$_MOLE_CORE_DIR/timeout.sh"
fi
if [[ -z "${MOLE_TIMEOUTS_LOADED:-}" ]]; then
    # shellcheck source=lib/core/timeouts.sh
    source "$_MOLE_CORE_DIR/timeouts.sh"
fi

# shellcheck source=lib/core/browser_clones.sh
source "$_MOLE_CORE_DIR/browser_clones.sh"

# Keep the removal-timeout summary actionable: record which path ran out of
# budget so the closing note can name it instead of a bare count.
_mole_record_removal_timeout_path() {
    local path="$1"
    MOLE_CLEAN_REMOVAL_TIMEOUT_PATHS="${MOLE_CLEAN_REMOVAL_TIMEOUT_PATHS:+$MOLE_CLEAN_REMOVAL_TIMEOUT_PATHS
}$path"
}

# Bound production sudo commands while keeping shell-function mocks observable
# in tests. Timeout behavior itself must use a PATH stub so it exercises the
# same external-command branch that users run.
_mole_bounded_sudo() {
    local duration="${1:-${MOLE_TIMEOUT_DISK_VERIFY_SEC:-30}}"
    shift || true
    [[ $# -gt 0 ]] || return 2
    if [[ ! "$duration" =~ ^[0-9]+(\.[0-9]+)?$ || "$duration" =~ ^0+(\.0+)?$ ]]; then
        duration=30
    fi

    if declare -F sudo > /dev/null 2>&1; then
        sudo "$@"
        return $?
    fi

    local sudo_bin=""
    sudo_bin=$(command -v sudo 2> /dev/null || true)
    [[ -n "$sudo_bin" ]] || return 127
    run_with_timeout "$duration" "$sudo_bin" "$@"
}

_mole_bounded_sudo_until() {
    local deadline="$1"
    local requested="$2"
    shift 2
    local duration=""
    duration=$(_mole_timeout_with_deadline "$requested" "$deadline") || return $?
    _mole_bounded_sudo "$duration" "$@"
}

# ============================================================================
# Utility Functions
# ============================================================================

# Format duration in seconds to human readable string (e.g., "5 days", "2 months")
format_duration_human() {
    local seconds="${1:-0}"
    [[ ! "$seconds" =~ ^[0-9]+$ ]] && seconds=0

    local days=$((seconds / 86400))

    if [[ $days -eq 0 ]]; then
        echo "today"
    elif [[ $days -eq 1 ]]; then
        echo "1 day"
    elif [[ $days -lt 7 ]]; then
        echo "${days} days"
    elif [[ $days -lt 30 ]]; then
        local weeks=$((days / 7))
        [[ $weeks -eq 1 ]] && echo "1 week" || echo "${weeks} weeks"
    elif [[ $days -lt 365 ]]; then
        local months=$((days / 30))
        [[ $months -eq 1 ]] && echo "1 month" || echo "${months} months"
    else
        local years=$((days / 365))
        [[ $years -eq 1 ]] && echo "1 year" || echo "${years} years"
    fi
}

# ============================================================================
# Path Validation
# ============================================================================

_mole_normalize_deletion_policy_path() {
    local path="$1"
    local slash="/"
    local double_slash="//"

    while [[ "$path" == *"$double_slash"* ]]; do
        path="${path//$double_slash/$slash}"
    done

    while [[ "$path" == *"/./"* ]]; do
        path="${path//\/\.\//$slash}"
    done
    while [[ "$path" == */. ]]; do
        path="${path%/.}"
        [[ -n "$path" ]] || path="/"
    done

    local trimmed="${path%/}"
    [[ -n "$trimmed" ]] && printf '%s\n' "$trimmed" || printf '%s\n' "$path"
}

# PerfPowerServices keeps one live SQLite database per telemetry store, named
# Current* (CurrentBackgroundProcessingDB.BGSQL, CurrentXcodeOrganizerDB.XCSQL
# and so on), and rotates old data into Archived* files. The main file and its
# WAL companions must stay together while the service runs; unlinking any member
# can split the active database state, and mtime cannot prove it is closed. The
# BackgroundProcessing path is also the one the read-only System Data hint sizes.
readonly MOLE_ACTIVE_POWERLOG_DB_PATH="/private/var/db/powerlog/Library/PerfPowerTelemetry/BackgroundProcessing/CurrentBackgroundProcessingDB.BGSQL"
readonly MOLE_POWERLOG_TELEMETRY_ROOT="/private/var/db/powerlog/Library/PerfPowerTelemetry"

_mole_is_active_powerlog_database_path() {
    local restore_nocasematch=false
    local result=1

    if ! shopt -q nocasematch; then
        shopt -s nocasematch
        restore_nocasematch=true
    fi

    # <root>/<store>/Current*, one level deep; the -wal and -shm companions
    # share the Current prefix.
    case "$1" in
        "$MOLE_POWERLOG_TELEMETRY_ROOT"/*/Current*)
            # Cut by length: the case match folds case, a prefix strip would not.
            local store_and_file="${1:$((${#MOLE_POWERLOG_TELEMETRY_ROOT} + 1))}"
            local store="${store_and_file%%/*}"
            local file="${store_and_file#*/}"
            [[ -n "$store" && "$file" != */* ]] && result=0
            ;;
    esac

    [[ "$restore_nocasematch" == "true" ]] && shopt -u nocasematch
    return "$result"
}

# Live reverse-DNS user-cache guard (#1390).
# Unlinking an open Cache.db (or its -wal/-shm companions) while the owning
# helper still holds the database can send that process into an unbounded write
# loop on unlinked temp files and fill the volume (Autodesk Fusion's
# AcCoreConsole). Size and mtime are never authority for these trees: only a
# conclusive "no matching process" result, plus an open-file check for SQLite
# families, may authorize deletion.
#
# Process-state results are memoized for the current clean process so a batch
# under one cache directory does not fork pgrep once per leaf file. Bash 3.2
# has no associative arrays, so the cache is a pipe-delimited string.

_mole_user_cache_scope() {
    local path="$1"
    local normalized="${path%/}"
    local library_root="${HOME%/}/Library"
    local remainder=""
    local component=""
    local suffix=""
    local scope_type=""

    case "$normalized" in
        "$library_root/Caches"/*)
            remainder="${normalized#"$library_root/Caches"/}"
            component="${remainder%%/*}"
            scope_type="standard"
            ;;
        "$library_root/Containers"/*)
            remainder="${normalized#"$library_root/Containers"/}"
            component="${remainder%%/*}"
            suffix="${remainder#"$component"}"
            case "$suffix" in
                /Data/Library/Caches | /Data/Library/Caches/*) scope_type="container" ;;
                *) return 1 ;;
            esac
            ;;
        "$library_root/Group Containers"/*)
            remainder="${normalized#"$library_root/Group Containers"/}"
            component="${remainder%%/*}"
            suffix="${remainder#"$component"}"
            case "$suffix" in
                /Caches | /Caches/* | /Library/Caches | /Library/Caches/*) scope_type="container" ;;
                *) return 1 ;;
            esac
            ;;
        *) return 1 ;;
    esac

    # Reverse-DNS style only (com.vendor.app). Named trees such as Homebrew
    # stay outside this gate; they have their own process probes. The separator
    # is excluded so the caller can split this Bash-3.2-compatible record.
    [[ "$component" == *.* && "$component" != .* && "$component" != *"|"* ]] || return 1
    printf '%s|%s\n' "$component" "$scope_type"
    return 0
}

# SQLite main file or -wal / -shm / -journal companion. Case-insensitive so a
# cache sweep cannot delete a database through a case variant of its name
# (contributor PR #1391 + main reverse-DNS gate).
_mole_is_sqlite_database_path() {
    local restore_nocasematch=false
    local result=1
    local path="$1"
    local base="${path%-wal}"
    base="${base%-shm}"
    base="${base%-journal}"

    if ! shopt -q nocasematch; then
        shopt -s nocasematch
        restore_nocasematch=true
    fi

    case "$base" in
        *.db | *.sqlite | *.sqlite3)
            result=0
            ;;
    esac

    [[ "$restore_nocasematch" == "true" ]] && shopt -u nocasematch
    return "$result"
}

_mole_is_user_cache_sqlite_family_path() {
    _mole_is_sqlite_database_path "$1"
}

# Exact browser partial-download files directly under Downloads. These may be
# actively written even when their browser process name is unavailable, so the
# final deletion gate must recheck the file handle itself.
# A partial download is a mutable file some process may still be writing, not a
# rebuildable cache, so callers gate it on an open-handle probe instead of size
# or age. Homebrew's cache belongs here for the same reason the browser roots
# do: `brew fetch` writes `<sha>--<name>.incomplete` and holds it open for the
# length of the transfer, and a blanket sweep of that directory deleted six
# in-flight cask downloads out from under a running fetch (#1594).
_mole_is_incomplete_download_path() {
    local downloads_root="${HOME%/}/Downloads"
    local brew_downloads="${HOME%/}/Library/Caches/Homebrew/downloads"
    local path="$1"
    case "$path" in
        "$downloads_root"/*.download | "$downloads_root"/*.crdownload | "$downloads_root"/*.part)
            [[ "${path#"$downloads_root"/}" != */* ]]
            ;;
        "$brew_downloads"/*.incomplete)
            [[ "${path#"$brew_downloads"/}" != */* ]]
            ;;
        *) return 1 ;;
    esac
}

_mole_user_cache_sqlite_main_path() {
    local path="$1"
    case "$path" in
        *-wal) printf '%s\n' "${path%-wal}" ;;
        *-shm) printf '%s\n' "${path%-shm}" ;;
        *-journal) printf '%s\n' "${path%-journal}" ;;
        *) printf '%s\n' "$path" ;;
    esac
}

_mole_sqlite_family_base_path() {
    _mole_user_cache_sqlite_main_path "$1"
}

# One process-table snapshot per run, mirroring the Mac app's
# ProcessGuard.cachedProcessTable. The answer cannot change between candidates
# inside a single sweep, and the old code forked pgrep up to three times per
# cache directory.
#
# Lines that must not vote are dropped here: Mole's own process, and the
# measurement tools it forks over the very path being judged. `du -skPx
# ~/Library/Caches/<id>` puts <id> in the table purely because Mole is looking
# at it, which would make every slowly-measured cache report its owner as live.
_MOLE_PROCESS_TABLE=""
_MOLE_PROCESS_TABLE_STATE=""

_mole_reset_process_snapshot() {
    _MOLE_PROCESS_TABLE=""
    _MOLE_PROCESS_TABLE_STATE=""
    _MOLE_USER_CACHE_OWNER_STATE_CACHE=""
}

_mole_load_process_table() {
    if [[ -n "${_MOLE_PROCESS_TABLE_STATE:-}" ]]; then
        [[ "$_MOLE_PROCESS_TABLE_STATE" == "ok" ]] || return 1
        return 0
    fi

    local raw=""
    if ! raw=$(ps -axo pid,ppid,comm,args 2> /dev/null) || [[ -z "$raw" ]]; then
        _MOLE_PROCESS_TABLE_STATE="unavailable"
        return 1
    fi
    # Before args, ps cuts comm to 16 bytes; as the LAST column it prints the
    # whole executable path, spaces included. That second read is the only
    # unambiguous answer to "which bundle runs this", because argv can be
    # rewritten and a path with spaces has no field boundary. It rides on the
    # end of each line after \037; a pid missing from it keeps the argv
    # heuristic. A failed read only loses the extra evidence.
    local executables=""
    executables=$(ps -axo pid=,comm= 2> /dev/null) || executables=""

    # Every text tool below runs under LC_ALL=C so it compares BYTES. A process
    # table is not guaranteed to be UTF-8: an app named 富途牛牛 makes awk and
    # grep abort with "illegal byte sequence" in a UTF-8 locale, and an aborted
    # filter would silently shorten the table into a false "owner is idle".
    local filtered=""

    # Mole must not vote on itself. `pgrep -f` skipped the caller for free;
    # a raw table does not, and every candidate id reaches this code as an
    # argument, so the shell running `mo clean` (and any wrapper above it)
    # carries that id in its own argv. Walking the ppid chain drops the whole
    # invoking tree, which is also what excludes the `du` and `find` children
    # forked to MEASURE the very directory being judged.
    if ! filtered=$(printf '%s\n' "$raw" | MOLE_PS_EXECUTABLES="$executables" LC_ALL=C awk -v self="$$" '
        BEGIN {
            rows = split(ENVIRON["MOLE_PS_EXECUTABLES"], exe_rows, "\n")
            for (r = 1; r <= rows; r++) {
                row = exe_rows[r]
                sub(/^[[:space:]]+/, "", row)
                if (!match(row, /^[0-9]+[[:space:]]+\//)) continue
                exe_pid = substr(row, 1, RLENGTH)
                sub(/[[:space:]]+\/$/, "", exe_pid)
                exe_path = substr(row, RLENGTH)
                if (index(exe_path, "\037") == 0) exe[exe_pid] = exe_path
            }
        }
        NR > 1 {
            pid = $1
            parent[pid] = $2
            order[++count] = pid
            # Drop the pid/ppid columns back off the line.
            sub(/^[[:space:]]*[0-9]+[[:space:]]+[0-9]+[[:space:]]+/, "")
            text[pid] = $0
            comm[pid] = $1
        }
        END {
            for (p = self; p != "" && p != "0" && p != "1" && !(p in seen); p = parent[p]) {
                seen[p] = 1
                mine[p] = 1
            }
            # Descendants too: a command substitution forks a child that
            # inherits our argv verbatim, so the id would come back through
            # the copy even after the ancestor chain is gone.
            for (i = 1; i <= count; i++) {
                pid = order[i]
                depth = 0
                for (p = pid; p != "" && p != "0" && p != "1" && depth < 64; p = parent[p]) {
                    if (p == self) { mine[pid] = 1; break }
                    depth++
                }
            }
            for (i = 1; i <= count; i++) {
                pid = order[i]
                if (pid in mine) continue
                n = split(comm[pid], parts, "/")
                base = parts[n]
                if (base == "du" || base == "find" || base == "mdfind" ||
                    base == "ps" || base == "grep" || base == "stat" ||
                    base == "ls" || base == "rm") continue
                if (index(tolower(text[pid]), "com.tw93.mole") > 0) continue
                if (pid in exe) print text[pid] "\037" exe[pid]
                else print text[pid]
            }
        }'); then
        # A filter that died mid-table would leave a SHORT table, which reads
        # as "nothing owns this cache". Refuse to answer instead.
        _MOLE_PROCESS_TABLE_STATE="unavailable"
        return 1
    fi

    _MOLE_PROCESS_TABLE="$filtered"
    _MOLE_PROCESS_TABLE_STATE="ok"
    return 0
}

# Escape the ERE metacharacters so a cache-dir component is matched as a
# literal. Only these: a backslash before any other byte (`\-`, `\ `) is
# undefined in POSIX ERE, and GNU grep prints "stray \" warnings for it.
_mole_regex_escape() {
    printf '%s' "$1" | LC_ALL=C sed 's/[][(){}.^$*+?|\\]/\\&/g'
}

# Tri-state process probe for a reverse-DNS cache owner:
# 0 = a matching process is running, 1 = none matched, 2 = could not tell.
#
# Two acceptance shapes, deliberately asymmetric (parity with the Mac app's
# ProcessGuard.processListMentionsCacheOwner):
#   1. The full reverse-DNS id appears in the line. Self-identifying, so a
#      plain substring is enough.
#   2. The last DNS label appears as a DELIMITED token AND the same line
#      independently names another component of the id. Corroboration is what
#      makes a shared binary name usable: Claude and VS Code both ship a
#      Squirrel binary called ShipIt, so `pgrep -x ShipIt` attributed VS Code's
#      cache to a running Claude. Measured on this machine before the change,
#      34 of 59 idle caches were called busy; the plain-substring shapes it
#      relied on also read "default" out of syncdefaultsd and "data" out of
#      dataaccessd.
#
# Shape 2 cannot tell sibling channels apart: every Brave Origin Nightly line
# carries "Brave" and "Nightly", so com.brave.Browser.nightly stayed busy for
# as long as the other channel ran, and its cache directory (610 MB of
# abandoned Sparkle downloads on one machine) was never reclaimed. A line whose
# executable lives in an app bundle is therefore attributed by that bundle's
# identifier (_mole_process_line_belongs_to_other_app) before its tokens count.
_mole_user_cache_owner_process_state() {
    local owner="$1"
    [[ -n "$owner" ]] || return 2

    local cache_token="|${owner}:"
    case "${_MOLE_USER_CACHE_OWNER_STATE_CACHE:-}" in
        *"${cache_token}0|"*) return 0 ;;
        *"${cache_token}1|"*) return 1 ;;
        *"${cache_token}2|"*) return 2 ;;
    esac

    if ! _mole_load_process_table; then
        # An unreadable process table is not proof the owner is idle.
        return 2
    fi
    local table="$_MOLE_PROCESS_TABLE"

    # Feed the table by here-string, never through a pipe. `grep -q` exits on
    # its first match, and the printf still writing into that closed pipe takes
    # SIGPIPE, which bash reports as "printf: write error: Broken pipe" on
    # stderr; during `mo clean` that lands in the middle of the user's output.
    local state=1
    if LC_ALL=C grep -qiF -- "$owner" <<< "$table"; then
        state=0
    fi

    local leaf="${owner##*.}"
    if [[ $state -eq 1 && -n "$leaf" && "$leaf" != "$owner" && ${#leaf} -ge 4 ]]; then
        # "com" is in every reverse-DNS id and corroborates nothing.
        local -a corroborators=()
        local old_ifs="$IFS"
        local -a components=()
        IFS='.' read -r -a components <<< "$owner"
        IFS="$old_ifs"
        local index=0
        local last_index=$((${#components[@]} - 1))
        local component
        for component in "${components[@]}"; do
            if [[ $index -lt $last_index && ${#component} -ge 4 ]]; then
                case "$component" in
                    [cC][oO][mM]) ;;
                    *) corroborators+=("$(_mole_regex_escape "$component")") ;;
                esac
            fi
            index=$((index + 1))
        done

        if [[ ${#corroborators[@]} -gt 0 ]]; then
            local escaped_leaf
            escaped_leaf=$(_mole_regex_escape "$leaf")
            local alternation=""
            for component in "${corroborators[@]}"; do
                alternation="${alternation:+$alternation|}$component"
            done
            local boundary_open='(^|[^A-Za-z0-9])'
            local boundary_close='([^A-Za-z0-9]|$)'
            # Two passes, so both tokens must land on the SAME line. Materialize
            # the first result instead of piping into a `grep -q`, for the same
            # broken-pipe reason as the substring check above.
            local leaf_lines=""
            leaf_lines=$(LC_ALL=C grep -iE -- \
                "${boundary_open}${escaped_leaf}${boundary_close}" <<< "$table") || leaf_lines=""
            local corroborated_lines=""
            if [[ -n "$leaf_lines" ]]; then
                corroborated_lines=$(LC_ALL=C grep -iE -- \
                    "${boundary_open}(${alternation})${boundary_close}" <<< "$leaf_lines") || corroborated_lines=""
            fi
            local line
            while IFS= read -r line; do
                [[ -n "$line" ]] || continue
                if _mole_process_line_belongs_to_other_app "$line" "$owner" "$leaf"; then
                    continue
                fi
                state=0
                break
            done <<< "$corroborated_lines"
        fi
    fi

    _MOLE_USER_CACHE_OWNER_STATE_CACHE="${_MOLE_USER_CACHE_OWNER_STATE_CACHE-}${cache_token}${state}|"
    return "$state"
}

# CFBundleIdentifier of an app bundle into _MOLE_APP_BUNDLE_ID, memoized for
# the process (bundles do not change identity while a clean runs). Status 1
# when the plist cannot be read, including a read that times out on a
# dataless bundle; the miss is memoized too, and callers treat it as busy.
_MOLE_APP_BUNDLE_ID_CACHE=""
_MOLE_APP_BUNDLE_ID=""
_mole_app_bundle_identifier() {
    local bundle="$1"
    local cache_token="|${bundle}="
    _MOLE_APP_BUNDLE_ID=""
    case "${_MOLE_APP_BUNDLE_ID_CACHE:-}" in
        *"$cache_token"*)
            local rest="${_MOLE_APP_BUNDLE_ID_CACHE#*"$cache_token"}"
            _MOLE_APP_BUNDLE_ID="${rest%%|*}"
            [[ -n "$_MOLE_APP_BUNDLE_ID" ]]
            return
            ;;
    esac
    local id=""
    id=$(run_with_timeout "$MOLE_TIMEOUT_QUICK_DETECT_SEC" \
        plutil -extract CFBundleIdentifier raw -o - "$bundle/Contents/Info.plist" 2> /dev/null) || id=""
    mole_is_reverse_dns_bundle_id "$id" || id=""
    _MOLE_APP_BUNDLE_ID_CACHE="${_MOLE_APP_BUNDLE_ID_CACHE-}${cache_token}${id}|"
    _MOLE_APP_BUNDLE_ID="$id"
    [[ -n "$id" ]]
}

# A corroborated shape-2 process line whose executable lives in an app bundle
# below /Applications or ~/Applications is attributed by that bundle's id.
# The executable path ps reported for the pid (after \037) decides the bundle.
# Without it, inspect only the leading argv path, removing a truncated comm
# only when argv repeats its prefix. Never search later arguments for an app.
# 0 = the line belongs to a different app, so it says nothing about the owner.
# 1 = the line may be the owner's and its tokens count:
#   - the bundle's identifier is the owner's, or the two extend each other at a
#     label boundary (a settings or helper app inside the owner's bundle);
#   - the executable itself is named after the owner's last label, which is
#     how a helper with its own cache directory runs inside another vendor's
#     bundle (AcCoreConsole inside Autodesk Fusion, #1390);
#   - the identifier cannot be read, or no such bundle path is on the line.
_mole_process_line_belongs_to_other_app() {
    local line="$1" owner="$2" leaf="$3"
    local field root head tail bundle="" executable=""
    if [[ "$line" == *$'\037'* ]]; then
        executable="${line##*$'\037'}"
        line="${line%$'\037'*}"
    fi
    # ps can prefix argv with a truncated 16-byte comm. Remove it only when
    # argv repeats that exact path prefix; otherwise keep uncertain lines busy.
    line="${line#"${line%%[![:space:]]*}"}"
    local comm_prefix="${line:0:16}"
    local arguments="${line:16}"
    arguments="${arguments#"${arguments%%[![:space:]]*}"}"
    if [[ "$comm_prefix" == /* && "$arguments" == "$comm_prefix"* ]]; then
        line="$arguments"
    fi
    field="$line"
    [[ "$executable" == /* ]] && field="$executable"
    for root in /Applications "$HOME/Applications"; do
        [[ "$field" == "$root/"* ]] || continue
        head=""
        tail="$field"
        while [[ "$tail" == *.app/* ]]; do
            head="${head}${tail%%.app/*}.app"
            tail="${tail#*.app/}"
            # Crossing into another absolute argument cannot identify argv[0].
            [[ "$head" != *" /"* ]] || return 1
            if [[ -d "$head" ]]; then
                bundle="$head"
                break 2
            fi
            head="${head}/"
        done
    done
    [[ -n "$bundle" ]] || return 1
    _mole_app_bundle_identifier "$bundle" || return 1
    local id="$_MOLE_APP_BUNDLE_ID"

    local restore_nocasematch=false
    if ! shopt -q nocasematch; then
        shopt -s nocasematch
        restore_nocasematch=true
    fi
    # Labels are [-A-Za-z0-9], so the leaf needs no escaping inside the regex.
    local executable_pattern="/${leaf}([[:space:]]|\$)"
    local other_app=true
    if [[ "$id" == "$owner" || "$id" == "$owner".* || "$owner" == "$id".* ||
        "$line" =~ $executable_pattern || "${executable##*/}" == "$leaf" ]]; then
        other_app=false
    fi
    [[ "$restore_nocasematch" == "true" ]] && shopt -u nocasematch
    [[ "$other_app" == "true" ]]
}

# Is the database family live? 0 = in use, 1 = idle, 2 = could not tell.
# WAL-mode -shm only exists while at least one connection is open (PR #1391),
# but a stale -shm can remain after an unclean exit. When -shm exists we must
# still verify a process holds it open; otherwise the guard refuses forever on
# orphaned caches (#1439).
_mole_sqlite_database_in_use() {
    local path="$1"
    local base
    base=$(_mole_sqlite_family_base_path "$path")

    # Check every family member, including a stale -shm. If any process has a
    # handle open the database is live; if none do, the -shm is orphaned and
    # deletion is safe. One lsof call covers the whole family: forking it per
    # member tripled the live-cache gate's cost once the -shm fast path went
    # away (#1439), and lsof already accepts several names at once.
    local candidate
    local -a family=()
    for candidate in "$base" "${base}-wal" "${base}-shm"; do
        [[ -e "$candidate" ]] || continue
        family[${#family[@]}]="$candidate"
    done
    # Guard the empty expansion: macOS /bin/bash is 3.2, where "${a[@]}" on an
    # empty array is an unbound-variable error under set -u.
    [[ ${#family[@]} -gt 0 ]] || return 1

    _mole_paths_have_open_handle "${family[@]}"
}

_mole_user_cache_sqlite_has_open_handle() {
    local path="$1"
    local state=0
    _mole_sqlite_database_in_use "$path" || state=$?
    return "$state"
}

# Identity captured by the most recent conclusively idle container-cache
# probe. safe_remove rebinds it immediately before rm so a rename-and-recreate
# cannot turn an idle snapshot of the old object into permission for the new
# object at the same path.
_MOLE_CONTAINER_CACHE_PROBE_PARENT=""
_MOLE_CONTAINER_CACHE_PROBE_PARENT_ID=""
_MOLE_CONTAINER_CACHE_PROBE_TARGET_ID=""
_MOLE_COMPLETE_LSOF_MODE=""

_mole_container_cache_probe_deadline() {
    local timeout_seconds="${MOLE_TIMEOUT_MEDIUM_PROBE_SEC:-5}"
    if [[ ! "$timeout_seconds" =~ ^[0-9]+(\.[0-9]+)?$ ||
        "$timeout_seconds" =~ ^0+(\.0+)?$ ]]; then
        timeout_seconds=5
    fi
    local timeout_whole="${timeout_seconds%%.*}"
    local timeout_budget=$((10#$timeout_whole))
    if [[ "$timeout_seconds" == *.* && "${timeout_seconds#*.}" =~ [1-9] ]]; then
        timeout_budget=$((timeout_budget + 1))
    fi
    [[ $timeout_budget -ge 2 ]] || timeout_budget=2
    printf '%s\n' "$((SECONDS + timeout_budget))"
}

_mole_lsof_records_include_root_process() {
    local records="$1"
    local padded=$'\n'"$records"$'\n'
    [[ "$padded" == *$'\np1\n'* && "$padded" == *$'\nu0\n'* ]]
}

# Choose an lsof invocation that can see root-owned processes. macOS may return
# status 1 with no diagnostics when an unprivileged lsof silently omits those
# processes, which is not proof that a cache has no privileged open handles.
# Prefer direct visibility; use only an already-authorized non-interactive sudo
# session as a fallback. Tests and no-auth probes never attempt sudo.
_mole_complete_lsof_mode() {
    local probe_deadline="${1:-}"
    case "${_MOLE_COMPLETE_LSOF_MODE:-}" in
        direct | sudo) return 0 ;;
        unknown) return 2 ;;
    esac

    command -v lsof > /dev/null 2>&1 || {
        _MOLE_COMPLETE_LSOF_MODE="unknown"
        return 2
    }
    declare -f run_with_timeout > /dev/null 2>&1 || {
        _MOLE_COMPLETE_LSOF_MODE="unknown"
        return 2
    }

    local probe_timeout=""
    if ! probe_timeout=$(_mole_timeout_with_deadline "$MOLE_TIMEOUT_QUICK_DETECT_SEC" \
        "$probe_deadline"); then
        _MOLE_COMPLETE_LSOF_MODE="unknown"
        return 2
    fi

    local records=""
    local probe_rc=0
    records=$(run_with_timeout "$probe_timeout" lsof -F pu -p 1 < /dev/null 2>&1) || probe_rc=$?
    # A timed-out read proves nothing: retain this item, continue other cleanup.
    mole_rc_timeout "$probe_rc" && return 2
    if mole_rc_timeout_or_signal "$probe_rc"; then
        return "$probe_rc"
    fi
    if [[ $probe_rc -eq 0 ]] && _mole_lsof_records_include_root_process "$records"; then
        _MOLE_COMPLETE_LSOF_MODE="direct"
        return 0
    fi

    if [[ "${MOLE_TEST_MODE:-0}" == "1" || "${MOLE_TEST_NO_AUTH:-0}" == "1" ]] ||
        ! command -v sudo > /dev/null 2>&1; then
        _MOLE_COMPLETE_LSOF_MODE="unknown"
        return 2
    fi

    if ! probe_timeout=$(_mole_timeout_with_deadline "$MOLE_TIMEOUT_QUICK_DETECT_SEC" \
        "$probe_deadline"); then
        _MOLE_COMPLETE_LSOF_MODE="unknown"
        return 2
    fi
    records=""
    probe_rc=0
    records=$(run_with_timeout "$probe_timeout" sudo -n lsof -F pu -p 1 < /dev/null 2>&1) || probe_rc=$?
    # A timed-out read proves nothing: retain this item, continue other cleanup.
    mole_rc_timeout "$probe_rc" && return 2
    if mole_rc_timeout_or_signal "$probe_rc"; then
        return "$probe_rc"
    fi
    if [[ $probe_rc -eq 0 ]] && _mole_lsof_records_include_root_process "$records"; then
        _MOLE_COMPLETE_LSOF_MODE="sudo"
        return 0
    fi

    _MOLE_COMPLETE_LSOF_MODE="unknown"
    return 2
}

_mole_run_complete_lsof() {
    local probe_timeout="$1"
    shift
    case "${_MOLE_COMPLETE_LSOF_MODE:-}" in
        direct) run_with_timeout "$probe_timeout" lsof "$@" < /dev/null ;;
        sudo) run_with_timeout "$probe_timeout" sudo -n lsof "$@" < /dev/null ;;
        *) return 2 ;;
    esac
}

# Is any exact path open? 0 = in use, 1 = idle, 2 = could not tell. A complete
# process view is required before an empty lsof result can authorize deletion.
_mole_paths_have_open_handle() {
    [[ $# -gt 0 ]] || return 1

    local visibility_rc=0
    _mole_complete_lsof_mode || visibility_rc=$?
    if mole_rc_timeout_or_signal "$visibility_rc"; then
        return "$visibility_rc"
    fi
    [[ $visibility_rc -eq 0 ]] || return 2

    local lsof_rc=0
    local open_records=""
    # MO_DEBUG=0 on the capture, because this buffer is EVIDENCE, not output:
    # an empty stderr is what makes rc=1 mean "conclusively idle" below. With
    # the flag on, run_with_timeout writes its own "[TIMEOUT] Running with ..."
    # line into the same stream, the buffer is never empty, and every probe
    # downgrades to "could not tell". Measured on this Mac: 10 of 25 real cache
    # databases flipped from cleanable to kept under `mo clean --debug`, so the
    # flag meant to explain the run was quietly changing it.
    open_records=$(MO_DEBUG=0 _mole_run_complete_lsof "$MOLE_TIMEOUT_QUICK_DETECT_SEC" \
        -F n -- "$@" 2>&1) || lsof_rc=$?
    if mole_rc_timeout "$lsof_rc"; then
        # An incomplete read-only probe is unknown, not a run cancellation.
        return 2
    fi
    if mole_rc_timeout_or_signal "$lsof_rc"; then
        return "$lsof_rc"
    fi
    if [[ $lsof_rc -eq 0 ]]; then
        return 0
    fi
    # lsof may return 1 when only some requested family members are open. A
    # field record is still positive evidence of use, while diagnostics are an
    # unknown result and must never be discarded as a reliable no-match.
    local padded_records=$'\n'"$open_records"$'\n'
    if [[ "$padded_records" == *$'\nn'* ]]; then
        return 0
    fi
    [[ $lsof_rc -eq 1 && -z "$open_records" ]] || return 2
    return 1
}

# Is any process holding the exact container-cache file, or a descendant of
# the directory, open? 0 = in use, 1 = conclusively idle, 2 = could not tell;
# signal statuses are preserved so clean can stop instead of treating an
# interrupted safety probe as an ordinary skipped item.
_mole_container_cache_has_open_handle() {
    local path="$1"
    _MOLE_CONTAINER_CACHE_PROBE_PARENT=""
    _MOLE_CONTAINER_CACHE_PROBE_PARENT_ID=""
    _MOLE_CONTAINER_CACHE_PROBE_TARGET_ID=""
    command -v lsof > /dev/null 2>&1 || return 2
    declare -f run_with_timeout > /dev/null 2>&1 || return 2
    [[ -e "$path" ]] || return 1

    if [[ -n "${_MOLE_CONTAINER_CACHE_PROBE_DEADLINE+x}" &&
        -z "$_MOLE_CONTAINER_CACHE_PROBE_DEADLINE" ]]; then
        _MOLE_CONTAINER_CACHE_PROBE_DEADLINE=$(_mole_container_cache_probe_deadline)
    fi
    local visibility_rc=0
    _mole_complete_lsof_mode "${_MOLE_CONTAINER_CACHE_PROBE_DEADLINE:-}" || visibility_rc=$?
    if mole_rc_timeout_or_signal "$visibility_rc"; then
        return "$visibility_rc"
    fi
    [[ $visibility_rc -eq 0 ]] || return 2

    local probe_timeout=""
    if ! probe_timeout=$(_mole_timeout_with_deadline "$MOLE_TIMEOUT_QUICK_DETECT_SEC" \
        "${_MOLE_CONTAINER_CACHE_PROBE_DEADLINE:-}"); then
        debug_log "Container cache handle probe budget exhausted, keep: $path"
        return 2
    fi
    # Bind the exact parent and target objects around lsof. The path can be
    # renamed and recreated while the recursive probe is running.
    _mole_snapshot_path_identity "$path" || return 2
    local expected_parent="$_MOLE_PATH_SNAPSHOT_PARENT"
    local expected_parent_id="$_MOLE_PATH_SNAPSHOT_PARENT_ID"
    local expected_target_id="$_MOLE_PATH_SNAPSHOT_TARGET_ID"

    local lsof_rc=0
    local records=""
    if [[ -d "$path" ]]; then
        records=$(MO_DEBUG=0 _mole_run_complete_lsof "$probe_timeout" \
            -F pfn +D "$path" 2>&1) || lsof_rc=$?
    else
        records=$(MO_DEBUG=0 _mole_run_complete_lsof "$probe_timeout" \
            -F pfn -- "$path" 2>&1) || lsof_rc=$?
    fi

    if mole_rc_timeout "$lsof_rc"; then
        # An incomplete read-only probe is unknown, not a run cancellation.
        return 2
    fi
    if mole_rc_timeout_or_signal "$lsof_rc"; then
        return "$lsof_rc"
    fi
    if [[ $lsof_rc -eq 0 ]]; then
        return 0
    fi
    # A recursive walk may report one open record and still fail on another
    # descendant. Field output starts with p/f/n; warning prose does not.
    if [[ -n "$records" ]] && LC_ALL=C grep -qE '^[pfn]' <<< "$records"; then
        return 0
    fi
    # Only status 1 with completely empty output is a conclusive no-match for
    # this snapshot. It is not an ownership lease: safe_remove minimizes the
    # unavoidable reopen window by taking this snapshot at the final sink.
    # Missing lsof/timeout helper, timeout, signal, traversal warning, or other
    # error is unknown and must not authorize deletion.
    [[ $lsof_rc -eq 1 && -z "$records" ]] || return 2
    if ! _mole_path_matches_identity \
        "$path" "$expected_parent" "$expected_parent_id" "$expected_target_id"; then
        debug_log "Container cache identity changed during handle probe, keep: $path"
        return 2
    fi
    _MOLE_CONTAINER_CACHE_PROBE_PARENT="$expected_parent"
    _MOLE_CONTAINER_CACHE_PROBE_PARENT_ID="$expected_parent_id"
    _MOLE_CONTAINER_CACHE_PROBE_TARGET_ID="$expected_target_id"
    return 1
}

# Return 0 when deletion must be refused (live owner or open cache handle).
_mole_should_refuse_live_user_cache_path() {
    local path="$1"
    _MOLE_CONTAINER_CACHE_PROBE_PARENT=""
    _MOLE_CONTAINER_CACHE_PROBE_PARENT_ID=""
    _MOLE_CONTAINER_CACHE_PROBE_TARGET_ID=""
    local scope=""
    scope=$(_mole_user_cache_scope "$path") || return 1
    local owner="${scope%%|*}"
    local scope_type="${scope#*|}"

    local process_state=0
    _mole_user_cache_owner_process_state "$owner" || process_state=$?
    if [[ $process_state -eq 0 ]]; then
        debug_log "Live user cache owner running, keep: $path ($owner)"
        return 0
    fi
    if [[ $process_state -eq 2 ]]; then
        debug_log "Live user cache owner state unknown, keep: $path ($owner)"
        return 0
    fi

    # Container ids and helper process names need not correspond (for example,
    # a team-prefixed Group Container used by SkyComputerUseService). Inspect
    # every open descendant instead of treating process-name silence as idle.
    if [[ "$scope_type" == "container" ]]; then
        # A real safe_remove defers this comparatively expensive recursive
        # probe to its final-sink recheck. Nothing mutates the target between
        # initial validation and that boundary. Dry-run and direct validators
        # do not set this dynamic-scope flag and still probe here.
        if [[ "${_MOLE_DEFER_CONTAINER_HANDLE_PROBE:-false}" == "true" ]]; then
            return 1
        fi
        local container_open_state=0
        _mole_container_cache_has_open_handle "$path" || container_open_state=$?
        if mole_rc_timeout_or_signal "$container_open_state"; then
            return "$container_open_state"
        fi
        if [[ $container_open_state -eq 0 || $container_open_state -eq 2 ]]; then
            debug_log "Container cache handle not conclusively idle, keep: $path"
            return 0
        fi
    # Standard reverse-DNS caches retain the narrower SQLite-family probe.
    elif _mole_is_user_cache_sqlite_family_path "$path"; then
        local open_state=0
        _mole_user_cache_sqlite_has_open_handle "$path" || open_state=$?
        if mole_rc_timeout_or_signal "$open_state"; then
            return "$open_state"
        fi
        if [[ $open_state -eq 0 || $open_state -eq 2 ]]; then
            debug_log "SQLite user cache handle not conclusively idle, keep: $path"
            return 0
        fi
    elif [[ -d "$path" ]]; then
        # A caller's GLOBIGNORE would silently hide database files from this
        # glob, which reads as "no SQLite here" and unblocks the delete. Shadow
        # it with an empty local: bash restores the caller's value AND its
        # attributes on return, so no manual save, `declare -p` parsing, or
        # export-state replay is needed. An empty GLOBIGNORE also turns off the
        # dotglob that bash auto-enables for a non-empty one, so dotglob is set
        # explicitly below and restored by hand (shopt state is not scoped).
        # failglob off keeps an empty cache directory yielding a literal that
        # the -f test drops. Both shopt flags are saved because cleanup helpers
        # elsewhere in the tree set them without restoring. nullglob is left
        # alone: either state reaches the same -f filter.
        local GLOBIGNORE=""
        local candidate open_state family_base seen_base already_seen
        local restore_dotglob=false
        local restore_failglob=false
        local -a sqlite_candidates=()
        local -a sqlite_family_bases=()

        if shopt -q dotglob; then
            restore_dotglob=true
        fi
        if shopt -q failglob; then
            restore_failglob=true
        fi
        shopt -s dotglob
        shopt -u failglob
        sqlite_candidates=("$path"/*)
        if [[ "$restore_dotglob" != "true" ]]; then shopt -u dotglob; fi
        if [[ "$restore_failglob" == "true" ]]; then shopt -s failglob; fi

        if [[ ${#sqlite_candidates[@]} -gt 0 ]]; then
            for candidate in "${sqlite_candidates[@]}"; do
                [[ -f "$candidate" ]] || continue
                _mole_is_user_cache_sqlite_family_path "$candidate" || continue
                family_base=$(_mole_sqlite_family_base_path "$candidate")
                already_seen=false
                if [[ ${#sqlite_family_bases[@]} -gt 0 ]]; then
                    for seen_base in "${sqlite_family_bases[@]}"; do
                        if [[ "$seen_base" == "$family_base" ]]; then
                            already_seen=true
                            break
                        fi
                    done
                fi
                [[ "$already_seen" == "true" ]] && continue
                sqlite_family_bases[${#sqlite_family_bases[@]}]="$family_base"

                open_state=0
                _mole_user_cache_sqlite_has_open_handle "$family_base" || open_state=$?
                if mole_rc_timeout_or_signal "$open_state"; then
                    return "$open_state"
                fi
                if [[ $open_state -eq 0 || $open_state -eq 2 ]]; then
                    debug_log "SQLite under user cache dir not conclusively idle, keep: $path ($family_base)"
                    return 0
                fi
            done
        fi
    fi

    return 1
}

_mole_path_is_same_existing_file() {
    local path="$1"
    local protected_path="$2"
    [[ -e "$path" && -e "$protected_path" && "$path" -ef "$protected_path" ]]
}

_mole_path_is_within_existing_root() {
    local path="$1"
    local protected_root="$2"
    [[ -e "$protected_root" ]] || return 1

    local probe="$path"
    while [[ "$probe" == /* ]]; do
        if _mole_path_is_same_existing_file "$probe" "$protected_root"; then
            return 0
        fi
        [[ "$probe" == "/" ]] && break
        probe="${probe%/*}"
        [[ -n "$probe" ]] || probe="/"
    done
    return 1
}

# Deletion policy only. App/data protection stays in app_protection.sh.
_mole_is_critical_deletion_path() {
    local path="$1"

    case "$path" in
        # Homebrew (Intel) and user-installed software live here; individual
        # entries stay deletable. The Homebrew roots themselves are still
        # critical roots and must fall through to the deny arms below.
        /usr/local/* | /opt/homebrew/*)
            return 1
            ;;
        / | \
            /bin | /bin/* | \
            /dev | /dev/* | \
            /sbin | /sbin/* | \
            /usr | /usr/* | \
            /System | /System/* | \
            /Library | /Library/Apple | /Library/Apple/* | \
            /Library/Application\ Support | \
            /Library/Extensions | /Library/Extensions/* | \
            /Library/Keychains | /Library/Keychains/* | \
            /Applications | \
            /Applications/Finder.app | /Applications/Finder.app/* | \
            /Applications/Safari.app | /Applications/Safari.app/* | \
            /Volumes | \
            /opt | /opt/homebrew | \
            /Users | /Users/Shared | /Users/Guest | /Users/Guest/*)
            return 0
            ;;
        /private | /private/tmp)
            return 0
            ;;
        /etc | /etc/* | /private/etc | /private/etc/*)
            return 0
            ;;
        /var | /var/db | /var/db/* | /var/audit | /var/audit/* | /var/root | \
            /private/var | /private/var/tmp | /private/var/folders | \
            /private/var/db | /private/var/db/* | /private/var/audit | /private/var/audit/* | /private/var/root)
            return 0
            ;;
    esac

    # Reject a user home root (/Users/<name>) while keeping its children
    # deletable. A single case glob cannot express "exactly one component
    # under /Users", so match one level here: this catches the empty-variable
    # collapse "/Users/$user/$leaf" -> "/Users/<name>" that would otherwise
    # hand rm -rf an entire home directory.
    if [[ "$path" == /Users/* && "$path" != /Users/*/* ]]; then
        return 0
    fi

    # APFS is normally case-insensitive but case-preserving. Uppercase aliases
    # such as /SYSTEM and /OPT/HOMEBREW are not symlinks, so string policy
    # checks alone can miss that they are the same inode as protected roots.
    local protected_root
    local -a exact_roots=(
        / /Applications /Library /Volumes /Network /cores /etc /home /net
        /tmp /var /private /private/tmp /private/var /private/var/tmp
        /private/var/folders /Users /opt /opt/homebrew
    )
    for protected_root in "${exact_roots[@]}"; do
        if _mole_path_is_same_existing_file "$path" "$protected_root"; then
            return 0
        fi
    done

    local -a protected_trees=(
        /bin /dev /sbin /usr /System /private/etc /private/var/audit
        /private/var/db /private/var/root /Library/Apple /Library/Extensions
        /Library/Keychains /Applications/Finder.app /Applications/Safari.app
    )
    for protected_root in "${protected_trees[@]}"; do
        if _mole_path_is_within_existing_root "$path" "$protected_root"; then
            return 0
        fi
    done

    # Protect every account root even when a caller changes only component
    # casing (for example /USERS/SHARED on a case-insensitive volume).
    local parent_path="${path%/*}"
    [[ -n "$parent_path" ]] || parent_path="/"
    if _mole_path_is_same_existing_file "$parent_path" "/Users"; then
        return 0
    fi

    return 1
}

# True when path is a direct child of the invoking user's Trash. Emptying Trash
# is an explicit discard contract: cleanup protection for input methods,
# keyboards, and similar names still applies to live Library paths, but not to
# items the user or uninstall already moved into ~/.Trash.
_mole_is_user_trash_top_level_item() {
    local path="$1"
    [[ -n "$path" && "$path" == /* ]] || return 1

    local user_home="${HOME:-}"
    [[ -n "$user_home" && "$user_home" == /* ]] || return 1

    local policy_path
    policy_path=$(_mole_normalize_deletion_policy_path "$path")

    local trash_dir="${user_home%/}/.Trash"
    [[ "${policy_path%/*}" == "$trash_dir" ]]
}

# The batch uninstall caller owns these arrays. Record evidence at the gate,
# not by probing again after removal or reading a previous operation's log.
_mole_record_uninstall_refusal() {
    [[ "${_MOLE_UNINSTALL_REFUSALS_ACTIVE:-0}" == "1" ]] || return 0
    _MOLE_UNINSTALL_REFUSAL_PATHS+=("$1")
    _MOLE_UNINSTALL_REFUSAL_REASONS+=("$2")
}

# Validate path for deletion (absolute, no traversal, not system dir)
# A refusal leaves its fixed operations-log reason in _MOLE_VALIDATION_REASON
# so the sink that asked can record why the path stayed.
validate_path_for_deletion() {
    local path="$1"
    _MOLE_VALIDATION_REASON="invalid path"

    # Check path is not empty
    if [[ -z "$path" ]]; then
        log_error "Path validation failed: empty path"
        return 1
    fi

    # Check path is absolute
    if [[ "$path" != /* ]]; then
        log_error "Path validation failed: path must be absolute: $path"
        return 1
    fi

    # Check for path traversal attempts
    # Only reject .. when it appears as a complete path component (/../ or /.. or ../)
    # This allows legitimate directory names containing .. (e.g., Firefox's "name..files")
    if [[ "$path" =~ (^|/)\.\.(\/|$) ]]; then
        log_error "Path validation failed: path traversal not allowed: $path"
        return 1
    fi

    # Check path doesn't contain dangerous characters
    if [[ "$path" =~ [[:cntrl:]] ]] || [[ "$path" =~ $'\n' ]]; then
        log_error "Path validation failed: contains control characters: $path"
        return 1
    fi

    local policy_path
    policy_path=$(_mole_normalize_deletion_policy_path "$path")
    _MOLE_VALIDATION_REASON="protected"

    # Check symlink target if path is a symbolic link
    if [[ -L "$path" ]]; then
        local link_target
        link_target=$(readlink "$path" 2> /dev/null) || {
            log_error "Cannot read symlink: $path"
            return 1
        }

        # Resolve relative symlinks to absolute paths for validation
        local resolved_target="$link_target"
        if [[ "$link_target" != /* ]]; then
            local link_dir
            link_dir=$(dirname "$path")
            resolved_target=$(cd "$link_dir" 2> /dev/null && cd "$(dirname "$link_target")" 2> /dev/null && pwd)/$(basename "$link_target") || resolved_target=""
        fi

        # Validate resolved target against protected paths
        if [[ -n "$resolved_target" ]]; then
            resolved_target=$(_mole_normalize_deletion_policy_path "$resolved_target")
            if _mole_is_critical_deletion_path "$resolved_target"; then
                log_error "Symlink points to protected system path: $path -> $resolved_target"
                return 1
            fi
        fi
    fi

    # Ancestor-symlink guard. The checks above (deny list, protection policy)
    # match on the LITERAL path string, and the -L test above only inspects the
    # leaf. If any ANCESTOR component is a symlink, the string matches nothing
    # dangerous while the actual rm follows the link into the real target:
    # a redirected "~/Library/Caches" would let a cache sweep walk into
    # ~/Documents or a system tree. Canonicalize the parent (physical cd
    # resolves every ancestor link) and re-run the deny predicates on the
    # resolved leaf. Deny-only: a resolved path never grants permission the
    # literal path lacked, so legitimate targets keep their existing verdict.
    # Runs BEFORE the allowlists below, which would otherwise early-return past
    # this gate for /private/* paths.
    #
    # This sits on the hot path (every deletion candidate), so the common case
    # must stay fork-free: walk the ancestors with the [[ -L ]] builtin and only
    # pay for the canonicalizing subshell when one of them really is a symlink.
    # A dirname + `cd -P` on every call cost ~2ms, about +23% on validation.
    local parent_dir resolved_parent probe
    local ancestor_is_link=false
    parent_dir="${policy_path%/*}"
    [[ -z "$parent_dir" ]] && parent_dir="/"
    if [[ -d "$parent_dir" ]]; then
        probe="$parent_dir"
        while [[ "$probe" == /?* ]]; do
            if [[ -L "$probe" ]]; then
                ancestor_is_link=true
                break
            fi
            probe="${probe%/*}"
        done
    fi
    if [[ "$ancestor_is_link" == "true" ]]; then
        resolved_parent=$(cd -P "$parent_dir" 2> /dev/null && pwd -P) || resolved_parent=""
        if [[ -n "$resolved_parent" && "$resolved_parent" != "$parent_dir" ]]; then
            local resolved_path
            resolved_path=$(_mole_normalize_deletion_policy_path "${resolved_parent}/${policy_path##*/}")
            if _mole_is_critical_deletion_path "$resolved_path"; then
                log_error "Path validation failed: resolves into a critical system path: $path -> $resolved_path"
                return 1
            fi
            if declare -f should_protect_path > /dev/null 2>&1 && should_protect_path "$resolved_path"; then
                _mole_record_uninstall_refusal "$path" protected
                if [[ "${MO_DEBUG:-0}" == "1" ]]; then
                    log_warning "Path validation: resolves into a protected path: $path -> $resolved_path"
                fi
                return 1
            fi
        fi
    fi

    # Allow deletion of coresymbolicationd cache (safe system cache that can be rebuilt)
    case "$policy_path" in
        /System/Library/Caches/com.apple.coresymbolicationd/data | /System/Library/Caches/com.apple.coresymbolicationd/data/*)
            return 0
            ;;
    esac

    # Reject the active power telemetry database before the broad powerlog
    # allowlist below. Size and mtime are diagnostic signals, never deletion
    # authority for a database that a KeepAlive system service can reopen.
    if _mole_is_active_powerlog_database_path "$policy_path"; then
        debug_log "Path validation: active powerlog database kept: $policy_path"
        return 1
    fi

    # Live reverse-DNS user caches (process + SQLite handle). Covers Autodesk
    # helpers and every other com.vendor tree under ~/Library/Caches (#1390).
    local live_cache_guard_rc=0
    _mole_should_refuse_live_user_cache_path "$policy_path" || live_cache_guard_rc=$?
    if [[ $live_cache_guard_rc -eq 0 ]]; then
        _mole_record_uninstall_refusal "$path" live-cache
        _MOLE_VALIDATION_REASON="live user cache"
        debug_log "Path validation: live user cache kept: $policy_path"
        return 1
    fi
    if mole_rc_timeout_or_signal "$live_cache_guard_rc"; then
        _mole_record_clean_cancellation "$live_cache_guard_rc"
        return "$live_cache_guard_rc"
    fi

    # General SQLite family gate from PR #1391: refuse any in-use database even
    # outside reverse-DNS cache dirs (fail closed when lsof cannot answer).
    if _mole_is_sqlite_database_path "$policy_path"; then
        local sqlite_state=0
        _mole_sqlite_database_in_use "$policy_path" || sqlite_state=$?
        if mole_rc_timeout_or_signal "$sqlite_state"; then
            _mole_record_clean_cancellation "$sqlite_state"
            return "$sqlite_state"
        fi
        if [[ $sqlite_state -eq 0 || $sqlite_state -eq 2 ]]; then
            _MOLE_VALIDATION_REASON="active or unknown SQLite database"
            debug_log "Path validation: in-use SQLite database kept: $policy_path"
            return 1
        fi
    fi

    # Browser partial downloads are mutable user files, not ordinary caches.
    # Recheck them here so safe_remove binds the open-handle evidence at the
    # final deletion boundary instead of trusting an earlier cleanup scan.
    if _mole_is_incomplete_download_path "$policy_path"; then
        local download_open_state=0
        _mole_paths_have_open_handle "$policy_path" || download_open_state=$?
        if mole_rc_timeout_or_signal "$download_open_state"; then
            _mole_record_clean_cancellation "$download_open_state"
            return "$download_open_state"
        fi
        if [[ $download_open_state -eq 0 || $download_open_state -eq 2 ]]; then
            _MOLE_VALIDATION_REASON="active or unknown download"
            debug_log "Path validation: incomplete download not conclusively idle, keep: $policy_path"
            return 1
        fi
    fi

    # Endpoint-security/EDR agent caches under var/folders look like ordinary
    # rebuildable caches, but deleting anything in a sensor's container trips
    # tamper detection (reported as malware). Reject here, before the
    # /private/var/folders allowlist below, so every deletion caller is covered,
    # not only the cleanup sweeps that pre-check the predicate.
    if declare -f is_endpoint_security_cache_path > /dev/null 2>&1 && is_endpoint_security_cache_path "$policy_path"; then
        if [[ "${MO_DEBUG:-0}" == "1" ]]; then
            log_warning "Path validation: endpoint-security agent cache skipped: $policy_path"
        fi
        return 1
    fi

    # Allow known safe paths under /private
    case "$policy_path" in
        /private/tmp/* | \
            /private/var/tmp/* | \
            /private/var/log | /private/var/log/* | \
            /private/var/folders/* | \
            /private/var/db/diagnostics | /private/var/db/diagnostics/* | \
            /private/var/db/DiagnosticPipeline | /private/var/db/DiagnosticPipeline/* | \
            /private/var/db/powerlog | /private/var/db/powerlog/* | \
            /private/var/db/reportmemoryexception | /private/var/db/reportmemoryexception/* | \
            /private/var/db/receipts/*.bom | /private/var/db/receipts/*.plist)
            return 0
            ;;
    esac

    # Check path isn't critical system directory
    if _mole_is_critical_deletion_path "$policy_path"; then
        log_error "Path validation failed: critical system path: $path"
        return 1
    fi

    # Check if path is protected (keychains, system settings, etc)
    if declare -f should_protect_path > /dev/null 2>&1; then
        if _mole_is_user_trash_top_level_item "$policy_path"; then
            :
        elif should_protect_path "$policy_path"; then
            _mole_record_uninstall_refusal "$path" protected
            if [[ "${MO_DEBUG:-0}" == "1" ]]; then
                log_warning "Path validation: protected path skipped: $policy_path"
            fi
            return 1
        fi
    fi

    return 0
}

# ============================================================================
# Safe Removal Operations
# ============================================================================

_record_file_ops_dry_run_target() {
    local path="$1"
    local precomputed_size_kb="${2:-}"

    declare -f record_dry_run_cleanup_target > /dev/null 2>&1 || return 0

    local size_kb=0
    local size_known=true
    local eligibility_still_current=true
    if [[ -n "$precomputed_size_kb" && "$precomputed_size_kb" =~ ^[0-9]+$ ]]; then
        size_kb="$precomputed_size_kb"
    elif [[ "$precomputed_size_kb" == "unknown" ]]; then
        # The caller cannot infer reclaimable bytes from allocated blocks
        # (for example APFS code-signature clones). Keep the preview partial.
        size_known=false
        eligibility_still_current=false
    else
        eligibility_still_current=false
        local measured_size=""
        local measure_rc=0
        measured_size=$(get_path_size_kb "$path" "" readable 2> /dev/null) || measure_rc=$?
        if [[ $measure_rc -ge 128 ]]; then
            return "$measure_rc"
        fi
        if mole_rc_timeout "$measure_rc"; then
            # Sizing budget exhausted: preview the item as size-unknown rather
            # than cancelling the whole dry run.
            MOLE_CLEAN_SIZING_TIMEOUTS=$((${MOLE_CLEAN_SIZING_TIMEOUTS:-0} + 1))
        fi
        if [[ $measure_rc -eq 0 && "$measured_size" =~ ^[0-9]+$ ]]; then
            size_kb="$measured_size"
        else
            size_known=false
        fi
    fi

    # A browser can reopen a partial download while the size probe runs. Keep
    # dry-run eligibility aligned with the real final sink instead of listing a
    # file that real cleanup would now refuse.
    if _mole_is_incomplete_download_path "$path"; then
        local download_open_state=0
        _mole_paths_have_open_handle "$path" || download_open_state=$?
        if mole_rc_timeout_or_signal "$download_open_state"; then
            return "$download_open_state"
        fi
        [[ $download_open_state -eq 1 ]] || return 1
    fi

    # A precomputed size means validate_path_for_deletion was the last
    # meaningful probe. If this helper measured after validation, rerun the
    # recorder guards: an owner can open the cache while du is walking it.
    local _MOLE_DRY_RUN_TARGET_PREVALIDATED="$eligibility_still_current"
    local record_rc=0
    record_dry_run_cleanup_target \
        "$path" "$size_kb" 1 "$size_known" || record_rc=$?
    return "$record_rc"
}

# Preserve the first timeout or signal observed by a clean deletion sink. Some
# older cleanup families intentionally treat ordinary item failures as
# best-effort; this sticky status prevents those `|| true` paths from turning a
# user interrupt into permission to continue deleting later targets. An
# optional label names what was running; see _mole_note_clean_cancel_source.
_mole_record_clean_cancellation() {
    local status="$1"
    local source="${2:-}"
    if [[ "${MOLE_CURRENT_COMMAND:-}" == "clean" ]] && mole_rc_timeout_or_signal "$status"; then
        local existing="${MOLE_CLEAN_CANCEL_STATUS:-0}"
        if ! mole_rc_timeout_or_signal "$existing"; then
            MOLE_CLEAN_CANCEL_STATUS=$status
            export MOLE_CLEAN_CANCEL_STATUS
        fi
        _mole_note_clean_cancel_source "$source"
    fi
}

# Name what a clean cancellation came from, so the summary and mole.log can say
# what timed out instead of only the exit status. A cancellation unwinds from
# the innermost caller outward, so the first label wins and the step runners
# only fill the gap when nothing deeper knew a better name.
_mole_note_clean_cancel_source() {
    local source="${1:-}"
    [[ -n "$source" && -z "${MOLE_CLEAN_CANCEL_SOURCE:-}" ]] || return 0
    MOLE_CLEAN_CANCEL_SOURCE="$source"
    export MOLE_CLEAN_CANCEL_SOURCE
}

# Safe wrapper around rm -rf with validation
safe_remove() {
    local path="$1"
    local silent="${2:-false}"
    local precomputed_size_kb="${3:-}"
    local deadline_seconds="${4:-}"
    local expected_parent="${5:-}"
    local expected_parent_id="${6:-}"
    local expected_target_id="${7:-}"
    local expected_file_sha256="${8:-}"
    local expected_absent_path="${9:-}"
    local _MOLE_DEFER_CONTAINER_HANDLE_PROBE=false
    local container_probe_parent=""
    local container_probe_parent_id=""
    local container_probe_target_id=""
    local exact_probe_parent=""
    local exact_probe_parent_id=""
    local exact_probe_target_id=""

    local pending_clean_cancel="${MOLE_CLEAN_CANCEL_STATUS:-0}"
    if [[ "${MOLE_CURRENT_COMMAND:-}" == "clean" ]] && mole_rc_timeout_or_signal "$pending_clean_cancel"; then
        return "$pending_clean_cancel"
    fi

    # Validate path. Silent cleanup callers still need the same policy result,
    # but should not print one validation warning per skipped cache item.
    # Real cleanup performs its recursive container-handle probe once at the
    # final sink below. A dry-run with no precomputed size likewise defers that
    # one expensive probe until after sizing, where the preview recorder runs
    # the complete eligibility pass. Pre-sized dry-runs probe here once.
    local dry_run_sizes_before_preview=false
    if [[ "${MOLE_DRY_RUN:-0}" == "1" &&
        (! "$precomputed_size_kb" =~ ^[0-9]+$) ]] &&
        declare -f record_dry_run_cleanup_target > /dev/null 2>&1; then
        dry_run_sizes_before_preview=true
    fi
    if [[ "${MOLE_DRY_RUN:-0}" != "1" || "$dry_run_sizes_before_preview" == "true" ]]; then
        _MOLE_DEFER_CONTAINER_HANDLE_PROBE=true
    fi
    local validation_rc=0
    if [[ "$silent" == "true" ]]; then
        validate_path_for_deletion "$path" 2> /dev/null || validation_rc=$?
    else
        validate_path_for_deletion "$path" || validation_rc=$?
    fi
    if [[ $validation_rc -ne 0 ]]; then
        if mole_rc_timeout_or_signal "$validation_rc"; then
            _mole_record_clean_cancellation "$validation_rc"
            return "$validation_rc"
        fi
        log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "${_MOLE_VALIDATION_REASON:-protected}"
        return 1
    fi
    _MOLE_DEFER_CONTAINER_HANDLE_PROBE=false

    # Honor the user whitelist here, not just in safe_clean. safe_remove is
    # called directly by several clean/optimize flows (Xcode DerivedData,
    # mail downloads, deep-system caches, broken LaunchAgents) that would
    # otherwise ignore a user's whitelist selection. is_path_whitelisted is
    # a no-op when the whitelist is empty, and uninstall does not route
    # through safe_remove, so this stays scoped to clean/optimize. See #710.
    if declare -f is_path_whitelisted > /dev/null 2>&1 && is_path_whitelisted "$path"; then
        log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "whitelist"
        return 1
    fi

    # Check if path exists
    if [[ ! -e "$path" ]]; then
        return 0
    fi

    # Keep preview eligibility identical to real cleanup. This first check
    # rejects an already-present compiled model cache before the dry-run return;
    # the final-sink check below still catches one created during size probing.
    if declare -f holds_compiled_model_cache > /dev/null 2>&1 && holds_compiled_model_cache "$path" 2> /dev/null; then
        debug_log "Skipped removal for compiled model cache: $path"
        log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "compiled model cache"
        return 1
    fi

    # Dry-run mode: log but don't delete
    if [[ "${MOLE_DRY_RUN:-0}" == "1" ]]; then
        local dry_record_rc=0
        _record_file_ops_dry_run_target \
            "$path" "$precomputed_size_kb" || dry_record_rc=$?
        if mole_rc_timeout_or_signal "$dry_record_rc"; then
            _mole_record_clean_cancellation "$dry_record_rc"
            return "$dry_record_rc"
        fi
        [[ $dry_record_rc -eq 0 ]] || return "$dry_record_rc"
        if [[ "${MO_DEBUG:-}" == "1" ]]; then
            local file_type="file"
            [[ -d "$path" ]] && file_type="directory"
            [[ -L "$path" ]] && file_type="symlink"

            local file_size=""
            local file_age=""

            if [[ -e "$path" ]]; then
                local size_kb=0
                if [[ -n "$precomputed_size_kb" ]]; then
                    if [[ "$precomputed_size_kb" =~ ^[0-9]+$ ]]; then
                        size_kb="$precomputed_size_kb"
                    fi
                else
                    local size_rc=0
                    size_kb=$(get_path_size_kb "$path" "" readable 2> /dev/null) || size_rc=$?
                    if mole_rc_timeout_or_signal "$size_rc"; then
                        _mole_record_clean_cancellation "$size_rc"
                        return "$size_rc"
                    fi
                    [[ $size_rc -eq 0 ]] || size_kb=0
                fi
                if [[ "$size_kb" -gt 0 ]]; then
                    file_size=$(bytes_to_human "$((size_kb * 1024))")
                fi

                if [[ -f "$path" || -d "$path" ]] && ! [[ -L "$path" ]]; then
                    local mod_time=0
                    local stat_rc=0
                    mod_time=$("$STAT_BSD" -f%m "$path" 2> /dev/null) || stat_rc=$?
                    if mole_rc_timeout_or_signal "$stat_rc"; then
                        _mole_record_clean_cancellation "$stat_rc"
                        return "$stat_rc"
                    fi
                    [[ $stat_rc -eq 0 ]] || mod_time=0
                    local now
                    now=$(date +%s 2> /dev/null || echo "0")
                    if [[ "$mod_time" -gt 0 && "$now" -gt 0 ]]; then
                        file_age=$(((now - mod_time) / 86400))
                    fi
                fi
            fi

            debug_file_action "[DRY RUN] Would remove" "$path" "$file_size" "$file_age"
        else
            debug_log "[DRY RUN] Would remove: $path"
        fi
        return 0
    fi

    debug_log "Removing: $path"

    # Calculate size before deletion for logging.
    # Accept pre-computed size to skip redundant I/O when the caller already measured.
    local size_kb=0
    local size_human=""
    if oplog_enabled; then
        if [[ -n "$precomputed_size_kb" ]]; then
            if [[ "$precomputed_size_kb" =~ ^[0-9]+$ ]]; then
                size_kb="$precomputed_size_kb"
            fi
        elif [[ -e "$path" ]]; then
            local size_probe_rc=0
            local size_probe_timeout=""
            size_probe_timeout=$(_mole_timeout_with_deadline "$MOLE_TIMEOUT_DISK_VERIFY_SEC" \
                "$deadline_seconds") || size_probe_rc=$?
            if [[ $size_probe_rc -eq 0 ]]; then
                size_kb=$(get_path_size_kb "$path" "$size_probe_timeout" readable 2> /dev/null) || size_probe_rc=$?
            fi
            if mole_rc_timeout "$size_probe_rc"; then
                # Sizing budget exhausted: still remove the item, with the
                # freed total under-reported, matching the batch-sizing policy.
                MOLE_CLEAN_SIZING_TIMEOUTS=$((${MOLE_CLEAN_SIZING_TIMEOUTS:-0} + 1))
            fi
            if [[ $size_probe_rc -ge 128 ]]; then
                _mole_record_clean_cancellation "$size_probe_rc"
                return "$size_probe_rc"
            fi
            [[ $size_probe_rc -eq 0 && "$size_kb" =~ ^[0-9]+$ ]] || size_kb=0
        fi
        if [[ "$size_kb" =~ ^[0-9]+$ ]] && [[ "$size_kb" -gt 0 ]]; then
            size_human=$(bytes_to_human "$((size_kb * 1024))" 2> /dev/null || echo "${size_kb}KB")
        fi
    fi

    # Recheck at the final sink. A daemon can create this compiled-model cache
    # while the preceding size probe walks the target, and deleting its parent
    # then breaks recognition until the owning process restarts.
    if declare -f holds_compiled_model_cache > /dev/null 2>&1 && holds_compiled_model_cache "$path" 2> /dev/null; then
        debug_log "Skipped removal after compiled model cache appeared: $path"
        log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "compiled model cache"
        return 1
    fi

    # Recheck live-owner / open-SQLite state after size probing: a helper can
    # launch while du is walking the tree (same race class as the compiled
    # model cache check above).
    _mole_reset_process_snapshot
    local live_cache_guard_rc=0
    _mole_should_refuse_live_user_cache_path "$path" || live_cache_guard_rc=$?
    if [[ $live_cache_guard_rc -eq 0 ]]; then
        debug_log "Skipped removal after live user cache appeared: $path"
        log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "live user cache"
        return 1
    fi
    if mole_rc_timeout_or_signal "$live_cache_guard_rc"; then
        _mole_record_clean_cancellation "$live_cache_guard_rc"
        return "$live_cache_guard_rc"
    fi
    container_probe_parent="$_MOLE_CONTAINER_CACHE_PROBE_PARENT"
    container_probe_parent_id="$_MOLE_CONTAINER_CACHE_PROBE_PARENT_ID"
    container_probe_target_id="$_MOLE_CONTAINER_CACHE_PROBE_TARGET_ID"

    # Reverse-DNS and container caches were rechecked by the live-cache guard.
    # SQLite files elsewhere still need their own post-size handle probe.
    if _mole_is_sqlite_database_path "$path" &&
        ! _mole_user_cache_scope "$path" > /dev/null 2>&1; then
        _mole_snapshot_path_identity "$path" || return 1
        local sqlite_parent="$_MOLE_PATH_SNAPSHOT_PARENT"
        local sqlite_parent_id="$_MOLE_PATH_SNAPSHOT_PARENT_ID"
        local sqlite_target_id="$_MOLE_PATH_SNAPSHOT_TARGET_ID"
        local sqlite_state=0
        _mole_sqlite_database_in_use "$path" || sqlite_state=$?
        if mole_rc_timeout_or_signal "$sqlite_state"; then
            _mole_record_clean_cancellation "$sqlite_state"
            return "$sqlite_state"
        fi
        if [[ $sqlite_state -ne 1 ]]; then
            debug_log "Skipped SQLite file after final open-file recheck: $path"
            log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "active or unknown SQLite database"
            return 1
        fi
        if ! _mole_path_matches_identity \
            "$path" "$sqlite_parent" "$sqlite_parent_id" "$sqlite_target_id"; then
            debug_log "Skipped SQLite file after identity changed during final open-file recheck: $path"
            log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "identity changed"
            return 1
        fi
        exact_probe_parent="$sqlite_parent"
        exact_probe_parent_id="$sqlite_parent_id"
        exact_probe_target_id="$sqlite_target_id"
    fi

    # Downloads are outside the user-cache owner guard above. Recheck the exact
    # file after sizing so a browser that resumed the transfer cannot race the
    # earlier validation into the unlink.
    if _mole_is_incomplete_download_path "$path"; then
        _mole_snapshot_path_identity "$path" || return 1
        local download_parent="$_MOLE_PATH_SNAPSHOT_PARENT"
        local download_parent_id="$_MOLE_PATH_SNAPSHOT_PARENT_ID"
        local download_target_id="$_MOLE_PATH_SNAPSHOT_TARGET_ID"
        local download_open_state=0
        _mole_paths_have_open_handle "$path" || download_open_state=$?
        if mole_rc_timeout_or_signal "$download_open_state"; then
            _mole_record_clean_cancellation "$download_open_state"
            return "$download_open_state"
        fi
        if [[ $download_open_state -ne 1 ]]; then
            debug_log "Skipped incomplete download after final open-file recheck: $path"
            log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "active or unknown download"
            return 1
        fi
        if ! _mole_path_matches_identity \
            "$path" "$download_parent" "$download_parent_id" "$download_target_id"; then
            debug_log "Skipped incomplete download after identity changed during final open-file recheck: $path"
            log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "identity changed"
            return 1
        fi
        exact_probe_parent="$download_parent"
        exact_probe_parent_id="$download_parent_id"
        exact_probe_target_id="$download_target_id"
    fi

    if [[ -n "$expected_parent" ]] && ! _mole_path_matches_identity \
        "$path" "$expected_parent" "$expected_parent_id" "$expected_target_id"; then
        debug_log "Refusing removal after final path identity changed: $path"
        log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "identity changed"
        return 1
    fi

    # Last hop before rm, for callers whose exclusion depends on state this
    # function cannot express as a parent/target inode pair. A candidate list
    # that skipped a live owner root only proves where that root pointed when
    # the list was built; re-asking here closes the rest of the window rather
    # than leaving it open from discovery all the way to the unlink. Set
    # _MOLE_SAFE_REMOVE_FINAL_GUARD to a function name that takes the path and
    # returns non-zero to refuse.
    local final_sink_guard="${_MOLE_SAFE_REMOVE_FINAL_GUARD:-}"
    if [[ -n "$final_sink_guard" ]] && declare -f "$final_sink_guard" > /dev/null 2>&1; then
        local final_sink_guard_rc=0
        "$final_sink_guard" "$path" || final_sink_guard_rc=$?
        if [[ $final_sink_guard_rc -ne 0 ]]; then
            debug_log "Refusing removal after the final sink guard denied: $path"
            log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "sink guard denied"
            if mole_rc_timeout_or_signal "$final_sink_guard_rc"; then
                _mole_record_clean_cancellation "$final_sink_guard_rc"
                return "$final_sink_guard_rc"
            fi
            return 1
        fi
    fi

    # A caller-specific final guard may perform process or metadata probes.
    # Rebind the original object once more after that work so a replacement
    # during the guard cannot reach rm under the identity checked above.
    if [[ -n "$expected_parent" ]] && ! _mole_path_matches_identity \
        "$path" "$expected_parent" "$expected_parent_id" "$expected_target_id"; then
        debug_log "Refusing removal after path identity changed during the final sink guard: $path"
        log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "identity changed"
        return 1
    fi

    if [[ -n "$container_probe_parent" ]] && ! _mole_path_matches_identity \
        "$path" "$container_probe_parent" "$container_probe_parent_id" \
        "$container_probe_target_id"; then
        debug_log "Refusing removal after container cache identity changed: $path"
        log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "identity changed"
        return 1
    fi

    if [[ -n "$exact_probe_parent" ]] && ! _mole_path_matches_identity \
        "$path" "$exact_probe_parent" "$exact_probe_parent_id" \
        "$exact_probe_target_id"; then
        debug_log "Refusing removal after final open-file target identity changed: $path"
        log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "identity changed"
        return 1
    fi

    # Resolve the removal budget before the last ownership check so a
    # replacement during that work cannot inherit the earlier approval.
    local error_msg
    local rm_exit=0
    local section_deadline_spent=0
    local rm_timeout=""
    local shell_rm=false
    if declare -F rm > /dev/null 2>&1; then
        shell_rm=true
    else
        rm_timeout=$(_mole_timeout_with_deadline "$MOLE_TIMEOUT_DISK_VERIFY_SEC" \
            "$deadline_seconds") || rm_exit=$?
        [[ $rm_exit -eq 0 ]] || section_deadline_spent=1
    fi
    if [[ $rm_exit -eq 0 ]]; then
        _mole_owned_path_still_valid "$path" \
            "$expected_file_sha256" "$expected_absent_path" \
            "$expected_parent" "$expected_parent_id" "$expected_target_id" || return $?
        # Use || so set -e does not abort before the failure is classified.
        if [[ "$shell_rm" == true ]]; then
            error_msg=$(rm -rf "$path" 2>&1) || rm_exit=$? # SAFE: safe_remove validated and rebound this exact target above
        else
            error_msg=$(run_with_timeout "$rm_timeout" rm -rf "$path" < /dev/null 2>&1) || rm_exit=$? # SAFE: safe_remove validated and rebound this exact target above
        fi
    fi

    if mole_rc_timeout "$rm_exit"; then
        debug_log "Removal timed out: $path"
        if [[ $section_deadline_spent -eq 1 ]]; then
            # Not a slow removal: the caller's section deadline expired before
            # rm ran, and that section reports its own stop. Counting it here
            # would point the user at the per-item removal budget instead.
            log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "section time limit reached"
        else
            log_operation "${MOLE_CURRENT_COMMAND:-clean}" "FAILED" "$path" "removal timed out"
            # A slow disk can exceed the per-item removal budget. That is a
            # failed removal, not a user interrupt: count it and keep going so
            # one slow cache never cancels the remaining cleanup.
            MOLE_CLEAN_REMOVAL_TIMEOUTS=$((${MOLE_CLEAN_REMOVAL_TIMEOUTS:-0} + 1))
            _mole_record_removal_timeout_path "$path"
        fi
        return 124
    fi

    # Preserve interrupt semantics so callers can abort long-running deletions.
    if [[ $rm_exit -ge 128 ]]; then
        _mole_record_clean_cancellation "$rm_exit"
        return "$rm_exit"
    fi

    if [[ $rm_exit -eq 0 ]]; then
        # Log successful removal
        log_operation "${MOLE_CURRENT_COMMAND:-clean}" "REMOVED" "$path" "$size_human"
        return 0
    else
        # Check if it's a permission error
        if [[ "$error_msg" == *"Permission denied"* ]] || [[ "$error_msg" == *"Operation not permitted"* ]]; then
            MOLE_PERMISSION_DENIED_COUNT=${MOLE_PERMISSION_DENIED_COUNT:-0}
            MOLE_PERMISSION_DENIED_COUNT=$((MOLE_PERMISSION_DENIED_COUNT + 1))
            export MOLE_PERMISSION_DENIED_COUNT
            debug_log "Permission denied: $path, may need Full Disk Access"
            log_operation "${MOLE_CURRENT_COMMAND:-clean}" "FAILED" "$path" "permission denied"
        else
            [[ "$silent" != "true" ]] && log_error "Failed to remove: $path"
            log_operation "${MOLE_CURRENT_COMMAND:-clean}" "FAILED" "$path" "error"
        fi
        return 1
    fi
}

# Safe symlink removal (for pre-validated symlinks only)
safe_remove_symlink() {
    local path="$1"
    local use_sudo="${2:-false}"
    local expected_parent="${3:-}"
    local expected_parent_id="${4:-}"
    local expected_target_id="${5:-}"
    local expected_file_sha256="${6:-}"
    local expected_absent_path="${7:-}"

    local pending_clean_cancel="${MOLE_CLEAN_CANCEL_STATUS:-0}"
    if [[ "${MOLE_CURRENT_COMMAND:-}" == "clean" ]] && mole_rc_timeout_or_signal "$pending_clean_cancel"; then
        return "$pending_clean_cancel"
    fi

    if [[ ! -L "$path" ]]; then
        return 1
    fi

    if ! validate_path_for_deletion "$path"; then
        return 1
    fi

    if declare -f is_path_whitelisted > /dev/null 2>&1 && is_path_whitelisted "$path"; then
        debug_log "Skipped symlink removal for whitelisted path: $path"
        log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "whitelist"
        return 1
    fi

    if [[ "$use_sudo" == "true" ]] && _mole_privileged_path_has_mutable_ancestor "$path"; then
        if [[ ${EUID:-0} -ne 0 ]]; then
            use_sudo=false
        else
            debug_log "Refusing privileged symlink removal below mutable parent: $path"
            return 1
        fi
    fi

    if [[ "${MOLE_DRY_RUN:-0}" == "1" ]]; then
        local dry_record_rc=0
        _record_file_ops_dry_run_target "$path" || dry_record_rc=$?
        if mole_rc_timeout_or_signal "$dry_record_rc"; then
            _mole_record_clean_cancellation "$dry_record_rc"
            return "$dry_record_rc"
        fi
        debug_log "[DRY RUN] Would remove symlink: $path"
        return 0
    fi

    if [[ -n "$expected_parent" ]] && ! _mole_path_matches_identity \
        "$path" "$expected_parent" "$expected_parent_id" "$expected_target_id"; then
        debug_log "Refusing symlink removal after final path identity changed: $path"
        return 1
    fi

    _mole_owned_path_still_valid "$path" \
        "$expected_file_sha256" "$expected_absent_path" \
        "$expected_parent" "$expected_parent_id" "$expected_target_id" || return $?

    local rm_exit=0
    if [[ "$use_sudo" == "true" ]]; then
        if [[ "${MOLE_TEST_MODE:-0}" == "1" || "${MOLE_TEST_NO_AUTH:-0}" == "1" ]]; then
            log_operation "${MOLE_CURRENT_COMMAND:-clean}" "FAILED" "$path" "sudo blocked in test mode"
            return 1
        fi
        sudo -n rm "$path" 2> /dev/null || rm_exit=$?
    else
        rm "$path" 2> /dev/null || rm_exit=$?
    fi

    if [[ $rm_exit -eq 0 ]]; then
        log_operation "${MOLE_CURRENT_COMMAND:-clean}" "REMOVED" "$path" "symlink"
        return 0
    else
        if mole_rc_timeout_or_signal "$rm_exit"; then
            _mole_record_clean_cancellation "$rm_exit"
            return "$rm_exit"
        fi
        log_operation "${MOLE_CURRENT_COMMAND:-clean}" "FAILED" "$path" "symlink removal failed"
        return 1
    fi
}

# A privileged path operation is only safe when every parent directory is
# immutable to unprivileged users. Checking `-w` alone is insufficient: a
# directory owner can chmod a 0555 parent after validation, replace a component,
# and redirect a later sudo rm/mv. Fail closed on non-root ownership, writable
# mode bits, symlinks, unreadable metadata, and effective ACL write access.
_mole_privileged_path_has_mutable_ancestor() {
    local path="$1"
    local probe="${path%/*}"
    local invoking_uid=""
    [[ -n "$probe" ]] || probe="/"
    invoking_uid=$(get_invoking_uid 2> /dev/null || true)
    [[ "$invoking_uid" =~ ^[0-9]+$ ]] || return 0

    while true; do
        if [[ -L "$probe" ]]; then
            return 0
        fi

        local owner_uid=""
        local mode=""
        owner_uid=$($STAT_BSD -f%u "$probe" 2> /dev/null || true)
        mode=$($STAT_BSD -f%Lp "$probe" 2> /dev/null || true)
        if [[ ! "$owner_uid" =~ ^[0-9]+$ || ! "$mode" =~ ^[0-7]+$ ]]; then
            return 0
        fi
        if [[ "$owner_uid" -ne 0 ]] || (((8#$mode & 0022) != 0)); then
            return 0
        fi
        if [[ "$invoking_uid" -ne 0 ]]; then
            if [[ ${EUID:-0} -eq "$invoking_uid" ]]; then
                [[ -w "$probe" ]] && return 0
            elif [[ ${EUID:-0} -eq 0 ]]; then
                # Under `sudo mo`, the shell's -w probe reflects root rather
                # than the invoking user. Drop authority for the ACL check so
                # immutable system parents do not become false positives.
                local acl_probe_rc=0
                _mole_bounded_sudo "$MOLE_TIMEOUT_QUICK_DETECT_SEC" \
                    -n -u "#$invoking_uid" /bin/test -w "$probe" < /dev/null 2> /dev/null || acl_probe_rc=$?
                if [[ $acl_probe_rc -eq 0 ]]; then
                    return 0
                fi
                # Only test's ordinary false status proves the invoking user
                # cannot write here. Timeout, auth, and execution failures are
                # unknown and must classify the ancestor as mutable.
                if [[ $acl_probe_rc -ne 1 ]]; then
                    return 0
                fi
            else
                return 0
            fi
        fi

        [[ "$probe" == "/" ]] && break
        probe="${probe%/*}"
        [[ -n "$probe" ]] || probe="/"
    done
    return 1
}

# Safe sudo removal with symlink and parent-component protection
safe_sudo_remove() {
    local path="$1"
    local precomputed_size_kb="${2:-}"
    local deadline_seconds="${3:-}"
    local expected_parent="${4:-}"
    local expected_parent_id="${5:-}"
    local expected_target_id="${6:-}"
    local expected_file_sha256="${7:-}"
    local expected_absent_path="${8:-}"

    local pending_clean_cancel="${MOLE_CLEAN_CANCEL_STATUS:-0}"
    if [[ "${MOLE_CURRENT_COMMAND:-}" == "clean" ]] && mole_rc_timeout_or_signal "$pending_clean_cancel"; then
        return "$pending_clean_cancel"
    fi

    if ! validate_path_for_deletion "$path"; then
        if declare -f should_protect_path > /dev/null 2>&1 && should_protect_path "$path"; then
            debug_log "Skipped sudo remove for protected path: $path"
            return "$MOLE_ERR_PROTECTED_PATH"
        else
            log_error "Path validation failed for sudo remove: $path"
        fi
        return 1
    fi

    if [[ ! -e "$path" ]]; then
        return 0
    fi

    if [[ -L "$path" ]]; then
        log_error "Refusing to sudo remove symlink: $path"
        return 1
    fi

    if declare -f is_path_whitelisted > /dev/null 2>&1 && is_path_whitelisted "$path"; then
        debug_log "Skipped sudo remove for whitelisted path: $path"
        log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "whitelist"
        return 1
    fi

    # This policy must run before dry-run/test-mode returns so preview and real
    # privileged cleanup agree on the eligible target set.
    if declare -f holds_compiled_model_cache > /dev/null 2>&1 && holds_compiled_model_cache "$path" 2> /dev/null; then
        debug_log "Skipped sudo removal for compiled model cache: $path"
        log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "compiled model cache"
        return "$MOLE_ERR_PROTECTED_PATH"
    fi

    if _mole_privileged_path_has_mutable_ancestor "$path"; then
        if [[ ${EUID:-0} -ne 0 ]]; then
            debug_log "Downgrading sudo remove below mutable parent: $path"
            safe_remove "$path" true "$precomputed_size_kb" "$deadline_seconds" \
                "$expected_parent" "$expected_parent_id" "$expected_target_id" \
                "$expected_file_sha256" "$expected_absent_path"
            return $?
        fi
        debug_log "Refusing sudo remove below mutable parent: $path"
        return 1
    fi

    if [[ "${MOLE_DRY_RUN:-0}" == "1" ]]; then
        local dry_record_rc=0
        _record_file_ops_dry_run_target \
            "$path" "$precomputed_size_kb" || dry_record_rc=$?
        if mole_rc_timeout_or_signal "$dry_record_rc"; then
            _mole_record_clean_cancellation "$dry_record_rc"
            return "$dry_record_rc"
        fi
    fi

    if [[ "${MOLE_TEST_MODE:-0}" == "1" || "${MOLE_TEST_NO_AUTH:-0}" == "1" ]]; then
        if [[ "${MOLE_DRY_RUN:-0}" == "1" ]]; then
            log_info "[DRY-RUN] Would sudo remove: $path"
            return 0
        fi
        log_operation "${MOLE_CURRENT_COMMAND:-clean}" "FAILED" "$path" "sudo blocked in test mode"
        return 1
    fi

    if [[ "${MOLE_DRY_RUN:-0}" == "1" ]]; then
        if [[ "${MO_DEBUG:-}" == "1" ]]; then
            local file_type="file"
            [[ -d "$path" ]] && file_type="directory"

            local file_size=""
            local file_age=""

            local exists_rc=0
            _mole_bounded_sudo "$MOLE_TIMEOUT_QUICK_DETECT_SEC" \
                -n test -e "$path" < /dev/null 2> /dev/null || exists_rc=$?
            if mole_rc_timeout_or_signal "$exists_rc"; then
                _mole_record_clean_cancellation "$exists_rc"
                return "$exists_rc"
            fi
            if [[ $exists_rc -eq 0 ]]; then
                local size_kb=0
                if [[ -n "$precomputed_size_kb" ]]; then
                    if [[ "$precomputed_size_kb" =~ ^[0-9]+$ ]]; then
                        size_kb="$precomputed_size_kb"
                    fi
                else
                    local size_rc=0
                    size_kb=$(_mole_bounded_sudo "$MOLE_TIMEOUT_DISK_VERIFY_SEC" \
                        -n du -skP "$path" < /dev/null 2> /dev/null | awk '{print $1}') || size_rc=$?
                    if mole_rc_timeout_or_signal "$size_rc"; then
                        _mole_record_clean_cancellation "$size_rc"
                        return "$size_rc"
                    fi
                    [[ $size_rc -eq 0 ]] || size_kb=0
                fi
                if [[ "$size_kb" -gt 0 ]]; then
                    file_size=$(bytes_to_human "$((size_kb * 1024))")
                fi

                local type_probe_rc=0
                _mole_bounded_sudo "$MOLE_TIMEOUT_QUICK_DETECT_SEC" \
                    -n test -f "$path" < /dev/null 2> /dev/null || type_probe_rc=$?
                if mole_rc_timeout_or_signal "$type_probe_rc"; then
                    _mole_record_clean_cancellation "$type_probe_rc"
                    return "$type_probe_rc"
                fi
                if [[ $type_probe_rc -ne 0 ]]; then
                    type_probe_rc=0
                    _mole_bounded_sudo "$MOLE_TIMEOUT_QUICK_DETECT_SEC" \
                        -n test -d "$path" < /dev/null 2> /dev/null || type_probe_rc=$?
                    if mole_rc_timeout_or_signal "$type_probe_rc"; then
                        _mole_record_clean_cancellation "$type_probe_rc"
                        return "$type_probe_rc"
                    fi
                fi
                if [[ $type_probe_rc -eq 0 ]]; then
                    local mod_time=0
                    local stat_rc=0
                    mod_time=$(_mole_bounded_sudo "$MOLE_TIMEOUT_QUICK_DETECT_SEC" \
                        -n "$STAT_BSD" -f%m "$path" < /dev/null 2> /dev/null) || stat_rc=$?
                    if mole_rc_timeout_or_signal "$stat_rc"; then
                        _mole_record_clean_cancellation "$stat_rc"
                        return "$stat_rc"
                    fi
                    [[ $stat_rc -eq 0 ]] || mod_time=0
                    local now
                    now=$(date +%s 2> /dev/null || echo "0")
                    if [[ "$mod_time" -gt 0 && "$now" -gt 0 ]]; then
                        local age_seconds=$((now - mod_time))
                        file_age=$(format_duration_human "$age_seconds")
                    fi
                fi
            fi

            log_info "[DRY-RUN] Would sudo remove: $file_type $path"
            [[ -n "$file_size" ]] && log_info "  Size: $file_size"
            [[ -n "$file_age" ]] && log_info "  Age: $file_age"
        else
            log_info "[DRY-RUN] Would sudo remove: $path"
        fi
        return 0
    fi

    local size_kb=0
    local size_human=""
    if oplog_enabled; then
        if [[ -n "$precomputed_size_kb" ]]; then
            if [[ "$precomputed_size_kb" =~ ^[0-9]+$ ]]; then
                size_kb="$precomputed_size_kb"
            fi
        else
            local exists_probe_rc=0
            local exists_probe_timeout=""
            exists_probe_timeout=$(_mole_timeout_with_deadline "$MOLE_TIMEOUT_QUICK_DETECT_SEC" \
                "$deadline_seconds") || exists_probe_rc=$?
            if [[ $exists_probe_rc -eq 0 ]]; then
                _mole_bounded_sudo "$exists_probe_timeout" \
                    -n test -e "$path" < /dev/null 2> /dev/null || exists_probe_rc=$?
            fi
            if mole_rc_timeout "$exists_probe_rc"; then
                _mole_record_clean_cancellation 124
                return 124
            fi
            if [[ $exists_probe_rc -ge 128 ]]; then
                _mole_record_clean_cancellation "$exists_probe_rc"
                return "$exists_probe_rc"
            fi
            if [[ $exists_probe_rc -eq 0 ]]; then
                local size_probe_rc=0
                local size_probe_timeout=""
                size_probe_timeout=$(_mole_timeout_with_deadline "$MOLE_TIMEOUT_DISK_VERIFY_SEC" \
                    "$deadline_seconds") || size_probe_rc=$?
                if [[ $size_probe_rc -eq 0 ]]; then
                    size_kb=$(_mole_bounded_sudo "$size_probe_timeout" \
                        -n du -skP "$path" < /dev/null 2> /dev/null | awk '{print $1}') || size_probe_rc=$?
                fi
                if mole_rc_timeout "$size_probe_rc"; then
                    MOLE_CLEAN_SIZING_TIMEOUTS=$((${MOLE_CLEAN_SIZING_TIMEOUTS:-0} + 1))
                fi
                if [[ $size_probe_rc -ge 128 ]]; then
                    _mole_record_clean_cancellation "$size_probe_rc"
                    return "$size_probe_rc"
                fi
                [[ $size_probe_rc -eq 0 && "$size_kb" =~ ^[0-9]+$ ]] || size_kb=0
            fi
        fi
        if [[ "$size_kb" =~ ^[0-9]+$ ]] && [[ "$size_kb" -gt 0 ]]; then
            size_human=$(bytes_to_human "$((size_kb * 1024))" 2> /dev/null || echo "${size_kb}KB")
        fi
    fi

    # Keep the same last-mile policy as safe_remove: privileged cleanup must
    # also fail closed if a compiled-model cache appears during size probing.
    if declare -f holds_compiled_model_cache > /dev/null 2>&1 && holds_compiled_model_cache "$path" 2> /dev/null; then
        debug_log "Skipped sudo removal after compiled model cache appeared: $path"
        log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "compiled model cache"
        return "$MOLE_ERR_PROTECTED_PATH"
    fi

    local output
    local ret=0
    if [[ -n "$expected_parent" ]] && ! _mole_path_matches_identity \
        "$path" "$expected_parent" "$expected_parent_id" "$expected_target_id"; then
        debug_log "Refusing privileged removal after final path identity changed: $path"
        log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "identity changed"
        return 1
    fi
    local remove_timeout=""
    local section_deadline_spent=0
    remove_timeout=$(_mole_timeout_with_deadline "$MOLE_TIMEOUT_DISK_VERIFY_SEC" \
        "$deadline_seconds") || ret=$?
    if [[ $ret -eq 0 ]]; then
        _mole_owned_path_still_valid "$path" \
            "$expected_file_sha256" "$expected_absent_path" \
            "$expected_parent" "$expected_parent_id" "$expected_target_id" || return $?
        output=$(_mole_bounded_sudo "$remove_timeout" \
            -n rm -rf "$path" < /dev/null 2>&1) || ret=$? # SAFE: safe_sudo_remove validated the exact immutable-ancestor target above
    else
        # The section's own wall-clock budget ran out, so rm never started.
        section_deadline_spent=1
    fi

    if [[ $ret -eq 0 ]]; then
        log_operation "${MOLE_CURRENT_COMMAND:-clean}" "REMOVED" "$path" "$size_human"
        return 0
    fi

    if mole_rc_timeout "$ret"; then
        if [[ $section_deadline_spent -eq 1 ]]; then
            # The section prints its own "time limit reached" line; counting it
            # here too would tell the user to raise the per-item removal budget,
            # which is not the budget that ran out.
            log_operation "${MOLE_CURRENT_COMMAND:-clean}" "SKIPPED" "$path" "section time limit reached"
        else
            log_operation "${MOLE_CURRENT_COMMAND:-clean}" "FAILED" "$path" "removal timed out"
            MOLE_CLEAN_REMOVAL_TIMEOUTS=$((${MOLE_CLEAN_REMOVAL_TIMEOUTS:-0} + 1))
            _mole_record_removal_timeout_path "$path"
        fi
        return 124
    fi
    if [[ $ret -ge 128 ]]; then
        _mole_record_clean_cancellation "$ret"
        return "$ret"
    fi

    case "$output" in
        *"a password is required"* | *"a terminal is required"* | *"Password:"*)
            log_operation "${MOLE_CURRENT_COMMAND:-clean}" "FAILED" "$path" "auth required"
            return "$MOLE_ERR_AUTH_FAILED"
            ;;
        *"Operation not permitted"*)
            log_operation "${MOLE_CURRENT_COMMAND:-clean}" "FAILED" "$path" "sip/mdm protected"
            return "$MOLE_ERR_SIP_PROTECTED"
            ;;
        *"Read-only file system"*)
            log_operation "${MOLE_CURRENT_COMMAND:-clean}" "FAILED" "$path" "readonly filesystem"
            return "$MOLE_ERR_READONLY_FS"
            ;;
        *"Sorry, try again"* | *"incorrect passphrase"* | *"incorrect credentials"*)
            log_operation "${MOLE_CURRENT_COMMAND:-clean}" "FAILED" "$path" "auth failed"
            return "$MOLE_ERR_AUTH_FAILED"
            ;;
        *)
            log_error "Failed to remove, sudo: $path"
            log_operation "${MOLE_CURRENT_COMMAND:-clean}" "FAILED" "$path" "sudo error"
            return 1
            ;;
    esac
}

# ============================================================================
# Unified deletion helper (Trash + permanent routing with forensic log)
# ============================================================================

# Capture the device, inode, and mtime contract accepted by mole_delete.
# Failure never falls back to a path-only identity.
mole_deletion_identity() {
    local path="$1"
    local duration identity
    duration=$(_mole_timeout_with_deadline "$MOLE_TIMEOUT_QUICK_DETECT_SEC" "${2:-}") || return $?
    identity=$(run_with_timeout "$duration" "$STAT_BSD" -f%d:%i:%m "$path" < /dev/null 2> /dev/null) || return $?
    [[ "$identity" =~ ^[0-9]+:[0-9]+:-?[0-9]+$ ]] || return 1
    printf '%s\n' "$identity"
}

# Bind owner decisions to file contents across slow probes. The caller also
# supplies path identity so an atomic replacement cannot inherit approval.
mole_file_sha256() {
    local timeout="$MOLE_TIMEOUT_QUICK_DETECT_SEC"
    if [[ -n "${2:-}" ]]; then
        timeout=$(_mole_timeout_with_deadline "$timeout" "$2") || return $?
    fi
    local output=""
    output=$(run_with_timeout "$timeout" \
        shasum -a 256 -- "$1" < /dev/null 2> /dev/null) || return $?
    [[ "$output" =~ ^[0-9a-f]{64}[[:space:]] ]] || return 1
    printf '%s\n' "${output:0:64}"
}

_mole_expected_path_absent() {
    local path="${1:-}"
    [[ -z "$path" || (! -e "$path" && ! -L "$path") ]]
}

_mole_owned_path_still_valid() {
    local path="$1"
    local expected_file_sha256="${2:-}"
    local expected_absent_path="${3:-}"
    local expected_parent="${4:-}"
    local expected_parent_id="${5:-}"
    local expected_target_id="${6:-}"
    local deadline="${7:-}"
    if [[ -n "$expected_file_sha256" ]]; then
        local current_sha256="" hash_rc=0
        current_sha256=$(mole_file_sha256 "$path" "$deadline") || hash_rc=$?
        mole_rc_timeout_or_signal "$hash_rc" && return "$hash_rc"
        [[ $hash_rc -eq 0 && "$current_sha256" == "$expected_file_sha256" ]] || return "$MOLE_ERR_OWNER_UNVERIFIED"
    fi
    # Hashing reads a file descriptor while the sink acts on a pathname. A
    # replacement installed during the hash must not inherit its approval.
    if [[ -n "$expected_parent" ]] && ! _mole_path_matches_identity \
        "$path" "$expected_parent" "$expected_parent_id" "$expected_target_id"; then
        return "$MOLE_ERR_OWNER_UNVERIFIED"
    fi
    _mole_expected_path_absent "$expected_absent_path" || return "$MOLE_ERR_APP_REAPPEARED"
}

_mole_report_unverified_delete() {
    local path="$1"
    local mode="$2"
    local size_kb="$3"
    local reason="${4:-$MOLE_ERR_OWNER_UNVERIFIED}"
    local refusal_reason="ownership-unverified"
    local detail="agent ownership unverified"
    local explanation="the agent file changed or could not be inspected. Review the plist before retrying."
    if [[ $reason -eq $MOLE_ERR_APP_REAPPEARED ]]; then
        refusal_reason="app-reappeared"
        detail="selected app path reappeared"
        explanation="the selected app path exists again. Select the app and review its removal plan."
    fi
    _mole_delete_log "$mode" "$size_kb" "$refusal_reason" "$path"
    log_operation "${MOLE_CURRENT_COMMAND:-uninstall}" "SKIPPED" "$path" "$detail"
    _mole_record_uninstall_refusal "$path" "$refusal_reason"
    if [[ "${_MOLE_UNINSTALL_REFUSALS_ACTIVE:-0}" != 1 ]]; then
        printf 'Kept %s: %s\n' "$path" "$explanation" >&2
    fi
}

# Route a deletion through either macOS Trash or permanent rm, while logging
# every call for forensic review. Designed for destructive paths where undo
# matters (e.g. uninstall). Not used by cache-clean paths.
#
# Usage: mole_delete <path> [needs_sudo=false] [expected_dev_inode_mtime] [expected_file_sha256] [expected_absent_path]
#
# Environment:
#   MOLE_DELETE_MODE      "permanent" (default) or "trash"; other values fail
#   MOLE_DRY_RUN=1        Log intent, do not delete
#   MOLE_TEST_TRASH_DIR   Test-only override, honored only with MOLE_TEST_MODE=1
#                         or MOLE_TEST_NO_AUTH=1; Trash moves go here via `mv`
#                         instead of Finder/trash CLI. Required for bats.
#   MOLE_DELETE_LOG       Override the log file path (default:
#                         ~/Library/Logs/mactools/mole/deletions.log)
#
# Returns 0 on success and a nonzero MOLE_ERR_* code on failure. Always appends a tab-separated line to
# the deletions log: <iso_ts>\t<mode>\t<size_kb>\t<status>\t<path>.
# Control bytes in any field are written as \n, \r, \t or \xHH so a name cannot
# start a record; backslashes stay literal.
# size_kb is "unknown" when du could not measure the path (permission denied,
# disappeared mid-call); never silently coerced to 0KB so post-hoc forensics
# can tell measured-zero from measurement-failure.
mole_delete() {
    local path="$1"
    local needs_sudo="${2:-false}"
    local expected_identity="${3:-}"
    local expected_file_sha256="${4:-}"
    local expected_absent_path="${5:-}"
    local mode="${MOLE_DELETE_MODE:-permanent}"

    [[ -z "$path" ]] && return 1

    case "$mode" in
        permanent | trash) ;;
        *)
            _mole_delete_log "$mode" "unknown" "invalid-mode" "$path"
            if [[ -z "${_MOLE_INVALID_MODE_WARNED:-}" ]]; then
                _MOLE_INVALID_MODE_WARNED=1
                export _MOLE_INVALID_MODE_WARNED
                printf 'Error: invalid MOLE_DELETE_MODE: %s (expected "permanent" or "trash")\n' "$mode" >&2
            fi
            return 1
            ;;
    esac

    # Nothing to do if path does not exist (but a broken symlink still counts).
    if [[ ! -e "$path" && ! -L "$path" ]]; then
        return 0
    fi

    # Validation is delegated to the underlying safe_* helpers (which call
    # validate_path_for_deletion). Trash routing only applies to paths the
    # user could legitimately restore from, so we short-circuit invalid paths
    # up front to avoid a no-op Trash move followed by a validation failure.
    # The rejection itself is recorded in the forensic log so audit trails
    # can distinguish refused-by-policy from never-attempted.
    local validation_rc=0
    validate_path_for_deletion "$path" || validation_rc=$?
    if mole_rc_timeout_or_signal "$validation_rc"; then
        local validation_status="interrupted"
        mole_rc_timeout "$validation_rc" && validation_status="timed-out"
        _mole_delete_log "$mode" "unknown" "$validation_status" "$path"
        return "$validation_rc"
    fi
    if [[ $validation_rc -ne 0 ]]; then
        _mole_delete_log "$mode" "0" "rejected" "$path"
        log_operation "${MOLE_CURRENT_COMMAND:-uninstall}" "SKIPPED" "$path" "${_MOLE_VALIDATION_REASON:-protected}"
        return 1
    fi

    if [[ "$needs_sudo" == "true" ]] && _mole_privileged_path_has_mutable_ancestor "$path"; then
        # Neither sudo rm/mv nor Finder authorization is safe here: both receive
        # a pathname that a non-root invoking user can replace after validation.
        # Finder also fails for some package-installed apps even after its native
        # authorization dialog (#1266). Keep both Trash and permanent modes
        # fail-closed and direct the user to perform the app move themselves.
        _mole_delete_log "$mode" "unknown" "mutable-parent" "$path"
        debug_log "Refusing privileged delete below mutable parent: $path"
        return "$MOLE_ERR_MUTABLE_PARENT"
    fi

    # Capture size before the delete so the log line is still useful when the
    # path is gone afterwards. Use "unknown" (not 0) on failure so the log
    # never lies about a multi-GB delete by recording it as 0KB.
    local size_kb="unknown"
    if [[ -e "$path" ]]; then
        local raw_size=""
        local du_rc=0
        if [[ "$needs_sudo" == "true" ]]; then
            if [[ "${MOLE_TEST_MODE:-0}" == "1" || "${MOLE_TEST_NO_AUTH:-0}" == "1" ]]; then
                du_rc=1
            else
                raw_size=$(run_with_timeout "$MOLE_TIMEOUT_DISK_VERIFY_SEC" \
                    sudo -n du -skP "$path" 2> /dev/null |
                    awk '{print $1; exit}') || du_rc=$?
            fi
        else
            raw_size=$(get_path_size_kb "$path" 2> /dev/null) || du_rc=$?
        fi
        if [[ "$du_rc" -eq 0 && "$raw_size" =~ ^[0-9]+$ ]]; then
            size_kb="$raw_size"
        fi
        # Ctrl-C and other signals are cancellation, not an unknown-size
        # measurement. Stop before any dry-run registration, Trash move, or
        # permanent removal so the user's interrupt cannot be ignored.
        if mole_rc_timeout_or_signal "$du_rc"; then
            local cancel_status="interrupted"
            mole_rc_timeout "$du_rc" && cancel_status="timed-out"
            _mole_delete_log "$mode" "$size_kb" "$cancel_status" "$path"
            return "$du_rc"
        fi
    fi

    local expected_parent=""
    local expected_parent_id=""
    local expected_target_id=""
    if [[ -n "$expected_identity" ]]; then
        if ! _mole_snapshot_path_identity "$path"; then
            _mole_delete_log "$mode" "$size_kb" "identity-changed" "$path"
            return 1
        fi
        expected_parent="$_MOLE_PATH_SNAPSHOT_PARENT"
        expected_parent_id="$_MOLE_PATH_SNAPSHOT_PARENT_ID"
        expected_target_id="$_MOLE_PATH_SNAPSHOT_TARGET_ID"
        local current_identity=""
        local identity_rc=0
        current_identity=$(mole_deletion_identity "$path") || identity_rc=$?
        if mole_rc_timeout_or_signal "$identity_rc"; then
            local identity_status="interrupted"
            mole_rc_timeout "$identity_rc" && identity_status="timed-out"
            _mole_delete_log "$mode" "$size_kb" "$identity_status" "$path"
            return "$identity_rc"
        fi
        if [[ $identity_rc -ne 0 || "$current_identity" != "$expected_identity" ||
            "$expected_target_id" != "${expected_identity%:*}" ||
            "$expected_target_id" != "${current_identity%:*}" ]]; then
            if [[ -n "$expected_file_sha256" ]]; then
                _mole_report_unverified_delete "$path" "$mode" "$size_kb"
            else
                _mole_delete_log "$mode" "$size_kb" "identity-changed" "$path"
                debug_log "Refusing deletion after selected path identity changed: $path"
            fi
            return 1
        fi
    fi

    if [[ -n "$expected_file_sha256" ]]; then
        [[ -n "$expected_identity" ]] || return 1
        local current_sha256="" hash_rc=0
        current_sha256=$(mole_file_sha256 "$path") || hash_rc=$?
        if mole_rc_timeout_or_signal "$hash_rc"; then
            local hash_status="interrupted"
            mole_rc_timeout "$hash_rc" && hash_status="timed-out"
            _mole_delete_log "$mode" "$size_kb" "$hash_status" "$path"
            return "$hash_rc"
        fi
        if [[ $hash_rc -ne 0 || "$current_sha256" != "$expected_file_sha256" ]]; then
            _mole_report_unverified_delete "$path" "$mode" "$size_kb"
            return 1
        fi
        if ! _mole_path_matches_identity "$path" "$expected_parent" \
            "$expected_parent_id" "$expected_target_id"; then
            _mole_report_unverified_delete "$path" "$mode" "$size_kb"
            return 1
        fi
    fi

    if ! _mole_expected_path_absent "$expected_absent_path"; then
        _mole_report_unverified_delete "$path" "$mode" "$size_kb" "$MOLE_ERR_APP_REAPPEARED"
        return 1
    fi

    if [[ "${MOLE_DRY_RUN:-0}" == "1" ]]; then
        local preview_rc=0
        if [[ "$size_kb" =~ ^[0-9]+$ ]]; then
            _record_file_ops_dry_run_target "$path" "$size_kb" || preview_rc=$?
        else
            _record_file_ops_dry_run_target "$path" || preview_rc=$?
        fi
        if mole_rc_timeout_or_signal "$preview_rc"; then
            local preview_status="interrupted"
            mole_rc_timeout "$preview_rc" && preview_status="timed-out"
            _mole_delete_log "$mode" "$size_kb" "$preview_status" "$path"
            return "$preview_rc"
        fi
        debug_log "[DRY RUN] Would delete ($mode): $path"
        _mole_delete_log "$mode" "$size_kb" "dry-run" "$path"
        return 0
    fi

    if [[ "$needs_sudo" == "true" ]]; then
        if [[ "${MOLE_TEST_MODE:-0}" == "1" || "${MOLE_TEST_NO_AUTH:-0}" == "1" ]]; then
            _mole_delete_log "$mode" "$size_kb" "sudo-blocked-test-mode" "$path"
            return 1
        fi
    fi

    # Trash mode is a recoverable-delete contract. If Trash is unavailable,
    # fail closed instead of silently switching to permanent removal.
    if [[ "$mode" == "trash" ]]; then
        local trash_rc=0
        _mole_move_to_trash "$path" "$needs_sudo" \
            "$expected_parent" "$expected_parent_id" \
            "$expected_target_id" "$expected_file_sha256" \
            "$expected_absent_path" || trash_rc=$?
        if [[ $trash_rc -eq 0 ]]; then
            _mole_delete_log "trash" "$size_kb" "ok" "$path"
            log_operation "${MOLE_CURRENT_COMMAND:-uninstall}" "TRASHED" "$path" "${size_kb}KB"
            return 0
        fi
        if [[ $trash_rc -eq $MOLE_ERR_PRIVACY_DENIED ]]; then
            _mole_record_uninstall_refusal "$path" access-denied
            _mole_delete_log "trash" "$size_kb" "privacy-denied" "$path"
            log_operation "${MOLE_CURRENT_COMMAND:-uninstall}" "SKIPPED" "$path" "privacy permission denied"
            if [[ -z "${_MOLE_PRIVACY_DENIED_WARNED:-}" ]]; then
                _MOLE_PRIVACY_DENIED_WARNED=1
                export _MOLE_PRIVACY_DENIED_WARNED
                declare -F stop_inline_spinner > /dev/null && stop_inline_spinner
                printf 'Error: macOS denied Trash access. Try moving the item to Trash in Finder. Run with --debug for details.\n' >&2
            fi
            debug_log "macOS privacy permission denied while moving to Trash: $path"
            return "$MOLE_ERR_PRIVACY_DENIED"
        fi
        if [[ $trash_rc -eq $MOLE_ERR_MUTABLE_PARENT ]]; then
            _mole_delete_log "trash" "$size_kb" "mutable-parent" "$path"
            log_operation "${MOLE_CURRENT_COMMAND:-uninstall}" "SKIPPED" "$path" "mutable-parent"
            debug_log "Trash move stopped because a mutable parent was detected: $path"
            return "$MOLE_ERR_MUTABLE_PARENT"
        fi
        if [[ $trash_rc -eq $MOLE_ERR_OWNER_UNVERIFIED ||
            $trash_rc -eq $MOLE_ERR_APP_REAPPEARED ]]; then
            _mole_report_unverified_delete "$path" "$mode" "$size_kb" "$trash_rc"
            return 1
        fi
        if mole_rc_timeout_or_signal "$trash_rc"; then
            local trash_status="interrupted"
            mole_rc_timeout "$trash_rc" && trash_status="timed-out"
            _mole_delete_log "trash" "$size_kb" "$trash_status" "$path"
            return "$trash_rc"
        fi
        _mole_delete_log "trash" "$size_kb" "trash-failed" "$path"
        log_operation "${MOLE_CURRENT_COMMAND:-uninstall}" "SKIPPED" "$path" "trash-failed"
        if [[ -z "${_MOLE_TRASH_UNAVAILABLE_WARNED:-}" ]]; then
            _MOLE_TRASH_UNAVAILABLE_WARNED=1
            export _MOLE_TRASH_UNAVAILABLE_WARNED
            declare -F stop_inline_spinner > /dev/null && stop_inline_spinner
            printf 'Error: Trash unavailable; refusing permanent delete. Use --permanent to delete immediately.\n' >&2
        fi
        debug_log "Trash move failed, refusing permanent delete: $path"
        return 1
    fi

    # Permanent path. Delegate to the existing safe_* helpers so path
    # validation, sudo handling, and existing log_operation calls remain
    # unchanged for callers that have always gone through rm -rf.
    local rc=0
    if [[ "$needs_sudo" == "true" ]] && _mole_privileged_path_has_mutable_ancestor "$path"; then
        # Recheck at the permanent-delete sink. The parent may have become
        # mutable while size accounting was running. This check covers both
        # regular paths and symlinks before either helper can downgrade.
        rc=$MOLE_ERR_MUTABLE_PARENT
    elif [[ -L "$path" ]]; then
        safe_remove_symlink "$path" "$needs_sudo" \
            "$expected_parent" "$expected_parent_id" \
            "$expected_target_id" "$expected_file_sha256" \
            "$expected_absent_path" || rc=$?
    elif [[ "$needs_sudo" == "true" ]]; then
        safe_sudo_remove "$path" "$size_kb" "" \
            "$expected_parent" "$expected_parent_id" \
            "$expected_target_id" "$expected_file_sha256" \
            "$expected_absent_path" || rc=$?
    else
        safe_remove "$path" "true" "$size_kb" "" \
            "$expected_parent" "$expected_parent_id" \
            "$expected_target_id" "$expected_file_sha256" \
            "$expected_absent_path" || rc=$?
    fi

    local status_label="ok"
    if [[ $rc -eq $MOLE_ERR_OWNER_UNVERIFIED ||
        $rc -eq $MOLE_ERR_APP_REAPPEARED ]]; then
        _mole_report_unverified_delete "$path" "$mode" "$size_kb" "$rc"
        return 1
    fi
    if [[ $rc -eq $MOLE_ERR_MUTABLE_PARENT ]]; then
        status_label="mutable-parent"
    elif mole_rc_timeout "$rc"; then
        status_label="timed-out"
    elif [[ $rc -ge 128 ]]; then
        status_label="interrupted"
    elif [[ $rc -ne 0 ]]; then
        status_label="error"
    fi
    _mole_delete_log "$mode" "$size_kb" "$status_label" "$path"
    return "$rc"
}

_mole_valid_invoking_home() {
    local user_home=""
    if declare -f get_invoking_home > /dev/null 2>&1; then
        user_home=$(get_invoking_home)
    else
        user_home="${MOLE_USER_HOME:-${HOME:-}}"
    fi

    if [[ -z "$user_home" || "$user_home" != /* || "$user_home" == "/" || "$user_home" == "/var/root" ]]; then
        debug_log "Refusing direct Trash move: invalid invoking user home: ${user_home:-<empty>}"
        return 1
    fi

    printf '%s\n' "${user_home%/}"
}

_mole_path_is_immediate_child_of() {
    local path="${1%/}"
    local parent="${2%/}"
    [[ "$path" == "$parent/"* ]] || return 1

    local child="${path#"$parent"/}"
    [[ -n "$child" && "$child" != */* ]]
}

_mole_path_is_application_bundle() {
    local path="${1%/}"
    _mole_path_is_immediate_child_of "$path" "/Applications" &&
        [[ "${path##*/}" == *.[aA][pP][pP] ]]
}

# Finder and third-party Trash helpers can fail on app bundles and TCC-managed
# app data even after authentication. Route only these exact one-level targets
# through the direct, recoverable Trash mover.
_mole_path_requires_direct_trash() {
    local path="${1%/}"
    if _mole_path_is_application_bundle "$path"; then
        return 0
    fi

    local user_home
    user_home=$(_mole_valid_invoking_home) || return 1
    _mole_path_is_immediate_child_of "$path" "$user_home/Library/Containers" && return 0
    _mole_path_is_immediate_child_of "$path" "$user_home/Library/Group Containers" && return 0
    _mole_path_is_immediate_child_of "$path" "$user_home/Library/Application Scripts" && return 0
    return 1
}

# Refresh the process evidence for one Trash target, then rebind its physical
# identity. The process table may be reused during discovery, but a distinct app
# can start before a later item reaches the move sink; stale evidence must never
# authorize that move.
_mole_trash_target_still_safe() {
    local path="$1"
    local expected_parent="${2:-}"
    local expected_parent_id="${3:-}"
    local expected_target_id="${4:-}"
    local expected_file_sha256="${5:-}"

    _mole_reset_process_snapshot
    local live_cache_guard_rc=0
    _mole_should_refuse_live_user_cache_path "$path" || live_cache_guard_rc=$?
    if [[ $live_cache_guard_rc -eq 0 ]]; then
        _mole_record_uninstall_refusal "$path" live-cache
        debug_log "Skipped Trash move after live user cache appeared: $path"
        log_operation "${MOLE_CURRENT_COMMAND:-uninstall}" "SKIPPED" "$path" "live user cache"
        return 1
    fi
    if mole_rc_timeout_or_signal "$live_cache_guard_rc"; then
        _mole_record_clean_cancellation "$live_cache_guard_rc"
        return "$live_cache_guard_rc"
    fi

    if [[ -n "$expected_parent" ]]; then
        if ! _mole_bound_path_matches "$path" "$expected_parent" \
            "$expected_parent_id" "$expected_target_id"; then
            [[ -n "$expected_file_sha256" ]] && return "$MOLE_ERR_OWNER_UNVERIFIED"
            return 1
        fi
        return 0
    fi
    _mole_bound_path_matches "$path" "$_MOLE_CONTAINER_CACHE_PROBE_PARENT" \
        "$_MOLE_CONTAINER_CACHE_PROBE_PARENT_ID" \
        "$_MOLE_CONTAINER_CACHE_PROBE_TARGET_ID"
}

# Finder's Trash API can move package-installed app bundles that macOS App
# Management blocks from a direct mv. Run it only as the invoking user and only
# for an exact one-level /Applications/*.app target selected above.
_mole_move_app_to_trash_via_finder() {
    local path="$1"
    local expected_parent="${2:-}"
    local expected_parent_id="${3:-}"
    local expected_target_id="${4:-}"
    local expected_file_sha256="${5:-}"
    local expected_absent_path="${6:-}"
    local finder_rc=0

    _mole_path_is_application_bundle "$path" || return 1
    _mole_trash_target_still_safe "$path" "$expected_parent" \
        "$expected_parent_id" "$expected_target_id" "$expected_file_sha256" || return $?
    _mole_owned_path_still_valid "$path" \
        "$expected_file_sha256" "$expected_absent_path" \
        "$expected_parent" "$expected_parent_id" "$expected_target_id" || return $?

    local finder_output=""
    finder_output=$(
        run_with_timeout "$MOLE_TIMEOUT_DISK_VERIFY_SEC" osascript - "$path" 2>&1 > /dev/null << 'APPLESCRIPT'
on run argv
    set p to POSIX file (item 1 of argv)
    tell application "Finder"
        delete p
    end tell
end run
APPLESCRIPT
    ) || finder_rc=$?

    if [[ $finder_rc -ne 0 ]]; then
        debug_log "Finder failed to move application to Trash (exit $finder_rc): $path: $finder_output"
        mole_rc_timeout_or_signal "$finder_rc" && return "$finder_rc"
        if [[ "$finder_output" == *"(-1743)"* && -z "${_MOLE_FINDER_AUTOMATION_WARNED:-}" ]]; then
            _MOLE_FINDER_AUTOMATION_WARNED=1
            _MOLE_PRIVACY_DENIED_WARNED=1
            export _MOLE_PRIVACY_DENIED_WARNED
            declare -F stop_inline_spinner > /dev/null && stop_inline_spinner
            printf 'Error: macOS blocked Finder automation. Allow your terminal app to control Finder in System Settings > Privacy & Security > Automation, then retry.\n' >&2
        fi
        return 1
    elif [[ -e "$path" || -L "$path" ]]; then
        debug_log "Finder returned success but the application remains: $path"
        return 1
    fi

    debug_log "Finder moved application to Trash: $path"
    return 0
}

# Move a path to the macOS Trash. Test harnesses set MOLE_TEST_TRASH_DIR to
# redirect the move to a tmpdir, avoiding any Finder/osascript interaction.
_mole_move_to_trash() {
    local path="$1"
    local needs_sudo="${2:-false}"
    local expected_parent="${3:-}"
    local expected_parent_id="${4:-}"
    local expected_target_id="${5:-}"
    local expected_file_sha256="${6:-}"
    local expected_absent_path="${7:-}"

    # The override is test-only: an exported MOLE_TEST_TRASH_DIR in a real
    # run must not silently redirect a Trash move away from the user's Trash.
    if [[ -n "${MOLE_TEST_TRASH_DIR:-}" ]] &&
        [[ "${MOLE_TEST_MODE:-0}" == "1" || "${MOLE_TEST_NO_AUTH:-0}" == "1" ]]; then
        mkdir -p "$MOLE_TEST_TRASH_DIR" 2> /dev/null || return 1
        local dest="$MOLE_TEST_TRASH_DIR/$(basename "$path").$$.$(date +%s 2> /dev/null || echo 0)"
        _mole_trash_target_still_safe "$path" "$expected_parent" \
            "$expected_parent_id" "$expected_target_id" "$expected_file_sha256" || return $?
        _mole_owned_path_still_valid "$path" \
            "$expected_file_sha256" "$expected_absent_path" \
            "$expected_parent" "$expected_parent_id" "$expected_target_id" || return $?
        mv "$path" "$dest" 2> /dev/null
        return $?
    fi

    # Blocked in test mode so uninstall tests never hit Finder/AppleScript.
    if [[ "${MOLE_TEST_NO_AUTH:-0}" == "1" ]]; then
        return 1
    fi

    if [[ "$needs_sudo" == "true" ]]; then
        _mole_move_path_to_user_trash "$path" "$needs_sudo" \
            "$expected_parent" "$expected_parent_id" "$expected_target_id" \
            "$expected_file_sha256" "$expected_absent_path"
        return $?
    fi

    if _mole_path_requires_direct_trash "$path"; then
        local direct_rc=0
        _mole_move_path_to_user_trash "$path" false \
            "$expected_parent" "$expected_parent_id" \
            "$expected_target_id" "$expected_file_sha256" \
            "$expected_absent_path" || direct_rc=$?
        if [[ $direct_rc -eq $MOLE_ERR_PRIVACY_DENIED ]] &&
            _mole_path_is_application_bundle "$path"; then
            debug_log "Direct Trash move was denied; retrying application through Finder: $path"
            local finder_rc=0
            _mole_move_app_to_trash_via_finder "$path" \
                "$expected_parent" "$expected_parent_id" \
                "$expected_target_id" "$expected_file_sha256" \
                "$expected_absent_path" || finder_rc=$?
            [[ $finder_rc -eq 0 ]] && return 0
            mole_rc_timeout_or_signal "$finder_rc" && return "$finder_rc"
        fi
        return "$direct_rc"
    fi

    # Prefer the `trash` CLI (Homebrew formula) for normal user-owned paths.
    if command -v trash > /dev/null 2>&1; then
        local trash_rc=0
        _mole_trash_target_still_safe "$path" "$expected_parent" \
            "$expected_parent_id" "$expected_target_id" "$expected_file_sha256" || return $?
        _mole_owned_path_still_valid "$path" \
            "$expected_file_sha256" "$expected_absent_path" \
            "$expected_parent" "$expected_parent_id" "$expected_target_id" || return $?
        run_with_timeout "$MOLE_TIMEOUT_DISK_VERIFY_SEC" \
            trash "$path" > /dev/null 2>&1 || trash_rc=$?
        [[ $trash_rc -eq 0 ]] && return 0
        mole_rc_timeout_or_signal "$trash_rc" && return "$trash_rc"
    fi

    # AppleScript fallback. Pass the path via argv so special chars (quotes,
    # backslashes) cannot break out of the quoted string.
    _mole_trash_target_still_safe "$path" "$expected_parent" \
        "$expected_parent_id" "$expected_target_id" "$expected_file_sha256" || return $?
    _mole_owned_path_still_valid "$path" \
        "$expected_file_sha256" "$expected_absent_path" \
        "$expected_parent" "$expected_parent_id" "$expected_target_id" || return $?
    run_with_timeout "$MOLE_TIMEOUT_DISK_VERIFY_SEC" \
        osascript - "$path" > /dev/null 2>&1 << 'APPLESCRIPT'
on run argv
    set p to POSIX file (item 1 of argv)
    tell application "Finder"
        delete p
    end tell
end run
APPLESCRIPT
}

# /Library/Caches is mode 0777 on supported macOS releases, so it cannot anchor a
# privileged path operation. This prepares an exact root-owned parent under
# immutable /Library; mode 0711 lets the invoking user traverse into only the
# randomized staging directory handed to them later.
#
# Takes the root as an argument so the concurrency behaviour is reachable from a
# test without a real /Library write.
_mole_prepare_privileged_trash_stage_root() {
    local stage_root="$1"

    # Refuse an existing symlink before any ownership or mode operation. Only
    # root can mutate /Library, but a stale privileged symlink must not make
    # chown/chmod follow into an unrelated tree. Then mkdir -p rather than
    # test-then-mkdir: two concurrent Mole processes can both see a missing root,
    # and the loser of a plain mkdir would abort a Trash move that was safe.
    # Tolerating EEXIST costs nothing, because the verification below is what
    # actually decides whether this root can anchor the operation.
    if [[ -L "$stage_root" ]]; then
        return 1
    fi
    sudo -n /bin/mkdir -p "$stage_root" 2> /dev/null || return 1
    sudo -n /usr/sbin/chown 0:0 "$stage_root" 2> /dev/null || return 1
    sudo -n /bin/chmod -N "$stage_root" 2> /dev/null || return 1
    sudo -n /bin/chmod 711 "$stage_root" 2> /dev/null || return 1

    local root_uid=""
    local root_mode=""
    root_uid=$($STAT_BSD -f%u "$stage_root" 2> /dev/null || true)
    root_mode=$($STAT_BSD -f%Lp "$stage_root" 2> /dev/null || true)
    if [[ -L "$stage_root" || "$root_uid" != "0" || "$root_mode" != "711" ]]; then
        return 1
    fi
}

_mole_create_privileged_trash_stage() {
    local stage_root="/Library/MoleTrashStaging"
    local stage_dir=""

    _mole_prepare_privileged_trash_stage_root "$stage_root" || return 1

    stage_dir=$(sudo -n /usr/bin/mktemp -d "$stage_root/item.XXXXXX" 2> /dev/null) || return 1
    if [[ "$stage_dir" != "$stage_root"/item.* || ! -d "$stage_dir" || -L "$stage_dir" ]]; then
        return 1
    fi
    if _mole_privileged_path_has_mutable_ancestor "$stage_dir/item"; then
        sudo -n /bin/rm -rf "$stage_dir" 2> /dev/null || true # SAFE: exact empty staging directory created by mktemp above
        return 1
    fi
    printf '%s\n' "$stage_dir"
}

# The staging root is deliberately persistent. Removing it when it looked empty
# raced with a concurrent Mole process that had just validated it and was about
# to mktemp inside, turning a safe Trash move into a spurious failure.
#
# `mo remove` deliberately leaves it behind too. It is an empty root-owned
# directory, and removing it would add a privileged step to an uninstall that
# may need no privileges at all: a ~/.local-only install would meet a sudo
# prompt for nothing. Any non-empty state is a payload a failed Trash move
# preserved for the user, which uninstall must not touch either.

_mole_move_path_to_user_trash() {
    local path="$1"
    local needs_sudo="${2:-false}"
    local expected_parent="${3:-}"
    local expected_parent_id="${4:-}"
    local expected_target_id="${5:-}"
    local expected_file_sha256="${6:-}"
    local expected_absent_path="${7:-}"

    if [[ "${MOLE_TEST_MODE:-0}" == "1" || "${MOLE_TEST_NO_AUTH:-0}" == "1" ]]; then
        return 1
    fi

    local user_home
    user_home="${_MOLE_TRASH_BATCH_HOME:-}"
    [[ -n "$user_home" ]] || user_home=$(_mole_valid_invoking_home) || return 1

    if [[ -z "$path" ]] || [[ ! -e "$path" && ! -L "$path" ]]; then
        debug_log "Refusing direct Trash move: path does not exist: ${path:-<empty>}"
        return 1
    fi

    if [[ "$needs_sudo" == "true" ]] && _mole_privileged_path_has_mutable_ancestor "$path"; then
        debug_log "Refusing direct privileged Trash move below mutable parent: $path"
        return "$MOLE_ERR_MUTABLE_PARENT"
    fi

    local trash_dir="${user_home%/}/.Trash"
    local owner_uid="${_MOLE_TRASH_BATCH_UID:-}" owner_gid="${_MOLE_TRASH_BATCH_GID:-}"
    if [[ -z "$owner_uid" ]] && declare -f get_invoking_uid > /dev/null 2>&1; then
        owner_uid=$(get_invoking_uid)
    fi
    if [[ -z "$owner_gid" ]] && declare -f get_invoking_gid > /dev/null 2>&1; then
        owner_gid=$(get_invoking_gid)
    fi
    if [[ ! "$owner_uid" =~ ^[0-9]+$ || ! "$owner_gid" =~ ^[0-9]+$ ]]; then
        debug_log "Failed to resolve invoking user ownership for Trash"
        return 1
    fi

    # The destination must be the invoking user's Trash, even though sudo is
    # needed to unlink the original protected path.
    if [[ -L "$trash_dir" ]]; then
        debug_log "Refusing direct Trash move: invoking user Trash is a symlink: $trash_dir"
        return 1
    fi
    if [[ ! -d "$trash_dir" && ${EUID:-0} -eq 0 ]]; then
        sudo -n -u "#$owner_uid" mkdir -p "$trash_dir" 2> /dev/null || {
            debug_log "Failed to create invoking user Trash: $trash_dir"
            return 1
        }
    elif [[ ! -d "$trash_dir" ]] && ! mkdir -p "$trash_dir" 2> /dev/null; then
        debug_log "Failed to create invoking user Trash: $trash_dir"
        return 1
    fi
    if [[ ! -d "$trash_dir" || -L "$trash_dir" ]]; then
        debug_log "Refusing direct Trash move: invoking user Trash is not a normal directory: $trash_dir"
        return 1
    fi

    local trash_metadata="" trash_owner_uid="" trash_mode=""
    trash_metadata=$("$STAT_BSD" -f '%u:%Lp' "$trash_dir" 2> /dev/null) || return 1
    trash_owner_uid="${trash_metadata%%:*}"
    trash_mode="${trash_metadata#*:}"
    if [[ "$trash_owner_uid" != "$owner_uid" ]]; then
        debug_log "Refusing direct Trash move: invoking user does not own Trash: $trash_dir"
        return 1
    fi
    if [[ "$trash_mode" != 700 && ${EUID:-0} -eq 0 ]]; then
        if ! sudo -n -u "#$owner_uid" chmod 700 "$trash_dir" 2> /dev/null; then
            debug_log "Failed to set invoking user Trash permissions: $trash_dir"
            return 1
        fi
    elif [[ "$trash_mode" != 700 ]] && ! chmod 700 "$trash_dir" 2> /dev/null; then
        debug_log "Failed to set invoking user Trash permissions: $trash_dir"
        return 1
    fi

    # Avoid Finder-style ':' path weirdness and keep generated names filesystem-safe.
    local base
    base="$path"
    while [[ "$base" == */ && "$base" != / ]]; do base="${base%/}"; done
    base="${base##*/}"
    base="${base//:/__}"
    base="${base//\//__}"
    [[ -n "$base" && "$base" != "." && "$base" != ".." ]] || base="mole-trash-item"

    local dest="$trash_dir/$base"
    local ts suffix
    ts=""
    suffix=0

    while [[ -e "$dest" || -L "$dest" ]]; do
        suffix=$((suffix + 1))
        if [[ $suffix -gt 100 ]]; then
            debug_log "Failed to choose unique Trash destination for: $path"
            return 1
        fi
        [[ -n "$ts" ]] || ts=$(date +%s 2> /dev/null || echo 0)
        dest="$trash_dir/$base.$ts.$$.$suffix"
    done

    if [[ -n "$expected_parent" ]]; then
        if ! _mole_path_matches_identity \
            "$path" "$expected_parent" "$expected_parent_id" "$expected_target_id"; then
            debug_log "Refusing Trash move after selected path identity changed: $path"
            return 1
        fi
    elif [[ -n "${_MOLE_TRASH_MOVE_EXPECTED_PATH:-}" && "$_MOLE_TRASH_MOVE_EXPECTED_PATH" == "$path" ]]; then
        if ! _mole_path_matches_identity \
            "$path" \
            "$_MOLE_TRASH_MOVE_EXPECTED_PARENT" \
            "$_MOLE_TRASH_MOVE_EXPECTED_PARENT_ID" \
            "$_MOLE_TRASH_MOVE_EXPECTED_TARGET_ID"; then
            debug_log "Refusing Trash move after source path identity changed: $path"
            return 1
        fi
    fi

    local move_output=""
    local move_rc=0
    if [[ "$needs_sudo" == "true" ]]; then
        # Never point a root mv directly into ~/.Trash: that directory is
        # intentionally controlled by the invoking user and can be replaced
        # after validation. First cross the privileged boundary into a
        # root-owned staging directory, then perform the final Trash move with
        # only the invoking user's authority.
        local stage_dir=""
        local stage_path=""
        stage_dir=$(_mole_create_privileged_trash_stage) || {
            debug_log "Failed to create immutable Trash staging directory"
            return 1
        }
        stage_path="$stage_dir/item"

        # The first move must be a same-filesystem rename. A cross-volume mv
        # degrades into copy-then-delete and can leave the only payload split
        # between source and staging if it fails midway.
        local source_device=""
        local stage_device=""
        local device_rc=0
        source_device=$($STAT_BSD -f%d "$path" 2> /dev/null) || device_rc=$?
        mole_rc_timeout_or_signal "$device_rc" && return "$device_rc"
        if [[ $device_rc -eq 0 ]]; then
            stage_device=$($STAT_BSD -f%d "$stage_dir" 2> /dev/null) || device_rc=$?
        fi
        mole_rc_timeout_or_signal "$device_rc" && return "$device_rc"
        if [[ ! "$source_device" =~ ^[0-9]+$ || "$source_device" != "$stage_device" ]]; then
            sudo -n /bin/rm -rf "$stage_dir" 2> /dev/null || true # SAFE: exact empty staging directory created by mktemp above
            debug_log "Refusing cross-volume privileged Trash staging: $path"
            return 1
        fi

        local stage_move_rc=0
        local stage_guard_rc=0
        _mole_trash_target_still_safe "$path" "$expected_parent" \
            "$expected_parent_id" "$expected_target_id" \
            "$expected_file_sha256" || stage_guard_rc=$?
        if [[ $stage_guard_rc -eq 0 ]]; then
            _mole_owned_path_still_valid "$path" \
                "$expected_file_sha256" "$expected_absent_path" \
                "$expected_parent" "$expected_parent_id" "$expected_target_id" || stage_guard_rc=$?
        fi
        if [[ $stage_guard_rc -ne 0 ]]; then
            sudo -n /bin/rm -rf "$stage_dir" 2> /dev/null || true # SAFE: exact empty root-owned stage created for this item above
            return "$stage_guard_rc"
        fi
        sudo -n /bin/mv "$path" "$stage_path" 2> /dev/null || stage_move_rc=$?
        if [[ $stage_move_rc -ne 0 ]]; then
            if mole_rc_timeout_or_signal "$stage_move_rc"; then
                if [[ -e "$stage_path" || -L "$stage_path" ]]; then
                    log_error "Trash move interrupted; item preserved for recovery at: $stage_path"
                fi
                return "$stage_move_rc"
            fi
            sudo -n /bin/rm -rf "$stage_dir" 2> /dev/null || true # SAFE: exact root-owned directory created by mktemp above
            debug_log "Failed to move path into immutable Trash staging: $path"
            return 1
        fi
        # Keep the stage root-owned while ownership is repaired. `-h` keeps chown
        # off symlink targets, and `-x` keeps it from descending into a nested
        # mount: the same-device gate above only compares the payload root with
        # the stage, so a disk image or FUSE volume mounted *inside* the payload
        # is still reachable, and chown -R would rewrite ownership on that
        # filesystem and can block on it. Once either payload ownership or stage
        # ownership changes, preserve on any later failure rather than
        # reintroducing user-owned content into the privileged source path.
        local handoff_rc=0
        sudo -n /bin/chmod 700 "$stage_dir" 2> /dev/null || handoff_rc=$?
        if [[ $handoff_rc -eq 0 ]]; then
            sudo -n /usr/sbin/chown -Rhx "$owner_uid:$owner_gid" \
                "$stage_path" 2> /dev/null || handoff_rc=$?
        fi
        if [[ $handoff_rc -eq 0 ]]; then
            sudo -n /usr/sbin/chown "$owner_uid:$owner_gid" \
                "$stage_dir" 2> /dev/null || handoff_rc=$?
        fi
        if [[ $handoff_rc -ne 0 ]]; then
            if mole_rc_timeout_or_signal "$handoff_rc"; then
                log_error "Trash move interrupted; item preserved for recovery at: $stage_path"
                return "$handoff_rc"
            fi
            log_error "Trash move failed; item preserved for recovery at: $stage_path"
            debug_log "Failed to hand Trash staging directory to invoking user"
            return 1
        fi

        if [[ ${EUID:-0} -eq 0 ]]; then
            move_output=$(sudo -n -u "#$owner_uid" /bin/mv -n "$stage_path" "$dest" 2>&1) || move_rc=$?
        else
            move_output=$(/bin/mv -n "$stage_path" "$dest" 2>&1) || move_rc=$?
        fi

        if [[ $move_rc -ne 0 || -e "$stage_path" || -L "$stage_path" ]]; then
            if mole_rc_timeout_or_signal "$move_rc"; then
                if [[ -e "$stage_path" || -L "$stage_path" ]]; then
                    log_error "Trash move interrupted; item preserved for recovery at: $stage_path"
                elif [[ -e "$dest" || -L "$dest" ]]; then
                    debug_log "Trash move completed before interruption was observed: $dest"
                fi
                return "$move_rc"
            fi
            move_rc=1
            # stage_dir is user-controlled after the ownership handoff above.
            # Never let root resolve stage_path again: it may have been replaced
            # between the failed user move and this branch. Preserve the item
            # in staging and report the exact recovery location instead.
            log_error "Trash move failed; item preserved for recovery at: $stage_path"
        else
            # The invoking user owns stage_dir but has no write bit on the
            # root-owned 0711 parent, so only a privileged rmdir can unlink it.
            sudo -n /bin/rmdir "$stage_dir" 2> /dev/null || true
        fi
    else
        _mole_trash_target_still_safe "$path" "$expected_parent" \
            "$expected_parent_id" "$expected_target_id" "$expected_file_sha256" || return $?
        _mole_owned_path_still_valid "$path" \
            "$expected_file_sha256" "$expected_absent_path" \
            "$expected_parent" "$expected_parent_id" "$expected_target_id" || return $?
        move_output=$(mv -n "$path" "$dest" 2>&1) || move_rc=$?
    fi
    if [[ $move_rc -ne 0 ]]; then
        mole_rc_timeout_or_signal "$move_rc" && return "$move_rc"
        debug_log "Failed to move path directly to invoking user Trash: $path -> $dest: $move_output"
        case "$move_output" in
            *"Operation not permitted"* | *"operation not permitted"* | \
                *"Permission denied"* | *"permission denied"*)
                _mole_record_uninstall_refusal "$path" access-denied
                return "$MOLE_ERR_PRIVACY_DENIED"
                ;;
        esac
        return 1
    fi
    if [[ -e "$path" || -L "$path" ]] || [[ ! -e "$dest" && ! -L "$dest" ]]; then
        debug_log "Failed to move path directly without overwriting destination: $path -> $dest"
        return 1
    fi

    debug_log "Moved path directly to invoking user Trash: $path -> $dest"
    return 0
}

# Batched Trash move for non-sudo, non-symlink paths. Removes the per-file
# Finder/AppleScript fan-out that made uninstalls feel frozen. The caller binds
# each item to its original physical parent and inode through the snapshot
# arrays below; this helper rechecks that identity before every direct move.
_MOLE_TRASH_BATCH_SNAPSHOT_PATHS=()
_MOLE_TRASH_BATCH_SNAPSHOT_PARENTS=()
_MOLE_TRASH_BATCH_SNAPSHOT_PARENT_IDS=()
_MOLE_TRASH_BATCH_SNAPSHOT_TARGET_IDS=()
_MOLE_TRASH_BATCH_MOVED_PATHS=()
_MOLE_TRASH_MOVE_EXPECTED_PATH=""
_MOLE_TRASH_MOVE_EXPECTED_PARENT=""
_MOLE_TRASH_MOVE_EXPECTED_PARENT_ID=""
_MOLE_TRASH_MOVE_EXPECTED_TARGET_ID=""

_MOLE_PATH_SNAPSHOT_PARENT=""
_MOLE_PATH_SNAPSHOT_PARENT_ID=""
_MOLE_PATH_SNAPSHOT_TARGET_ID=""

_mole_snapshot_path_identity() {
    local path="$1"
    _MOLE_PATH_SNAPSHOT_PARENT=""
    _MOLE_PATH_SNAPSHOT_PARENT_ID=""
    _MOLE_PATH_SNAPSHOT_TARGET_ID=""

    [[ -e "$path" || -L "$path" ]] || return 1
    local lexical_parent="${path%/*}"
    [[ -n "$lexical_parent" && "$lexical_parent" != "$path" ]] || lexical_parent="/"

    local physical_parent=""
    physical_parent=$(cd -P "$lexical_parent" 2> /dev/null && pwd -P) || return 1
    local parent_id=""
    local target_id=""
    local identities=""
    identities=$("$STAT_BSD" -f '%d:%i' "$physical_parent" "$path" 2> /dev/null) || return 1
    [[ "$identities" == *$'\n'* ]] || return 1
    parent_id="${identities%%$'\n'*}"
    target_id="${identities#*$'\n'}"
    [[ "$parent_id" =~ ^[0-9]+:[0-9]+$ && "$target_id" =~ ^[0-9]+:[0-9]+$ ]] || return 1

    _MOLE_PATH_SNAPSHOT_PARENT="$physical_parent"
    _MOLE_PATH_SNAPSHOT_PARENT_ID="$parent_id"
    _MOLE_PATH_SNAPSHOT_TARGET_ID="$target_id"
}

_mole_path_matches_identity() {
    local path="$1"
    local expected_parent="$2"
    local expected_parent_id="$3"
    local expected_target_id="$4"

    _mole_snapshot_path_identity "$path" || return 1
    [[ "$_MOLE_PATH_SNAPSHOT_PARENT" == "$expected_parent" ]] || return 1
    [[ "$_MOLE_PATH_SNAPSHOT_PARENT_ID" == "$expected_parent_id" ]] || return 1
    [[ "$_MOLE_PATH_SNAPSHOT_TARGET_ID" == "$expected_target_id" ]]
}

_mole_bound_path_matches() {
    local path="$1"
    local expected_parent="${2:-}"
    local expected_parent_id="${3:-}"
    local expected_target_id="${4:-}"
    [[ -z "$expected_parent" ]] && return 0
    _mole_path_matches_identity \
        "$path" "$expected_parent" "$expected_parent_id" "$expected_target_id"
}

_mole_move_to_trash_batch() {
    local -a paths=("$@")
    [[ ${#paths[@]} -eq 0 ]] && return 0
    _MOLE_TRASH_BATCH_MOVED_PATHS=()

    local use_bound_snapshots=false
    if [[ ${#_MOLE_TRASH_BATCH_SNAPSHOT_PATHS[@]} -eq ${#paths[@]} &&
        ${#_MOLE_TRASH_BATCH_SNAPSHOT_PARENTS[@]} -eq ${#paths[@]} &&
        ${#_MOLE_TRASH_BATCH_SNAPSHOT_PARENT_IDS[@]} -eq ${#paths[@]} &&
        ${#_MOLE_TRASH_BATCH_SNAPSHOT_TARGET_IDS[@]} -eq ${#paths[@]} ]]; then
        use_bound_snapshots=true
    fi

    local -a expected_parents=()
    local -a expected_parent_ids=()
    local -a expected_target_ids=()
    local index p
    for ((index = 0; index < ${#paths[@]}; index++)); do
        p="${paths[$index]}"
        if [[ "$use_bound_snapshots" == "true" ]]; then
            [[ "${_MOLE_TRASH_BATCH_SNAPSHOT_PATHS[$index]}" == "$p" ]] || return 1
            expected_parents+=("${_MOLE_TRASH_BATCH_SNAPSHOT_PARENTS[$index]}")
            expected_parent_ids+=("${_MOLE_TRASH_BATCH_SNAPSHOT_PARENT_IDS[$index]}")
            expected_target_ids+=("${_MOLE_TRASH_BATCH_SNAPSHOT_TARGET_IDS[$index]}")
        else
            _mole_snapshot_path_identity "$p" || return 1
            expected_parents+=("$_MOLE_PATH_SNAPSHOT_PARENT")
            expected_parent_ids+=("$_MOLE_PATH_SNAPSHOT_PARENT_ID")
            expected_target_ids+=("$_MOLE_PATH_SNAPSHOT_TARGET_ID")
        fi
    done

    if [[ -n "${MOLE_TEST_TRASH_DIR:-}" ]] &&
        [[ "${MOLE_TEST_MODE:-0}" == "1" || "${MOLE_TEST_NO_AUTH:-0}" == "1" ]]; then
        mkdir -p "$MOLE_TEST_TRASH_DIR" 2> /dev/null || return 1
        local ts
        ts=$(date +%s 2> /dev/null || echo 0)
        local dest
        for ((index = 0; index < ${#paths[@]}; index++)); do
            p="${paths[$index]}"
            _mole_trash_target_still_safe \
                "$p" \
                "${expected_parents[$index]}" \
                "${expected_parent_ids[$index]}" \
                "${expected_target_ids[$index]}" || return $?
            dest="$MOLE_TEST_TRASH_DIR/$(basename "$p").$$.${ts}.$RANDOM"
            /bin/mv "$p" "$dest" 2> /dev/null || return $?
            _MOLE_TRASH_BATCH_MOVED_PATHS+=("$p")
        done
        return 0
    fi

    if [[ "${MOLE_TEST_NO_AUTH:-0}" == "1" ]]; then
        return 1
    fi

    # Stable invoking-user values are shared only for this batch. Destination
    # ownership, mode, live owners and source identity are checked per move.
    local _MOLE_TRASH_BATCH_HOME="" _MOLE_TRASH_BATCH_UID="" _MOLE_TRASH_BATCH_GID=""
    _MOLE_TRASH_BATCH_HOME=$(_mole_valid_invoking_home) || return 1
    _MOLE_TRASH_BATCH_UID=$(get_invoking_uid) || return 1
    _MOLE_TRASH_BATCH_GID=$(get_invoking_gid) || return 1

    # Avoid handing a stale lexical batch to a third-party Trash CLI or Finder.
    # Direct per-item renames keep the helper in one shell process and let us
    # recheck the bound parent/inode immediately before every move.
    local failed=0
    for ((index = 0; index < ${#paths[@]}; index++)); do
        p="${paths[$index]}"
        if ! _mole_path_matches_identity \
            "$p" \
            "${expected_parents[$index]}" \
            "${expected_parent_ids[$index]}" \
            "${expected_target_ids[$index]}"; then
            failed=1
            continue
        fi
        _MOLE_TRASH_MOVE_EXPECTED_PATH="$p"
        _MOLE_TRASH_MOVE_EXPECTED_PARENT="${expected_parents[$index]}"
        _MOLE_TRASH_MOVE_EXPECTED_PARENT_ID="${expected_parent_ids[$index]}"
        _MOLE_TRASH_MOVE_EXPECTED_TARGET_ID="${expected_target_ids[$index]}"
        local move_rc=0
        if _mole_move_path_to_user_trash "$p" false \
            "${expected_parents[$index]}" \
            "${expected_parent_ids[$index]}" \
            "${expected_target_ids[$index]}"; then
            _MOLE_TRASH_BATCH_MOVED_PATHS+=("$p")
        else
            move_rc=$?
            failed=1
        fi
        _MOLE_TRASH_MOVE_EXPECTED_PATH=""
        _MOLE_TRASH_MOVE_EXPECTED_PARENT=""
        _MOLE_TRASH_MOVE_EXPECTED_PARENT_ID=""
        _MOLE_TRASH_MOVE_EXPECTED_TARGET_ID=""
        mole_rc_timeout_or_signal "$move_rc" && return "$move_rc"
    done
    [[ $failed -eq 0 ]]
}

_mole_delete_log() {
    local mode="$1"
    local size_kb="$2"
    local status="$3"
    local target="$4"

    local log_file="${MOLE_DELETE_LOG:-$HOME/Library/Logs/mactools/mole/deletions.log}"
    local log_dir
    log_dir="${log_file%/*}"
    [[ "$log_dir" != "$log_file" ]] || log_dir="."

    # Surface log-write failures once per session. The deletions log is the
    # only audit trail for Trash-routed removals; silently no-oping when the
    # log dir is unwritable (root-owned from prior sudo, ENOSPC, read-only
    # volume) defeats the design.
    if [[ ! -d "$log_dir" ]] && ! mkdir -p "$log_dir" 2> /dev/null; then
        _mole_warn_log_broken "create directory: $log_dir"
        return 0
    fi

    local ts
    ts=$(date '+%Y-%m-%dT%H:%M:%S%z' 2> /dev/null || echo "unknown")

    _mole_escape_log_value mode "$mode"
    _mole_escape_log_value size_kb "$size_kb"
    _mole_escape_log_value status "$status"
    _mole_escape_log_value target "$target"
    if ! printf '%s\t%s\t%s\t%s\t%s\n' \
        "$ts" "$mode" "$size_kb" "$status" "$target" \
        >> "$log_file" 2> /dev/null; then
        _mole_warn_log_broken "write to: $log_file"
    fi
}

# ============================================================================
# Safe Find and Delete Operations
# ============================================================================

# Safe file discovery and deletion with depth and age limits
safe_find_delete() {
    local base_dir="$1"
    local pattern="$2"
    local age_days="${3:-7}"
    local type_filter="${4:-f}"

    # Validate base directory exists and is not a symlink
    if [[ ! -d "$base_dir" ]]; then
        log_error "Directory does not exist: $base_dir"
        return 1
    fi

    if [[ -L "$base_dir" ]]; then
        log_error "Refusing to search symlinked directory: $base_dir"
        return 1
    fi

    # Validate type filter
    if [[ "$type_filter" != "f" && "$type_filter" != "d" ]]; then
        log_error "Invalid type filter: $type_filter, must be 'f' or 'd'"
        return 1
    fi

    debug_log "Finding in $base_dir: $pattern, age: ${age_days}d, type: $type_filter"

    local find_args=("-maxdepth" "5" "-name" "$pattern" "-type" "$type_filter")
    if [[ "$age_days" -gt 0 ]]; then
        find_args+=("-mtime" "+$age_days")
    fi

    local scan_file=""
    if ! scan_file=$(create_temp_file 2> /dev/null); then
        return 1
    fi
    local scan_rc=0
    run_with_timeout "$MOLE_TIMEOUT_DISK_VERIFY_SEC" find \
        "$base_dir" "${find_args[@]}" -print0 < /dev/null > "$scan_file" 2> /dev/null || scan_rc=$?
    if [[ $scan_rc -ne 0 ]]; then
        rm -f -- "$scan_file" 2> /dev/null || true # SAFE: exact tracked temp file created above
        debug_log "Cleanup scan failed for $base_dir (status $scan_rc)"
        return "$scan_rc"
    fi

    # Iterate only a completed result set so a timeout cannot authorize
    # deletion of the partial prefix.
    # Per-caller whitelist gates were missed in past releases (see #710, #724,
    # #738, #744, #757); enforcing here makes the protection structural so
    # new clean_* functions get whitelist enforcement for free.
    local delete_rc=0
    while IFS= read -r -d '' match; do
        if declare -f should_protect_path > /dev/null 2>&1 && should_protect_path "$match"; then
            continue
        fi
        if declare -f is_path_whitelisted > /dev/null && is_path_whitelisted "$match"; then
            continue
        fi
        if [[ "${MOLE_DRY_RUN:-0}" == "1" ]] && declare -f record_dry_run_cleanup_target > /dev/null 2>&1; then
            local match_size_kb=0
            local match_size_rc=0
            match_size_kb=$(get_path_size_kb "$match" "" readable 2> /dev/null) || match_size_rc=$?
            if mole_rc_timeout_or_signal "$match_size_rc"; then
                delete_rc=$match_size_rc
                break
            fi
            [[ $match_size_rc -eq 0 ]] || match_size_kb=0
            [[ "$match_size_kb" =~ ^[0-9]+$ ]] || match_size_kb=0
            record_dry_run_cleanup_target "$match" "$match_size_kb" 1 true || continue
        fi
        local remove_rc=0
        safe_remove "$match" true || remove_rc=$?
        if mole_rc_timeout_or_signal "$remove_rc"; then
            delete_rc=$remove_rc
            break
        fi
        if [[ $remove_rc -ne 0 && $delete_rc -eq 0 ]]; then
            delete_rc=$remove_rc
        fi
    done < "$scan_file"
    rm -f -- "$scan_file" 2> /dev/null || true # SAFE: exact tracked temp file created above

    return "$delete_rc"
}

# Run privileged find with a wall-clock budget and closed stdin.
_mole_bounded_sudo_find() {
    local duration="${1:-${MOLE_TIMEOUT_DISK_VERIFY_SEC:-30}}"
    shift || true
    [[ $# -gt 0 ]] || return 2
    _mole_bounded_sudo "$duration" -n find "$@" < /dev/null
}

# Store a privileged scan only after the producer completed successfully. A
# timeout or any other failure truncates the destination so callers cannot act
# on a partial prefix.
_mole_materialize_bounded_sudo_find() {
    local output_file="$1"
    local duration="$2"
    shift 2
    [[ $# -gt 0 ]] || return 2

    : > "$output_file" || return 1
    local scan_rc=0
    _mole_bounded_sudo_find "$duration" "$@" > "$output_file" 2> /dev/null || scan_rc=$?
    if [[ $scan_rc -ne 0 ]]; then
        : > "$output_file" || true
        return "$scan_rc"
    fi
    return 0
}

# Keep privileged batch state bounded in Bash. This is a function rather than a
# public setting so tests can exercise the limit without exposing another user
# knob or constructing thousands of command-substitution probes.
_mole_privileged_batch_max_items() {
    printf '4096\n'
}

# Safe sudo discovery and deletion
safe_sudo_find_delete() {
    local base_dir="$1"
    local pattern="$2"
    local age_days="${3:-7}"
    local type_filter="${4:-f}"
    local max_depth="${5:-5}"
    local deadline_seconds="${6:-}"
    local -a name_patterns=("$pattern")
    if [[ $# -gt 6 ]]; then
        name_patterns+=("${@:7}")
    fi

    # Callers use this count to distinguish a completed empty scan from actual
    # cleanup. It is reset for every invocation and updated only for confirmed
    # removals or accepted dry-run previews.
    MOLE_SAFE_SUDO_FIND_DELETE_COUNT=0

    if [[ "$type_filter" != "f" && "$type_filter" != "d" ]]; then
        log_error "Invalid type filter: $type_filter, must be 'f' or 'd'"
        return 1
    fi
    if [[ ! "$age_days" =~ ^[0-9]+$ ]]; then
        log_error "Invalid age: $age_days, must be a non-negative integer"
        return 1
    fi
    if [[ ! "$max_depth" =~ ^[1-5]$ ]]; then
        log_error "Invalid max depth: $max_depth, must be between 1 and 5"
        return 1
    fi
    if [[ -n "$deadline_seconds" && ! "$deadline_seconds" =~ ^[0-9]+$ ]]; then
        log_error "Invalid cleanup deadline: $deadline_seconds"
        return 1
    fi

    if [[ "${MOLE_TEST_MODE:-0}" == "1" || "${MOLE_TEST_NO_AUTH:-0}" == "1" ]]; then
        debug_log "Skipping sudo find/delete in test mode: $base_dir"
        return 0
    fi

    # An already-expired overall budget authorizes no privileged probe at all.
    # Re-clamp every later probe because any preceding command can consume the
    # final second of the caller's section budget.
    _mole_timeout_with_deadline "$MOLE_TIMEOUT_QUICK_DETECT_SEC" \
        "$deadline_seconds" > /dev/null || return $?

    # Keep the entire sudo-probing body independent of the caller's errexit
    # state. macOS 14's /bin/bash build fires the caller's errexit when a
    # sudo shell-function mock returns nonzero inside an if condition (the
    # same bash 3.2.57 on macOS 15+ does not), so the guard must sit above
    # the first sudo probe, not just around the scan/batch loop. The
    # predicates below intentionally return 1 for ordinary "not protected /
    # not whitelisted / no oplog" cases; callers still get explicit nonzero
    # returns from the validation gates, restored to their errexit state.
    local restore_errexit=0
    case $- in
        *e*)
            restore_errexit=1
            set +e
            ;;
    esac

    # Confirm noninteractive authorization before interpreting a failed path
    # predicate as "not present". Otherwise an expired credential looks like an
    # empty successful scan and callers can print a false cleanup result.
    local sudo_rc=0
    _mole_bounded_sudo_until "$deadline_seconds" "$MOLE_TIMEOUT_QUICK_DETECT_SEC" \
        -n true < /dev/null > /dev/null 2>&1 || sudo_rc=$?
    if [[ $sudo_rc -ne 0 ]]; then
        [[ $restore_errexit -eq 1 ]] && set -e
        [[ $sudo_rc -ge 128 ]] && return "$sudo_rc"
        mole_rc_timeout "$sudo_rc" && return 124
        return "$MOLE_ERR_AUTH_FAILED"
    fi

    # Validate base directory (use sudo for permission-restricted dirs).
    local base_rc=0
    _mole_bounded_sudo_until "$deadline_seconds" "$MOLE_TIMEOUT_QUICK_DETECT_SEC" \
        -n test -d "$base_dir" < /dev/null 2> /dev/null || base_rc=$?
    if [[ $base_rc -ne 0 ]]; then
        if [[ $base_rc -ge 128 ]]; then
            [[ $restore_errexit -eq 1 ]] && set -e
            return "$base_rc"
        fi
        if mole_rc_timeout "$base_rc"; then
            [[ $restore_errexit -eq 1 ]] && set -e
            return 124
        fi
        # `sudo test` uses status 1 both for a false predicate and for some
        # authorization failures. Recheck credentials before calling this a
        # missing directory; a credential may expire after the initial probe.
        local base_auth_rc=0
        _mole_bounded_sudo_until "$deadline_seconds" "$MOLE_TIMEOUT_QUICK_DETECT_SEC" \
            -n true < /dev/null > /dev/null 2>&1 || base_auth_rc=$?
        if [[ $base_auth_rc -ne 0 ]]; then
            [[ $restore_errexit -eq 1 ]] && set -e
            [[ $base_auth_rc -ge 128 ]] && return "$base_auth_rc"
            mole_rc_timeout "$base_auth_rc" && return 124
            return "$MOLE_ERR_AUTH_FAILED"
        fi
        debug_log "Directory does not exist, skipping: $base_dir"
        [[ $restore_errexit -eq 1 ]] && set -e
        return 0
    fi

    local link_rc=0
    _mole_bounded_sudo_until "$deadline_seconds" "$MOLE_TIMEOUT_QUICK_DETECT_SEC" \
        -n test -L "$base_dir" < /dev/null 2> /dev/null || link_rc=$?
    if [[ $link_rc -eq 0 ]]; then
        log_error "Refusing to search symlinked directory: $base_dir"
        [[ $restore_errexit -eq 1 ]] && set -e
        return 1
    fi
    if mole_rc_timeout "$link_rc"; then
        [[ $restore_errexit -eq 1 ]] && set -e
        return 124
    fi
    if [[ $link_rc -ge 128 ]]; then
        [[ $restore_errexit -eq 1 ]] && set -e
        return "$link_rc"
    fi
    if [[ $link_rc -eq 1 ]]; then
        local link_auth_rc=0
        _mole_bounded_sudo_until "$deadline_seconds" "$MOLE_TIMEOUT_QUICK_DETECT_SEC" \
            -n true < /dev/null > /dev/null 2>&1 || link_auth_rc=$?
        if [[ $link_auth_rc -ne 0 ]]; then
            [[ $restore_errexit -eq 1 ]] && set -e
            [[ $link_auth_rc -ge 128 ]] && return "$link_auth_rc"
            mole_rc_timeout "$link_auth_rc" && return 124
            return "$MOLE_ERR_AUTH_FAILED"
        fi
    fi
    if [[ $link_rc -ne 1 ]]; then
        [[ $restore_errexit -eq 1 ]] && set -e
        return "$link_rc"
    fi

    debug_log "Finding, sudo, in $base_dir: $pattern, age: ${age_days}d, type: $type_filter"

    local find_args=("-maxdepth" "$max_depth")
    local match_all_names=false
    local name_pattern=""
    for name_pattern in "${name_patterns[@]}"; do
        if [[ "$name_pattern" == "*" ]]; then
            match_all_names=true
            break
        fi
    done
    if [[ "$match_all_names" != "true" ]]; then
        if [[ ${#name_patterns[@]} -eq 1 ]]; then
            find_args+=("-name" "${name_patterns[0]}")
        else
            find_args+=("(")
            local pattern_index=0
            for ((pattern_index = 0; pattern_index < ${#name_patterns[@]}; pattern_index++)); do
                [[ $pattern_index -gt 0 ]] && find_args+=("-o")
                find_args+=("-name" "${name_patterns[$pattern_index]}")
            done
            find_args+=(")")
        fi
    fi
    find_args+=("-type" "$type_filter")
    if [[ "$age_days" -gt 0 ]]; then
        find_args+=("-mtime" "+$age_days")
    fi

    # Materialize the completed scan before deleting anything. Process
    # substitution cannot expose the producer's exit status, so it previously
    # turned timeout 124 into an empty/partial successful scan and could delete
    # the partial prefix. A failed scan now authorizes no deletion.
    local scan_file=""
    if ! scan_file=$(create_temp_file 2> /dev/null); then
        [[ $restore_errexit -eq 1 ]] && set -e
        return 1
    fi
    local scan_rc=0
    local scan_timeout=""
    scan_timeout=$(_mole_timeout_with_deadline "$MOLE_TIMEOUT_DISK_VERIFY_SEC" \
        "$deadline_seconds") || scan_rc=$?
    if [[ $scan_rc -eq 0 ]]; then
        _mole_materialize_bounded_sudo_find "$scan_file" "$scan_timeout" \
            "$base_dir" "${find_args[@]}" -print0 || scan_rc=$?
    fi
    if [[ $scan_rc -ne 0 ]]; then
        rm -f -- "$scan_file" 2> /dev/null || true # SAFE: exact tracked temp file created above
        debug_log "Privileged cleanup scan failed for $base_dir (status $scan_rc)"
        [[ $restore_errexit -eq 1 ]] && set -e
        return "$scan_rc"
    fi

    # Iterate results to respect both system protection and user whitelist.
    # See safe_find_delete for rationale (#757).
    #
    # Regular files are removed in one privileged xargs batch instead of one
    # safe_sudo_remove per match: the single-file path costs three sudo forks
    # per file (test -e, du, rm), which turns a sweep over a stale .logarchive
    # bundle (1000+ tracev3 files) into minutes. Every path still passes the
    # same per-file gates before entering the batch; only the rm is batched.
    # Directories and dry-run keep the single-file path so rm -rf handling
    # and preview output stay unchanged.
    local -a batch_files=()
    local -a batch_identities=()
    local max_batch_items=""
    max_batch_items=$(_mole_privileged_batch_max_items)
    [[ "$max_batch_items" =~ ^[1-9][0-9]*$ ]] || max_batch_items=4096
    local removed_count=0
    local delete_rc=0
    local deadline_reached=false
    local batch_aborted=false
    while IFS= read -r -d '' match; do
        if [[ -n "$deadline_seconds" && $SECONDS -ge $deadline_seconds ]]; then
            deadline_reached=true
            delete_rc=124
            break
        fi
        if should_protect_path "$match"; then
            continue
        fi
        # Fast-path the active family before the general validator below. The
        # validator remains authoritative and also normalizes dot aliases so
        # preview and real cleanup cannot diverge.
        if _mole_is_active_powerlog_database_path "$match"; then
            continue
        fi
        if declare -f is_path_whitelisted > /dev/null && is_path_whitelisted "$match"; then
            continue
        fi
        # Run the same final path policy before preview accounting and real
        # removal. This keeps aliases such as /./ and case variants out of
        # both surfaces instead of relying on a raw-string precheck.
        if ! validate_path_for_deletion "$match"; then
            continue
        fi
        if _mole_privileged_path_has_mutable_ancestor "$match"; then
            # A privileged path-based delete cannot safely cross a directory
            # the invoking user can rename or replace. Delete only with the
            # caller's own permissions; root invocations skip the path because
            # they have no unprivileged identity to fall back to.
            if [[ ${EUID:-0} -ne 0 ]]; then
                local mutable_rc=0
                safe_remove "$match" true "" "$deadline_seconds" || mutable_rc=$?
                if [[ $mutable_rc -eq 0 ]]; then
                    removed_count=$((removed_count + 1))
                elif mole_rc_timeout_or_signal "$mutable_rc"; then
                    delete_rc=$mutable_rc
                    break
                elif [[ $delete_rc -eq 0 ]]; then
                    delete_rc=$mutable_rc
                fi
            else
                debug_log "Skipping sudo delete below mutable parent: $match"
                [[ $delete_rc -eq 0 ]] && delete_rc=1
            fi
            continue
        fi
        if [[ "${MOLE_DRY_RUN:-0}" == "1" ]] && declare -f record_dry_run_cleanup_target > /dev/null 2>&1; then
            local match_size_kb=0
            local match_size_known=false
            local raw_match_size=""
            local size_timeout=""
            local dry_size_rc=0
            size_timeout=$(_mole_timeout_with_deadline "$MOLE_TIMEOUT_DISK_VERIFY_SEC" \
                "$deadline_seconds") || dry_size_rc=$?
            if [[ $dry_size_rc -eq 0 ]]; then
                raw_match_size=$(_mole_bounded_sudo "$size_timeout" \
                    -n du -skP "$match" < /dev/null 2> /dev/null | awk '{print $1; exit}') || dry_size_rc=$?
            fi
            if mole_rc_timeout_or_signal "$dry_size_rc"; then
                delete_rc=$dry_size_rc
                break
            elif [[ $dry_size_rc -eq 0 ]]; then
                if [[ "$raw_match_size" =~ ^[0-9]+$ ]]; then
                    match_size_kb="$raw_match_size"
                    match_size_known=true
                fi
            fi
            record_dry_run_cleanup_target "$match" "$match_size_kb" 1 "$match_size_known" || continue
        fi
        # -type f never emits symlinks; a path that is one now was swapped
        # after find saw it, and the single-file path refuses those.
        if [[ "$type_filter" == "f" && "${MOLE_DRY_RUN:-0}" != "1" && ! -L "$match" ]]; then
            local identity_timeout=""
            local match_identity=""
            local identity_rc=0
            identity_timeout=$(_mole_timeout_with_deadline "$MOLE_TIMEOUT_QUICK_DETECT_SEC" \
                "$deadline_seconds") || identity_rc=$?
            if [[ $identity_rc -eq 0 ]]; then
                match_identity=$(_mole_bounded_sudo "$identity_timeout" \
                    -n "$STAT_BSD" -f%d:%i:%m "$match" < /dev/null 2> /dev/null) || identity_rc=$?
            fi
            if mole_rc_timeout_or_signal "$identity_rc"; then
                delete_rc=$identity_rc
                break
            fi
            if [[ $identity_rc -eq 0 && "$match_identity" =~ ^[0-9]+:[0-9]+:[0-9]+$ ]]; then
                if [[ ${#batch_files[@]} -ge $max_batch_items ]]; then
                    debug_log "Privileged cleanup candidate limit reached for $base_dir"
                    delete_rc=1
                    batch_aborted=true
                    break
                fi
                batch_files+=("$match")
                batch_identities+=("$match_identity")
            elif [[ $delete_rc -eq 0 ]]; then
                delete_rc=${identity_rc:-1}
                [[ $delete_rc -ne 0 ]] || delete_rc=1
            fi
            continue
        fi
        local single_rc=0
        safe_sudo_remove "$match" "" "$deadline_seconds" || single_rc=$?
        if [[ $single_rc -eq 0 ]]; then
            removed_count=$((removed_count + 1))
        elif mole_rc_timeout_or_signal "$single_rc"; then
            delete_rc=$single_rc
            break
        elif [[ $delete_rc -eq 0 ]]; then
            delete_rc=$single_rc
        fi
    done < "$scan_file"
    rm -f -- "$scan_file" 2> /dev/null || true # SAFE: exact tracked temp file created above

    if [[ -n "$deadline_seconds" && $SECONDS -ge $deadline_seconds ]]; then
        deadline_reached=true
        if [[ $delete_rc -lt 128 ]]; then
            delete_rc=124
        fi
    fi

    if [[ ${#batch_files[@]} -gt 0 && "$deadline_reached" != "true" && "$batch_aborted" != "true" ]] && ! mole_rc_timeout_or_signal "$delete_rc"; then
        local batch_rc=0
        local batch_result_file=""
        local batch_timeout=""
        if ! batch_timeout=$(_mole_timeout_with_deadline "$MOLE_TIMEOUT_DISK_VERIFY_SEC" \
            "$deadline_seconds"); then
            batch_rc=124
        elif ! batch_result_file=$(create_temp_file 2> /dev/null); then
            batch_rc=1
        else
            # The privileged worker acknowledges each completed unlink with a
            # NUL-delimited path. A later failure or timeout therefore cannot
            # erase the forensic record for an already completed prefix.
            local -a batch_worker_records=()
            local batch_index=0
            for ((batch_index = 0; batch_index < ${#batch_files[@]}; batch_index++)); do
                batch_worker_records+=("${batch_identities[$batch_index]}:${batch_files[$batch_index]}")
            done
            # shellcheck disable=SC2016 # $path expands inside privileged /bin/sh.
            printf '%s\0' "${batch_worker_records[@]}" |
                _mole_bounded_sudo "$batch_timeout" \
                    -n xargs -0 /bin/sh -c '
                        stat_tool=$1
                        age_days=$2
                        shift 2
                        for record do
                            dev=${record%%:*}
                            rest=${record#*:}
                            ino=${rest%%:*}
                            rest=${rest#*:}
                            mtime=${rest%%:*}
                            path=${rest#*:}
                            expected=$dev:$ino:$mtime
                            if [ "$age_days" -gt 0 ]; then
                                actual=$(/usr/bin/find "$path" -maxdepth 0 -type f -mtime "+$age_days" \
                                    -exec "$stat_tool" -f%d:%i:%m {} \; 2>/dev/null) || continue
                            else
                                actual=$($stat_tool -f%d:%i:%m "$path" 2>/dev/null) || continue
                            fi
                            [ "$actual" = "$expected" ] || continue
                            /bin/rm -f -- "$path" || exit 1
                            printf "%s\0" "$path"
                        done
                    ' sh "$STAT_BSD" "$age_days" > "$batch_result_file" 2> /dev/null || batch_rc=$?

            local batch_ts=""
            local batch_command=""
            if oplog_enabled; then
                batch_ts=$(get_timestamp)
                operation_log_command batch_command "${MOLE_CURRENT_COMMAND:-clean}"
            fi
            local batch_ack_count=0
            local -a removed_lines=()
            local batch_file=""
            while IFS= read -r -d '' batch_file; do
                batch_ack_count=$((batch_ack_count + 1))
                if [[ -n "$batch_ts" ]]; then
                    removed_lines+=("[$batch_ts] [$batch_command] REMOVED $batch_file (batch)")
                fi
            done < "$batch_result_file"
            rm -f -- "$batch_result_file" 2> /dev/null || true # SAFE: exact tracked temp file created above

            removed_count=$((removed_count + batch_ack_count))
            if [[ ${#removed_lines[@]} -gt 0 ]]; then
                append_log_lines "$OPERATIONS_LOG_FILE" "${removed_lines[@]}"
            fi
            if [[ $batch_rc -eq 0 && $batch_ack_count -ne ${#batch_files[@]} ]]; then
                batch_rc=1
            fi
        fi

        if [[ $batch_rc -ne 0 && $delete_rc -eq 0 ]]; then
            delete_rc=$batch_rc
            log_operation "${MOLE_CURRENT_COMMAND:-clean}" "FAILED" "$base_dir" \
                "batch removal incomplete (status $batch_rc)"
        fi
    fi

    MOLE_SAFE_SUDO_FIND_DELETE_COUNT=$removed_count

    if [[ $restore_errexit -eq 1 ]]; then
        set -e
    fi

    return "$delete_rc"
}

# ============================================================================
# Size Calculation
# ============================================================================

# Get path size in KB (returns 0 if not found)
#
# For regular files and symlinks, prefer allocated blocks from 'stat' over
# 'du': it avoids the fork+pipe cost of 'du | awk' on every call, which adds
# up in tight loops (e.g. external-volume ._* sweeps, Application Support log
# scans). macOS st_blocks and 'du -skP' use the same 512-byte allocation basis
# without following symlinks. Directories still go through 'du' because 'stat'
# only reports a single directory entry, not recursive content size. .app
# bundles use Spotlight's physical size when available so uninstall previews
# do not add logical bundle bytes to physical leftover sizes.
#
# Optional third argument "readable": du exits 1 when it cannot list some
# directory, after printing the total of everything it could read. Uninstall
# needs a complete size (#1404), so by default that is a failure. A cleanup
# total passes "readable" and takes the readable bytes: a directory the user
# cannot list cannot be removed by Mole either, so those bytes are exactly what
# the cleanup can free, and dropping them counted the whole item as 0.
get_path_size_kb() {
    local path="$1"
    local size_timeout="${2:-$MOLE_TIMEOUT_DISK_VERIFY_SEC}"
    local size_mode="${3:-}"
    [[ -z "$path" || ! -e "$path" ]] && {
        echo "0"
        return
    }

    if [[ ! "$size_timeout" =~ ^[0-9]+(\.[0-9]+)?$ || "$size_timeout" =~ ^0+(\.0+)?$ ]]; then
        size_timeout="$MOLE_TIMEOUT_DISK_VERIFY_SEC"
    fi
    local timeout_whole="${size_timeout%%.*}"
    local timeout_budget=$((10#$timeout_whole))
    if [[ "$size_timeout" == *.* && "${size_timeout#*.}" =~ [1-9] ]]; then
        timeout_budget=$((timeout_budget + 1))
    fi
    [[ $timeout_budget -gt 0 ]] || timeout_budget=1
    local size_deadline=$((SECONDS + timeout_budget))

    # Uninstall totals represent estimated disk occupancy. Keep .app bundles
    # on the same physical-size basis as the directory fallback; logical size
    # can be much larger for APFS-cloned bundles and must not be mixed into the
    # same total as `du` results (#1404).
    if [[ "$path" == *.[aA][pP][pP] || "$path" == *.[aA][pP][pP]/ ]]; then
        local mdls_size
        local mdls_timeout=""
        local mdls_deadline_rc=0
        mdls_timeout=$(_mole_timeout_with_deadline \
            "$size_timeout" "$size_deadline") || mdls_deadline_rc=$?
        [[ $mdls_deadline_rc -eq 0 ]] || return "$mdls_deadline_rc"
        local mdls_rc=0
        mdls_size=$(run_with_timeout "$mdls_timeout" mdls \
            -name kMDItemPhysicalSize -raw "$path" < /dev/null 2> /dev/null) || mdls_rc=$?
        mole_rc_timeout_or_signal "$mdls_rc" && return "$mdls_rc"
        if [[ "$mdls_size" =~ ^[0-9]+$ && "$mdls_size" -gt 0 ]]; then
            echo $(((mdls_size + 1023) / 1024))
            return
        fi
    fi

    # Fast path for regular files and symlinks: st_blocks is measured in
    # 512-byte units and matches the physical basis of `du -skP`.
    if [[ -f "$path" || -L "$path" ]]; then
        local blocks
        local stat_timeout=""
        local stat_deadline_rc=0
        stat_timeout=$(_mole_timeout_with_deadline \
            "$size_timeout" "$size_deadline") || stat_deadline_rc=$?
        [[ $stat_deadline_rc -eq 0 ]] || return "$stat_deadline_rc"
        local stat_rc=0
        blocks=$(run_with_timeout "$stat_timeout" "$STAT_BSD" \
            -f%b "$path" < /dev/null 2> /dev/null) || stat_rc=$?
        mole_rc_timeout_or_signal "$stat_rc" && return "$stat_rc"
        if [[ "$blocks" =~ ^[0-9]+$ ]]; then
            echo $(((blocks + 1) / 2))
            return
        fi
    fi

    # Bounded like every other du call site (hints/project/caches): an
    # unbounded walk here wedges one parallel sizing worker forever on a
    # stalled SMB/FUSE mount. A timeout is cancellation, not a zero-byte
    # measurement, because callers may feed the result into a deletion plan.
    local size
    local du_timeout=""
    local du_deadline_rc=0
    du_timeout=$(_mole_timeout_with_deadline \
        "$size_timeout" "$size_deadline") || du_deadline_rc=$?
    [[ $du_deadline_rc -eq 0 ]] || return "$du_deadline_rc"
    local du_rc=0
    size=$(run_with_timeout "$du_timeout" du -skP "$path" 2> /dev/null |
        awk 'NR==1 {print $1; exit}') || du_rc=$?
    # `du` may print a partial aggregate before reporting an unreadable child.
    # Any nonzero status makes that number incomplete, so never return it as a
    # successful size estimate (#1404), unless the caller asked for readable
    # bytes (see above).
    if mole_rc_timeout "$du_rc" && declare -F debug_log > /dev/null; then
        debug_log "Size check timed out after ${size_timeout}s: $path"
    fi
    if [[ $du_rc -eq 1 && "$size_mode" == "readable" && "$size" =~ ^[0-9]+$ ]]; then
        echo "$size"
        return 0
    fi
    [[ $du_rc -eq 0 ]] || return "$du_rc"

    if [[ "$size" =~ ^[0-9]+$ ]]; then
        echo "$size"
    else
        [[ "${MO_DEBUG:-}" == "1" ]] && debug_log "get_path_size_kb: Failed to get size for $path (returned: $size)"
        echo "0"
    fi
}

# Add one reported cleanup row to the run totals: its item count, its KB, and
# one category. Every section that prints its own result row goes through
# here, so non-numeric input counts as zero instead of arithmetic on a name.
# Dry-run totals are rebuilt from the preview ledger at the end of the run.
mole_add_cleaned_row() {
    local count="${1:-0}" size_kb="${2:-0}"
    [[ "$count" =~ ^[0-9]+$ ]] || count=0
    [[ "$size_kb" =~ ^[0-9]+$ ]] || size_kb=0
    files_cleaned=$((${files_cleaned:-0} + count))
    total_size_cleaned=$((${total_size_cleaned:-0} + size_kb))
    total_items=$((${total_items:-0} + 1))
}

# Classify a per-item get_path_size_kb status for a caller whose size only
# feeds totals (bugs reference, section 15). Callers measure with "readable",
# so an unlistable directory already arrives as its readable bytes. A timeout
# leaves the item eligible with an unknown size and marks the freed total
# partial; any other failure (the item vanished) leaves nothing to free and no
# mark; a signal records the cancellation and returns its status so the caller
# stops.
mole_item_size_continues() {
    local rc="${1:-0}"
    [[ $rc -eq 0 ]] && return 0
    if [[ $rc -ge 128 ]]; then
        _mole_record_clean_cancellation "$rc"
        return "$rc"
    fi
    if mole_rc_timeout "$rc"; then
        MOLE_CLEAN_SIZING_TIMEOUTS=$((${MOLE_CLEAN_SIZING_TIMEOUTS:-0} + 1))
    fi
    return 0
}

# Calculate total size for multiple paths
calculate_total_size() {
    local files="$1"
    local total_kb=0 file
    local -a unique_paths=()
    while IFS= read -r file; do
        [[ -z "$file" || ! -e "$file" ]] || unique_paths+=("$file")
    done <<< "$files"
    local filtered=""
    filtered=$(mole_filter_nested_paths "${unique_paths[@]+"${unique_paths[@]}"}") || return $?
    unique_paths=()
    while IFS= read -r file; do
        [[ -z "$file" ]] || unique_paths+=("$file")
    done <<< "$filtered"

    for file in "${unique_paths[@]+"${unique_paths[@]}"}"; do
        local size_kb=0
        local size_rc=0
        size_kb=$(get_path_size_kb "$file") || size_rc=$?
        mole_rc_timeout_or_signal "$size_rc" && return "$size_rc"
        [[ $size_rc -eq 0 && "$size_kb" =~ ^[0-9]+$ ]] || size_kb=0
        total_kb=$((total_kb + size_kb))
    done

    echo "$total_kb"
}

diagnose_removal_failure() {
    local exit_code="$1"
    local app_name="${2:-application}"

    local reason=""
    local suggestion=""

    case "$exit_code" in
        "$MOLE_ERR_SIP_PROTECTED")
            reason="protected by macOS (SIP/MDM)"
            ;;
        "$MOLE_ERR_AUTH_FAILED")
            reason="authentication failed"
            if declare -F check_touchid_support > /dev/null 2>&1 && check_touchid_support > /dev/null 2>&1; then
                suggestion="Check your credentials or restart Terminal"
            else
                suggestion="Try 'mole touchid' to enable fingerprint auth"
            fi
            ;;
        "$MOLE_ERR_READONLY_FS")
            reason="filesystem is read-only"
            suggestion="Check if disk needs repair"
            ;;
        "$MOLE_ERR_PROTECTED_PATH")
            reason="protected by Mole safety rules"
            ;;
        "$MOLE_ERR_PRIVACY_DENIED")
            reason="macOS denied Trash access"
            suggestion="Try moving the item to Trash in Finder. Run with --debug for details"
            ;;
        "$MOLE_ERR_MUTABLE_PARENT")
            reason="Mole cannot safely use elevated deletion below a user-writable parent"
            suggestion="Move the app to Trash in Finder; Mole will leave protected containers and app data untouched"
            ;;
        *)
            reason="permission denied"
            if declare -F check_touchid_support > /dev/null 2>&1 && check_touchid_support > /dev/null 2>&1; then
                suggestion="Try running again or check file ownership"
            else
                suggestion="Try 'mole touchid' or check with 'ls -l'"
            fi
            ;;
    esac

    echo "$reason|$suggestion"
}
